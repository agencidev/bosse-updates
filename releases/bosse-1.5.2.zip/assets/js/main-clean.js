/**
 * Main JavaScript
 * General site functionality
 */

'use strict';

// General site initialization
document.addEventListener('DOMContentLoaded', function() {
  // Add any general site JavaScript here
});
