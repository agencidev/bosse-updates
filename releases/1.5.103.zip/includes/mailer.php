<?php
/**
 * SMTP Mailer
 * Ren PHP SMTP-klient utan externa beroenden
 * Stöd för SSL (port 465) och STARTTLS (port 587)
 * Stöd för MIME multipart attachments
 */

class SmtpMailer {
    private string $host;
    private int $port;
    private string $username;
    private string $password;
    private string $encryption;
    private int $timeout;
    private bool $verifySsl;
    private $socket = null;
    private string $lastError = '';

    public function __construct(
        string $host,
        int $port,
        string $username,
        string $password,
        string $encryption = 'ssl',
        int $timeout = 30,
        bool $verifySsl = true
    ) {
        $this->host = $host;
        $this->port = $port;
        $this->username = $username;
        $this->password = $password;
        $this->encryption = strtolower($encryption);
        $this->timeout = $timeout;
        $this->verifySsl = $verifySsl;
    }

    /**
     * Get last error message
     */
    public function getLastError(): string {
        return $this->lastError;
    }

    /**
     * Skicka plaintext-mail
     */
    public function send(
        string $to,
        string $subject,
        string $body,
        string $from_name = '',
        string $from_email = '',
        string $reply_to = '',
        array $attachments = []
    ): bool {
        $message = $this->buildMessage($from_name, $from_email, $to, $subject, $reply_to, false, $body, $attachments);
        return $this->sendMessage($to, $from_email ?: $this->username, $message);
    }

    /**
     * Skicka HTML-mail
     */
    public function sendHtml(
        string $to,
        string $subject,
        string $htmlBody,
        string $from_name = '',
        string $from_email = '',
        string $reply_to = '',
        array $attachments = []
    ): bool {
        $message = $this->buildMessage($from_name, $from_email, $to, $subject, $reply_to, true, $htmlBody, $attachments);
        return $this->sendMessage($to, $from_email ?: $this->username, $message);
    }

    /**
     * Bygg komplett MIME-meddelande (headers + body)
     */
    private function buildMessage(
        string $from_name,
        string $from_email,
        string $to,
        string $subject,
        string $reply_to,
        bool $html,
        string $body,
        array $attachments = []
    ): string {
        if (empty($from_email)) {
            $from_email = $this->username;
        }

        $from = $from_name
            ? '=?UTF-8?B?' . base64_encode($from_name) . '?= <' . $from_email . '>'
            : $from_email;

        $headers  = "Date: " . date('r') . "\r\n";
        $headers .= "From: " . $from . "\r\n";
        $headers .= "To: " . $to . "\r\n";
        $headers .= "Subject: =?UTF-8?B?" . base64_encode($subject) . "?=\r\n";
        $headers .= "MIME-Version: 1.0\r\n";

        if (!empty($reply_to)) {
            $headers .= "Reply-To: " . $reply_to . "\r\n";
        }

        $headers .= "X-Mailer: Bosse-Template-PHP/1.0\r\n";

        // Without attachments — simple message
        if (empty($attachments)) {
            $contentType = $html ? 'text/html' : 'text/plain';
            $headers .= "Content-Type: {$contentType}; charset=UTF-8\r\n";
            $headers .= "Content-Transfer-Encoding: base64\r\n";
            return $headers . "\r\n" . chunk_split(base64_encode($body));
        }

        // With attachments — multipart/mixed
        $boundary = 'Bosse_' . bin2hex(random_bytes(16));
        $headers .= "Content-Type: multipart/mixed; boundary=\"{$boundary}\"\r\n";

        $message = $headers . "\r\n";
        $message .= "--{$boundary}\r\n";

        // Body part
        $contentType = $html ? 'text/html' : 'text/plain';
        $message .= "Content-Type: {$contentType}; charset=UTF-8\r\n";
        $message .= "Content-Transfer-Encoding: base64\r\n\r\n";
        $message .= chunk_split(base64_encode($body)) . "\r\n";

        // Attachment parts
        foreach ($attachments as $filePath) {
            if (!file_exists($filePath) || !is_readable($filePath)) {
                continue;
            }

            $filename = basename($filePath);
            $mimeType = $this->detectMimeType($filePath);
            $fileData = file_get_contents($filePath);

            $message .= "--{$boundary}\r\n";
            $message .= "Content-Type: {$mimeType}; name=\"{$filename}\"\r\n";
            $message .= "Content-Disposition: attachment; filename=\"{$filename}\"\r\n";
            $message .= "Content-Transfer-Encoding: base64\r\n\r\n";
            $message .= chunk_split(base64_encode($fileData)) . "\r\n";
        }

        $message .= "--{$boundary}--\r\n";

        return $message;
    }

    /**
     * Detect MIME type for attachment
     */
    private function detectMimeType(string $filePath): string {
        $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        $mimeMap = [
            'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg',
            'png' => 'image/png', 'gif' => 'image/gif',
            'webp' => 'image/webp', 'svg' => 'image/svg+xml',
            'pdf' => 'application/pdf',
            'doc' => 'application/msword',
            'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
            'xls' => 'application/vnd.ms-excel',
            'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            'zip' => 'application/zip',
            'txt' => 'text/plain',
            'csv' => 'text/csv',
        ];
        return $mimeMap[$ext] ?? 'application/octet-stream';
    }

    /**
     * Skicka meddelande via SMTP
     */
    private function sendMessage(string $to, string $from_email, string $fullMessage): bool {
        $this->lastError = '';

        try {
            $this->connect();
            $this->authenticate();

            // MAIL FROM
            $response = $this->sendCommand("MAIL FROM:<{$from_email}>");
            if (!$this->isResponseOk($response, 250)) {
                throw new \RuntimeException("MAIL FROM rejected: {$response}");
            }

            // RCPT TO
            $response = $this->sendCommand("RCPT TO:<{$to}>");
            if (!$this->isResponseOk($response, 250)) {
                throw new \RuntimeException("RCPT TO rejected: {$response}");
            }

            // DATA
            $response = $this->sendCommand("DATA");
            if (!$this->isResponseOk($response, 354)) {
                throw new \RuntimeException("DATA rejected: {$response}");
            }

            // Send full message + terminator
            $response = $this->sendCommand($fullMessage . "\r\n.");
            if (!$this->isResponseOk($response, 250)) {
                throw new \RuntimeException("Message rejected: {$response}");
            }

            $this->close();
            return true;

        } catch (\Throwable $e) {
            $this->lastError = $e->getMessage();
            error_log("SMTP Error: " . $e->getMessage());
            $this->close();
            return false;
        }
    }

    /**
     * Anslut till SMTP-server
     */
    private function connect(): void {
        $address = $this->host;

        if ($this->encryption === 'ssl') {
            $address = 'ssl://' . $this->host;
        }

        $sslOptions = $this->verifySsl
            ? ['verify_peer' => true, 'verify_peer_name' => true, 'allow_self_signed' => false]
            : ['verify_peer' => false, 'verify_peer_name' => false, 'allow_self_signed' => true];

        $context = stream_context_create(['ssl' => $sslOptions]);

        $this->socket = @stream_socket_client(
            "{$address}:{$this->port}",
            $errno,
            $errstr,
            $this->timeout,
            STREAM_CLIENT_CONNECT,
            $context
        );

        if (!$this->socket) {
            throw new \RuntimeException("Could not connect to {$this->host}:{$this->port} - {$errstr} ({$errno})");
        }

        stream_set_timeout($this->socket, $this->timeout);

        // Läs server-greeting
        $greeting = $this->readResponse();
        if (!$this->isResponseOk($greeting, 220)) {
            throw new \RuntimeException("Unexpected greeting: {$greeting}");
        }

        // EHLO
        $response = $this->sendCommand("EHLO " . gethostname());
        if (!$this->isResponseOk($response, 250)) {
            // Fallback till HELO
            $response = $this->sendCommand("HELO " . gethostname());
            if (!$this->isResponseOk($response, 250)) {
                throw new \RuntimeException("EHLO/HELO rejected: {$response}");
            }
        }

        // STARTTLS om encryption = tls
        if ($this->encryption === 'tls') {
            $response = $this->sendCommand("STARTTLS");
            if (!$this->isResponseOk($response, 220)) {
                throw new \RuntimeException("STARTTLS rejected: {$response}");
            }

            $crypto = stream_socket_enable_crypto($this->socket, true, STREAM_CRYPTO_METHOD_TLSv1_2_CLIENT);
            if (!$crypto) {
                throw new \RuntimeException("TLS handshake failed");
            }

            // EHLO igen efter TLS
            $response = $this->sendCommand("EHLO " . gethostname());
            if (!$this->isResponseOk($response, 250)) {
                throw new \RuntimeException("EHLO after STARTTLS rejected: {$response}");
            }
        }
    }

    /**
     * Autentisera med AUTH LOGIN
     */
    private function authenticate(): void {
        $response = $this->sendCommand("AUTH LOGIN");
        if (!$this->isResponseOk($response, 334)) {
            throw new \RuntimeException("AUTH LOGIN rejected: {$response}");
        }

        $response = $this->sendCommand(base64_encode($this->username));
        if (!$this->isResponseOk($response, 334)) {
            throw new \RuntimeException("Username rejected: {$response}");
        }

        $response = $this->sendCommand(base64_encode($this->password));
        if (!$this->isResponseOk($response, 235)) {
            throw new \RuntimeException("Authentication failed: {$response}");
        }
    }

    /**
     * Skicka SMTP-kommando och läs svar
     */
    private function sendCommand(string $command): string {
        if (!$this->socket) {
            throw new \RuntimeException("Not connected to SMTP server");
        }

        fwrite($this->socket, $command . "\r\n");
        return $this->readResponse();
    }

    /**
     * Läs svar från SMTP-server
     */
    private function readResponse(): string {
        if (!$this->socket) {
            return '';
        }

        $response = '';
        while (true) {
            $line = fgets($this->socket, 4096);
            if ($line === false) {
                break;
            }
            $response .= $line;
            // SMTP multiline: om 4:e tecknet är mellanslag är det sista raden
            if (isset($line[3]) && $line[3] === ' ') {
                break;
            }
            // Enradig respons utan continuation
            if (strlen($line) < 4) {
                break;
            }
        }

        return trim($response);
    }

    /**
     * Kontrollera om responsekod matchar
     */
    private function isResponseOk(string $response, int $expected): bool {
        return (int)substr($response, 0, 3) === $expected;
    }

    /**
     * Stäng anslutning
     */
    private function close(): void {
        if ($this->socket) {
            @fwrite($this->socket, "QUIT\r\n");
            @fclose($this->socket);
            $this->socket = null;
        }
    }
}

/**
 * Get last send_mail() error message
 */
function send_mail_error(): string {
    global $_send_mail_last_error;
    return $_send_mail_last_error ?? '';
}

/**
 * Wrapper-funktion för att skicka mail
 *
 * @param string $to Mottagare
 * @param string $subject Ämne
 * @param string $body Meddelande
 * @param array $options Extra alternativ:
 *   - html (bool): Skicka som HTML
 *   - reply_to (string): Reply-To adress
 *   - from_name (string): Avsändarnamn
 *   - from_email (string): Avsändaradress
 *   - attachments (array): Filsökvägar att bifoga, t.ex. ['/path/to/file.jpg', '/path/to/doc.pdf']
 *   - delete_attachments (bool): Radera bifogade filer efter lyckat utskick (default false)
 * @return bool True vid lyckat utskick, false vid misslyckande. Använd send_mail_error() för detaljer.
 */
function send_mail(string $to, string $subject, string $body, array $options = []): bool {
    global $_send_mail_last_error;
    $_send_mail_last_error = '';

    // Kontrollera att SMTP-config finns
    if (!defined('SMTP_HOST') || !defined('SMTP_PORT') || !defined('SMTP_USERNAME') || !defined('SMTP_PASSWORD')) {
        $_send_mail_last_error = 'SMTP är inte konfigurerat. Ange SMTP-uppgifter i config.php.';
        error_log('send_mail: ' . $_send_mail_last_error);
        return false;
    }

    if (empty(SMTP_HOST) || empty(SMTP_USERNAME) || empty(SMTP_PASSWORD)) {
        $_send_mail_last_error = 'SMTP-uppgifter saknas (host, username eller password är tomma).';
        error_log('send_mail: ' . $_send_mail_last_error);
        return false;
    }

    $html = $options['html'] ?? false;
    $reply_to = $options['reply_to'] ?? '';
    $from_name = $options['from_name'] ?? (defined('SITE_NAME') ? SITE_NAME : '');
    $from_email = $options['from_email'] ?? SMTP_USERNAME;
    $attachments = $options['attachments'] ?? [];
    $deleteAttachments = $options['delete_attachments'] ?? false;
    $encryption = defined('SMTP_ENCRYPTION') ? SMTP_ENCRYPTION : 'ssl';
    $verifySsl = defined('SMTP_VERIFY_SSL') ? (bool)SMTP_VERIFY_SSL : true;

    // Validate attachments exist
    $validAttachments = [];
    foreach ($attachments as $file) {
        if (file_exists($file) && is_readable($file)) {
            $validAttachments[] = $file;
        } else {
            error_log("send_mail: Bilaga saknas eller ej läsbar: {$file}");
        }
    }

    $mailer = new SmtpMailer(
        SMTP_HOST,
        (int)SMTP_PORT,
        SMTP_USERNAME,
        SMTP_PASSWORD,
        $encryption,
        30,
        $verifySsl
    );

    if ($html) {
        $result = $mailer->sendHtml($to, $subject, $body, $from_name, $from_email, $reply_to, $validAttachments);
    } else {
        $result = $mailer->send($to, $subject, $body, $from_name, $from_email, $reply_to, $validAttachments);
    }

    if (!$result) {
        $_send_mail_last_error = $mailer->getLastError();
        return false;
    }

    // Delete attachments after successful send
    if ($deleteAttachments) {
        foreach ($validAttachments as $file) {
            @unlink($file);
        }
    }

    return true;
}
