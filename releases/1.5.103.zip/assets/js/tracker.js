/**
 * Bosse Analytics Tracker
 * Consent-gated, privacy-first page analytics
 * Tracks: pageviews, scroll depth, time on page, clicks (heatmap)
 */
(function() {
    'use strict';

    var ENDPOINT = '/cms/analytics-collect.php';
    var HEARTBEAT_INTERVAL = 30000; // 30s
    var CLICK_BATCH_SIZE = 20;
    var SESSION_TIMEOUT = 30 * 60 * 1000; // 30 min

    // Check consent
    function getConsent() {
        var match = document.cookie.match(/(?:^|; )cookie_consent=([^;]*)/);
        if (!match) return null;
        try { return JSON.parse(decodeURIComponent(match[1])); }
        catch(e) { return null; }
    }

    var consent = getConsent();
    if (!consent || !consent.analytics) return;

    // Cookie helpers
    function getCookie(name) {
        var match = document.cookie.match(new RegExp('(?:^|; )' + name + '=([^;]*)'));
        return match ? match[1] : null;
    }

    function setCookie(name, value, days) {
        var d = new Date();
        d.setTime(d.getTime() + days * 86400000);
        document.cookie = name + '=' + value + ';expires=' + d.toUTCString() + ';path=/;SameSite=Lax';
    }

    // Generate random hex ID
    function genId(len) {
        var arr = new Uint8Array(len / 2);
        crypto.getRandomValues(arr);
        return Array.from(arr, function(b) { return ('0' + b.toString(16)).slice(-2); }).join('');
    }

    // Visitor ID (1 year)
    var vid = getCookie('_bv');
    if (!vid) {
        vid = genId(16);
        setCookie('_bv', vid, 365);
    }

    // Session ID (30 min sliding)
    var sid = getCookie('_bs');
    if (!sid) {
        sid = genId(16);
    }
    setCookie('_bs', sid, 0); // session-length initially, extended by heartbeat

    function renewSession() {
        setCookie('_bs', sid, 0);
        // Re-set with 30 min from now (approximate via max-age workaround)
        var d = new Date();
        d.setTime(d.getTime() + SESSION_TIMEOUT);
        document.cookie = '_bs=' + sid + ';expires=' + d.toUTCString() + ';path=/;SameSite=Lax';
    }

    // Send data
    function send(data) {
        data.sid = sid;
        data.vid = vid;
        var json = JSON.stringify(data);
        if (navigator.sendBeacon) {
            navigator.sendBeacon(ENDPOINT, json);
        } else {
            var xhr = new XMLHttpRequest();
            xhr.open('POST', ENDPOINT, true);
            xhr.setRequestHeader('Content-Type', 'application/json');
            xhr.send(json);
        }
    }

    // Parse UTM params
    function getUtm() {
        var params = new URLSearchParams(location.search);
        return {
            utm_source: params.get('utm_source') || '',
            utm_medium: params.get('utm_medium') || '',
            utm_campaign: params.get('utm_campaign') || ''
        };
    }

    // ── Pageview ──
    var utm = getUtm();
    send({
        type: 'pageview',
        path: location.pathname,
        title: document.title,
        ref: document.referrer,
        sw: screen.width,
        sh: screen.height,
        utm_source: utm.utm_source,
        utm_medium: utm.utm_medium,
        utm_campaign: utm.utm_campaign
    });

    // ── Scroll tracking ──
    var maxScroll = 0;
    function updateScroll() {
        var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        var docHeight = Math.max(
            document.body.scrollHeight, document.documentElement.scrollHeight,
            document.body.offsetHeight, document.documentElement.offsetHeight
        );
        var winHeight = window.innerHeight;
        if (docHeight <= winHeight) {
            maxScroll = 100;
        } else {
            var pct = Math.round((scrollTop + winHeight) / docHeight * 100);
            if (pct > maxScroll) maxScroll = pct;
        }
    }
    window.addEventListener('scroll', updateScroll, { passive: true });
    updateScroll();

    // ── Time on page ──
    var pageStart = Date.now();

    // ── Heartbeat ──
    var heartbeatTimer = setInterval(function() {
        renewSession();
        send({
            type: 'heartbeat',
            path: location.pathname,
            scroll: maxScroll,
            time: Math.round((Date.now() - pageStart) / 1000)
        });
    }, HEARTBEAT_INTERVAL);

    // ── Click tracking (heatmap) ──
    var clickBuffer = [];

    document.addEventListener('click', function(e) {
        var docHeight = Math.max(
            document.body.scrollHeight, document.documentElement.scrollHeight
        );
        var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
        var x = ((e.clientX / window.innerWidth) * 100).toFixed(2);
        var y = (((e.clientY + scrollTop) / docHeight) * 100).toFixed(2);

        var tag = e.target.tagName || '';
        var text = (e.target.textContent || '').trim().substring(0, 50);

        clickBuffer.push({
            x: parseFloat(x),
            y: parseFloat(y),
            tag: tag,
            text: text,
            vw: window.innerWidth,
            ph: docHeight
        });

        if (clickBuffer.length >= CLICK_BATCH_SIZE) {
            flushClicks();
        }
    }, true);

    function flushClicks() {
        if (clickBuffer.length === 0) return;
        var batch = clickBuffer.splice(0, CLICK_BATCH_SIZE);
        send({
            type: 'clicks',
            path: location.pathname,
            clicks: batch
        });
    }

    // ── Page leave: send final heartbeat + flush clicks ──
    function onLeave() {
        clearInterval(heartbeatTimer);
        send({
            type: 'heartbeat',
            path: location.pathname,
            scroll: maxScroll,
            time: Math.round((Date.now() - pageStart) / 1000)
        });
        flushClicks();
    }

    // Use pagehide (most reliable) with visibilitychange fallback
    if ('onpagehide' in window) {
        window.addEventListener('pagehide', onLeave);
    } else {
        window.addEventListener('beforeunload', onLeave);
    }
    document.addEventListener('visibilitychange', function() {
        if (document.visibilityState === 'hidden') {
            onLeave();
        }
    });

})();
