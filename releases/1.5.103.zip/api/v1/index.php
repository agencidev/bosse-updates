<?php
declare(strict_types=1);
/**
 * Stira REST API v1 — Entry Point
 * Handles authentication, rate limiting, CORS, and routing.
 */

// ── Bootstrap ───────────────────────────────────────────
require_once __DIR__ . '/../../bootstrap.php';
require_once ROOT_PATH . '/security/audit.php';
require_once ROOT_PATH . '/security/validation.php';
require_once ROOT_PATH . '/security/session.php';
require_once ROOT_PATH . '/cms/content.php';
require_once ROOT_PATH . '/cms/helpers.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/rate-limit.php';

// ── JSON response helpers ───────────────────────────────

function api_success(mixed $data, array $meta = [], int $status = 200): never {
    http_response_code($status);
    $response = ['data' => $data];
    if (!empty($meta)) {
        $response['meta'] = $meta;
    }
    echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

function api_error(int $code, string $message, array $details = [], string $allowed = ''): never {
    http_response_code($code);
    if ($allowed !== '') {
        header("Allow: $allowed");
    }
    $body = ['error' => ['code' => $code, 'message' => $message]];
    if (!empty($details)) {
        $body['error']['details'] = $details;
    }
    echo json_encode($body, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    exit;
}

function api_get_json_body(): array {
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    if (stripos($contentType, 'application/json') === false) {
        api_error(415, 'Content-Type must be application/json');
    }

    $raw = file_get_contents('php://input');
    if ($raw === '' || $raw === false) {
        api_error(400, 'Empty request body');
    }

    $data = json_decode($raw, true);
    if (!is_array($data)) {
        api_error(400, 'Invalid JSON in request body');
    }

    return $data;
}

// ── Atomic JSON update ──────────────────────────────────

/**
 * Read-modify-write a JSON file atomically.
 * Creates the file with an empty array if it doesn't exist.
 *
 * @param string   $file     Path to JSON file
 * @param callable $callback Receives current data (array), must return updated array
 * @return bool              True on success
 */
function atomic_json_update(string $file, callable $callback): bool {
    $data = [];
    if (file_exists($file)) {
        $raw = file_get_contents($file);
        if ($raw !== false && $raw !== '') {
            $data = json_decode($raw, true) ?? [];
        }
    }

    $data = $callback($data);

    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if ($json === false) {
        return false;
    }

    return file_put_contents($file, $json, LOCK_EX) !== false;
}

// ── ETag helpers ────────────────────────────────────────

/**
 * Set ETag/Last-Modified headers. Returns 304 if client cache is fresh.
 */
function api_etag(string $filePath): void {
    if (!file_exists($filePath)) {
        return;
    }

    $stat = stat($filePath);
    $etag = '"' . md5($stat['mtime'] . '-' . $stat['size']) . '"';
    $lastModified = gmdate('D, d M Y H:i:s', $stat['mtime']) . ' GMT';

    header("ETag: $etag");
    header("Last-Modified: $lastModified");
    header('Cache-Control: private, no-cache');

    $clientEtag = $_SERVER['HTTP_IF_NONE_MATCH'] ?? '';
    if ($clientEtag === $etag) {
        http_response_code(304);
        exit;
    }

    $clientModified = $_SERVER['HTTP_IF_MODIFIED_SINCE'] ?? '';
    if ($clientModified !== '' && strtotime($clientModified) >= $stat['mtime']) {
        http_response_code(304);
        exit;
    }
}

/**
 * Verify If-Match header for optimistic concurrency on writes.
 */
function api_check_if_match(string $filePath): void {
    $clientEtag = $_SERVER['HTTP_IF_MATCH'] ?? '';
    if ($clientEtag === '' || !file_exists($filePath)) {
        return;
    }

    $stat = stat($filePath);
    $currentEtag = '"' . md5($stat['mtime'] . '-' . $stat['size']) . '"';
    if ($clientEtag !== $currentEtag) {
        api_error(412, 'Precondition Failed — resource has been modified since last read');
    }
}

// ── Pagination helper ───────────────────────────────────

/**
 * Paginate an array. Supports both page-based (?page=&per_page=) and
 * offset-based (?offset=&limit=) pagination.
 *
 * @return array{0: array, 1: array} [sliced items, meta]
 */
function api_paginate(array $items, int $defaultLimit = 20, int $maxLimit = 100): array {
    $page    = isset($_GET['page']) ? max(1, (int)$_GET['page']) : null;
    $perPage = isset($_GET['per_page']) ? max(1, min((int)$_GET['per_page'], $maxLimit)) : null;
    $limit   = isset($_GET['limit']) ? max(1, min((int)$_GET['limit'], $maxLimit)) : null;
    $offset  = isset($_GET['offset']) ? max(0, (int)$_GET['offset']) : 0;

    if ($page !== null) {
        $effectiveLimit  = $perPage ?? $defaultLimit;
        $effectiveOffset = ($page - 1) * $effectiveLimit;
    } else {
        $effectiveLimit  = $limit ?? $defaultLimit;
        $effectiveOffset = $offset;
    }

    $total  = count($items);
    $sliced = array_slice($items, $effectiveOffset, $effectiveLimit);

    $meta = [
        'total'  => $total,
        'limit'  => $effectiveLimit,
        'offset' => $effectiveOffset,
    ];

    if ($page !== null) {
        $meta['page']        = $page;
        $meta['per_page']    = $effectiveLimit;
        $meta['total_pages'] = $effectiveLimit > 0 ? (int)ceil($total / $effectiveLimit) : 0;
    }

    return [$sliced, $meta];
}

// ── Sort helper ─────────────────────────────────────────

/**
 * Sort an array of items. Supports ?sort=-field (desc) or ?sort=field&order=asc.
 */
function api_sort(array $items, array $allowedFields, string $defaultField = 'createdAt', string $defaultOrder = 'desc'): array {
    $sortParam = $_GET['sort'] ?? '';

    if ($sortParam !== '' && str_starts_with($sortParam, '-')) {
        $field = substr($sortParam, 1);
        $order = 'desc';
    } elseif ($sortParam !== '') {
        $field = $sortParam;
        $order = $_GET['order'] ?? 'asc';
    } else {
        $field = $defaultField;
        $order = $_GET['order'] ?? $defaultOrder;
    }

    if (!in_array($field, $allowedFields, true)) {
        $field = $defaultField;
    }

    usort($items, function ($a, $b) use ($field, $order) {
        $va = $a[$field] ?? '';
        $vb = $b[$field] ?? '';
        $cmp = is_numeric($va) && is_numeric($vb)
            ? $va <=> $vb
            : strcasecmp((string)$va, (string)$vb);
        return $order === 'desc' ? -$cmp : $cmp;
    });

    return $items;
}

// ── Headers ─────────────────────────────────────────────
header('Content-Type: application/json; charset=utf-8');
header('X-API-Version: 1.0.0');

// CORS
$corsOrigins = defined('API_CORS_ORIGINS') ? API_CORS_ORIGINS : '*';
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';

if ($corsOrigins === '*') {
    header('Access-Control-Allow-Origin: *');
} elseif ($origin !== '') {
    $allowed = array_map('trim', explode(',', $corsOrigins));
    if (in_array($origin, $allowed, true)) {
        header("Access-Control-Allow-Origin: $origin");
        header('Vary: Origin');
    }
}

header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Authorization, Content-Type, If-None-Match, If-Match');
header('Access-Control-Expose-Headers: ETag, X-API-Version, X-RateLimit-Limit, X-RateLimit-Remaining, X-RateLimit-Reset');
header('Access-Control-Max-Age: 86400');

// ── OPTIONS preflight — no auth needed ──────────────────
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

// ── Parse URI (early, for pre-auth routes) ──────────────
$requestUri = $_SERVER['REQUEST_URI'] ?? '';
$path = parse_url($requestUri, PHP_URL_PATH);
$path = preg_replace('#^/api/v1/?#', '', $path);
$path = rtrim($path, '/');

$segments   = $path !== '' ? explode('/', $path) : [];
$resource   = $segments[0] ?? '';
$identifier = $segments[1] ?? null;
$method     = $_SERVER['REQUEST_METHOD'];

// ── Pre-auth routes ─────────────────────────────────────

// Health check (no auth required)
if ($resource === 'health') {
    require_once __DIR__ . '/handlers/health.php';
    handle_health($method);
}

// API discovery (no auth required)
if ($resource === '' && $method === 'GET') {
    api_success([
        'name'    => 'Stira CMS API',
        'version' => '1.0.0',
        'endpoints' => [
            'content'       => ['href' => '/api/v1/content',       'methods' => ['GET', 'PUT', 'PATCH']],
            'projects'      => ['href' => '/api/v1/projects',      'methods' => ['GET', 'POST', 'PUT', 'PATCH', 'DELETE']],
            'landing-pages' => ['href' => '/api/v1/landing-pages', 'methods' => ['GET', 'POST', 'PUT', 'PATCH', 'DELETE']],
            'seo'           => ['href' => '/api/v1/seo',           'methods' => ['GET', 'PUT']],
            'media'         => ['href' => '/api/v1/media',         'methods' => ['GET', 'POST', 'DELETE']],
            'navigation'    => ['href' => '/api/v1/navigation',    'methods' => ['GET', 'PUT']],
            'settings'      => ['href' => '/api/v1/settings',      'methods' => ['GET', 'PUT', 'PATCH']],
            'contacts'      => ['href' => '/api/v1/contacts',      'methods' => ['GET', 'POST', 'PATCH', 'DELETE']],
            'audit'         => ['href' => '/api/v1/audit',         'methods' => ['GET']],
            'health'        => ['href' => '/api/v1/health',        'methods' => ['GET']],
        ],
    ]);
}

// ── Auth ────────────────────────────────────────────────
api_authenticate();

// ── Rate limit ──────────────────────────────────────────
check_api_rate_limit();

// ── Route to handler ────────────────────────────────────
match($resource) {
    'content' => (function () use ($method, $identifier) {
        require_once __DIR__ . '/handlers/content.php';
        handle_content($method, $identifier);
    })(),

    'projects' => (function () use ($method, $identifier) {
        require_once __DIR__ . '/handlers/projects.php';
        handle_projects($method, $identifier);
    })(),

    'landing-pages' => (function () use ($method, $identifier) {
        require_once __DIR__ . '/handlers/landing-pages.php';
        handle_landing_pages($method, $identifier);
    })(),

    'seo' => (function () use ($method, $identifier) {
        require_once __DIR__ . '/handlers/seo.php';
        handle_seo($method, $identifier);
    })(),

    'media' => (function () use ($method, $identifier) {
        require_once __DIR__ . '/handlers/media.php';
        handle_media($method, $identifier);
    })(),

    'navigation' => (function () use ($method) {
        require_once __DIR__ . '/handlers/navigation.php';
        handle_navigation($method);
    })(),

    'settings' => (function () use ($method, $identifier) {
        require_once __DIR__ . '/handlers/settings.php';
        handle_settings($method, $identifier);
    })(),

    'contacts' => (function () use ($method, $identifier) {
        require_once __DIR__ . '/handlers/contacts.php';
        handle_contacts($method, $identifier);
    })(),

    'audit' => (function () use ($method) {
        require_once __DIR__ . '/handlers/audit.php';
        handle_audit($method);
    })(),

    default => api_error(404, "Unknown resource: $resource"),
};
