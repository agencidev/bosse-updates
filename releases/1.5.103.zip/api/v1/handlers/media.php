<?php
declare(strict_types=1);
/**
 * Media API Handler
 * Upload, list, get metadata, and delete files.
 */

define('MEDIA_REGISTRY', DATA_PATH . '/media.json');

function handle_media(string $method, ?string $identifier): void {
    match(true) {
        $method === 'GET' && $identifier === null   => media_list(),
        $method === 'GET' && $identifier !== null    => media_get($identifier),
        $method === 'POST' && $identifier === null   => media_upload(),
        $method === 'DELETE' && $identifier !== null  => media_delete($identifier),
        default => api_error(405, 'Method not allowed', allowed: 'GET, POST, DELETE'),
    };
}

function media_list(): void {
    api_etag(MEDIA_REGISTRY);

    $media = [];
    if (file_exists(MEDIA_REGISTRY)) {
        $media = json_decode(file_get_contents(MEDIA_REGISTRY), true) ?? [];
    }

    // Most recent first
    $media = array_reverse($media);

    [$items, $meta] = api_paginate($media);
    api_success($items, $meta);
}

function media_get(string $filename): void {
    api_etag(MEDIA_REGISTRY);

    $media = [];
    if (file_exists(MEDIA_REGISTRY)) {
        $media = json_decode(file_get_contents(MEDIA_REGISTRY), true) ?? [];
    }

    foreach ($media as $file) {
        if (($file['filename'] ?? '') === $filename) {
            api_success($file);
            return;
        }
    }

    api_error(404, "File '$filename' not found");
}

function media_upload(): void {
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    if (stripos($contentType, 'multipart/form-data') === false) {
        api_error(415, 'Content-Type must be multipart/form-data for file uploads');
    }

    if (!isset($_FILES['file']) || $_FILES['file']['error'] === UPLOAD_ERR_NO_FILE) {
        api_error(400, 'No file provided. Use form field name "file".');
    }

    $file = $_FILES['file'];

    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors = [
            UPLOAD_ERR_INI_SIZE   => 'File exceeds server size limit',
            UPLOAD_ERR_FORM_SIZE  => 'File exceeds form size limit',
            UPLOAD_ERR_PARTIAL    => 'File was only partially uploaded',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing temporary directory',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk',
        ];
        api_error(422, $errors[$file['error']] ?? 'Upload error');
    }

    $validation = validate_file_upload($file);
    if (!$validation['valid']) {
        api_error(422, 'File validation failed', ['file' => $validation['error']]);
    }

    $filename = generate_safe_filename($file['name'], $file['tmp_name']);
    $uploadPath = UPLOADS_PATH . '/' . $filename;

    if (!move_uploaded_file($file['tmp_name'], $uploadPath)) {
        api_error(500, 'Failed to save file');
    }

    // Optimize if image
    $mimeType = mime_content_type($uploadPath);
    if (str_starts_with($mimeType, 'image/')) {
        optimize_image($uploadPath);
    }

    $entry = [
        'filename'     => $filename,
        'originalName' => $file['name'],
        'url'          => '/uploads/' . $filename,
        'mimeType'     => mime_content_type($uploadPath),
        'size'         => filesize($uploadPath),
        'uploadedAt'   => date('c'),
    ];

    atomic_json_update(MEDIA_REGISTRY, function (array $data) use ($entry): array {
        $data[] = $entry;
        return $data;
    });

    audit_log('api.media.upload', "Uploaded: {$entry['originalName']} → {$filename}", 'api');
    api_success($entry, status: 201);
}

function media_delete(string $filename): void {
    // Prevent directory traversal
    if (preg_match('/[\/\\\\]/', $filename) || str_contains($filename, '..')) {
        api_error(400, 'Invalid filename');
    }

    $filePath = UPLOADS_PATH . '/' . $filename;
    if (!file_exists($filePath)) {
        api_error(404, "File '$filename' not found on disk");
    }

    // Remove from registry
    $found = false;
    atomic_json_update(MEDIA_REGISTRY, function (array $data) use ($filename, &$found): array {
        foreach ($data as $i => $entry) {
            if (($entry['filename'] ?? '') === $filename) {
                $found = true;
                array_splice($data, $i, 1);
                break;
            }
        }
        return $data;
    });

    unlink($filePath);

    audit_log('api.media.delete', "Deleted: $filename", 'api');
    api_success(null);
}
