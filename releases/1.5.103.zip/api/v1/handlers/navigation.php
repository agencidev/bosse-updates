<?php
declare(strict_types=1);
/**
 * Navigation API Handler
 * Manage header and footer navigation menus.
 *
 * Expected structure:
 * {
 *   "main": [
 *     { "label": "Analys", "url": null, "children": [
 *         { "label": "Analysverktyg", "url": "/analysverktyg" }
 *     ]},
 *     { "label": "Blogg", "url": "/blogg", "children": [] }
 *   ],
 *   "cta": { "label": "BOKA DEMO", "url": "/demo" },
 *   "footer": [
 *     { "heading": "Analys", "links": [
 *         { "label": "Analysverktyg", "url": "/analysverktyg" }
 *     ]}
 *   ]
 * }
 */

define('NAVIGATION_FILE', DATA_PATH . '/navigation.json');

function handle_navigation(string $method): void {
    match($method) {
        'GET'  => navigation_get(),
        'PUT'  => navigation_put(),
        default => api_error(405, 'Method not allowed', allowed: 'GET, PUT'),
    };
}

function navigation_get(): void {
    api_etag(NAVIGATION_FILE);

    $data = [];
    if (file_exists(NAVIGATION_FILE)) {
        $data = json_decode(file_get_contents(NAVIGATION_FILE), true) ?? [];
    }

    api_success($data);
}

function navigation_put(): void {
    api_check_if_match(NAVIGATION_FILE);

    $body = api_get_json_body();

    $errors = validate_navigation($body);
    if (!empty($errors)) {
        api_error(422, 'Validation failed', details: $errors);
    }

    $body = sanitize_nav_data($body);

    $ok = file_put_contents(
        NAVIGATION_FILE,
        json_encode($body, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE),
        LOCK_EX
    );

    if ($ok === false) {
        api_error(500, 'Failed to save navigation');
    }

    audit_log('api.navigation.put', 'Replaced navigation structure', 'api');
    api_success($body);
}

function validate_navigation(array $data): array {
    $errors = [];

    if (isset($data['main']) && !is_array($data['main'])) {
        $errors['main'] = 'main must be an array of menu items';
    }

    if (isset($data['main'])) {
        foreach ($data['main'] as $i => $item) {
            if (empty($item['label'])) {
                $errors["main[$i].label"] = 'Label is required';
            }
        }
    }

    if (isset($data['footer']) && !is_array($data['footer'])) {
        $errors['footer'] = 'footer must be an array of menu groups';
    }

    if (isset($data['cta'])) {
        if (empty($data['cta']['label'])) {
            $errors['cta.label'] = 'CTA label is required';
        }
        if (empty($data['cta']['url'])) {
            $errors['cta.url'] = 'CTA url is required';
        }
    }

    return $errors;
}

function sanitize_nav_data(array $data): array {
    foreach ($data as $k => $v) {
        if (is_string($v)) {
            $data[$k] = sanitize_text($v);
        } elseif (is_array($v)) {
            $data[$k] = sanitize_nav_data($v);
        }
    }
    return $data;
}
