<?php
declare(strict_types=1);
/**
 * Projects API Handler
 * Full CRUD on projects.json
 */

function handle_projects(string $method, ?string $identifier): void {
    $file = DATA_PATH . '/projects.json';

    match(true) {
        // GET /projects — list all (with filters)
        $method === 'GET' && $identifier === null => projects_list($file),

        // GET /projects/{id} — get one
        $method === 'GET' && $identifier !== null => projects_get($file, $identifier),

        // POST /projects — create new
        $method === 'POST' && $identifier === null => projects_create($file),

        // PUT /projects/{id} — replace
        $method === 'PUT' && $identifier !== null => projects_put($file, $identifier),

        // PATCH /projects/{id} — partial update
        $method === 'PATCH' && $identifier !== null => projects_patch($file, $identifier),

        // DELETE /projects/{id} — delete
        $method === 'DELETE' && $identifier !== null => projects_delete($file, $identifier),

        default => api_error(405, 'Method not allowed', allowed: 'GET, POST, PUT, PATCH, DELETE'),
    };
}

function projects_list(string $file): void {
    api_etag($file);

    $projects = [];
    if (file_exists($file)) {
        $projects = json_decode(file_get_contents($file), true) ?? [];
    }

    // Filters
    $status   = $_GET['status'] ?? null;
    $category = $_GET['category'] ?? null;
    $limit    = isset($_GET['limit']) ? max(1, (int)$_GET['limit']) : null;
    $offset   = isset($_GET['offset']) ? max(0, (int)$_GET['offset']) : 0;

    if ($status !== null) {
        $projects = array_filter($projects, fn($p) => ($p['status'] ?? '') === $status);
    }
    if ($category !== null) {
        $projects = array_filter($projects, fn($p) => ($p['category'] ?? '') === $category);
    }

    $total = count($projects);
    $projects = array_values($projects);

    // Sort (optional — ?sort=-createdAt or ?sort=title&order=asc)
    $projects = api_sort($projects, ['createdAt', 'updatedAt', 'title', 'category', 'status']);

    if ($offset > 0) {
        $projects = array_slice($projects, $offset);
    }
    if ($limit !== null) {
        $projects = array_slice($projects, 0, $limit);
    }

    api_success($projects, ['total' => $total, 'offset' => $offset, 'limit' => $limit]);
}

function projects_get(string $file, string $id): void {
    api_etag($file);

    $projects = [];
    if (file_exists($file)) {
        $projects = json_decode(file_get_contents($file), true) ?? [];
    }

    foreach ($projects as $project) {
        if (($project['id'] ?? '') === $id) {
            api_success($project);
            return;
        }
    }

    api_error(404, "Project '$id' not found");
}

function projects_create(string $file): void {
    $body = api_get_json_body();
    $errors = validate_project($body);
    if (!empty($errors)) {
        api_error(422, 'Validation failed', details: $errors);
    }

    $now = date('c');
    $project = [
        'id'        => uniqid('proj_', true),
        'slug'      => generateSlug($body['title']),
        'title'     => sanitize_text($body['title']),
        'category'  => sanitize_text($body['category'] ?? ''),
        'status'    => sanitize_text($body['status'] ?? 'draft'),
        'description' => isset($body['description']) ? sanitize_text($body['description']) : '',
        'image'     => isset($body['image']) ? sanitize_text($body['image']) : '',
        'url'       => isset($body['url']) ? sanitize_text($body['url']) : '',
        'createdAt' => $now,
        'updatedAt' => $now,
    ];

    // Preserve extra fields (sanitized)
    foreach ($body as $k => $v) {
        if (!isset($project[$k])) {
            $project[$k] = is_string($v) ? sanitize_text($v) : $v;
        }
    }

    $ok = atomic_json_update($file, function(array $data) use ($project): array {
        $data[] = $project;
        return $data;
    });

    if (!$ok) {
        api_error(500, 'Failed to save project');
    }

    audit_log('api.project.create', "Created project: {$project['title']}", 'api');
    api_success($project, status: 201);
}

function projects_put(string $file, string $id): void {
    $body = api_get_json_body();
    $errors = validate_project($body);
    if (!empty($errors)) {
        api_error(422, 'Validation failed', details: $errors);
    }

    $found = false;
    $result = null;

    $ok = atomic_json_update($file, function(array $data) use ($id, $body, &$found, &$result): array {
        foreach ($data as $i => $project) {
            if (($project['id'] ?? '') === $id) {
                $found = true;
                $result = [
                    'id'        => $id,
                    'slug'      => generateSlug($body['title']),
                    'title'     => sanitize_text($body['title']),
                    'category'  => sanitize_text($body['category'] ?? ''),
                    'status'    => sanitize_text($body['status'] ?? 'draft'),
                    'description' => isset($body['description']) ? sanitize_text($body['description']) : '',
                    'image'     => isset($body['image']) ? sanitize_text($body['image']) : '',
                    'url'       => isset($body['url']) ? sanitize_text($body['url']) : '',
                    'createdAt' => $project['createdAt'] ?? date('c'),
                    'updatedAt' => date('c'),
                ];
                foreach ($body as $k => $v) {
                    if (!isset($result[$k])) {
                        $result[$k] = is_string($v) ? sanitize_text($v) : $v;
                    }
                }
                $data[$i] = $result;
                break;
            }
        }
        return $data;
    });

    if (!$found) {
        api_error(404, "Project '$id' not found");
    }
    if (!$ok) {
        api_error(500, 'Failed to save project');
    }

    audit_log('api.project.put', "Replaced project: $id", 'api');
    api_success($result);
}

function projects_patch(string $file, string $id): void {
    $body = api_get_json_body();
    if (isset($body['title']) && !validate_text($body['title'], 1, 500)) {
        api_error(422, 'Validation failed', details: ['title' => 'Title must be 1-500 characters']);
    }

    $found = false;
    $result = null;

    $ok = atomic_json_update($file, function(array $data) use ($id, $body, &$found, &$result): array {
        foreach ($data as $i => $project) {
            if (($project['id'] ?? '') === $id) {
                $found = true;
                // Sanitize incoming values
                foreach ($body as $k => $v) {
                    if (is_string($v)) {
                        $body[$k] = sanitize_text($v);
                    }
                }
                // Shallow merge
                $data[$i] = array_merge($project, $body);
                $data[$i]['updatedAt'] = date('c');
                if (isset($body['title'])) {
                    $data[$i]['slug'] = generateSlug($body['title']);
                }
                $result = $data[$i];
                break;
            }
        }
        return $data;
    });

    if (!$found) {
        api_error(404, "Project '$id' not found");
    }
    if (!$ok) {
        api_error(500, 'Failed to save project');
    }

    audit_log('api.project.patch', "Updated project: $id", 'api');
    api_success($result);
}

function projects_delete(string $file, string $id): void {
    $found = false;

    $ok = atomic_json_update($file, function(array $data) use ($id, &$found): array {
        foreach ($data as $i => $project) {
            if (($project['id'] ?? '') === $id) {
                $found = true;
                array_splice($data, $i, 1);
                break;
            }
        }
        return $data;
    });

    if (!$found) {
        api_error(404, "Project '$id' not found");
    }
    if (!$ok) {
        api_error(500, 'Failed to delete project');
    }

    audit_log('api.project.delete', "Deleted project: $id", 'api');
    api_success(null);
}

function validate_project(array $data): array {
    $errors = [];
    if (empty($data['title']) || !validate_text($data['title'], 1, 500)) {
        $errors['title'] = 'Title is required (1-500 characters)';
    }
    return $errors;
}
