<?php
declare(strict_types=1);
/**
 * Audit Log API Handler
 * Read-only access to audit trail.
 */

function handle_audit(string $method): void {
    if ($method !== 'GET') {
        api_error(405, 'Method not allowed', allowed: 'GET');
    }

    $file = DATA_PATH . '/audit-log.json';
    api_etag($file);

    $entries = [];
    if (file_exists($file)) {
        $entries = json_decode(file_get_contents($file), true) ?? [];
    }

    // Filter by action prefix (e.g. ?action=api.project)
    $action = $_GET['action'] ?? null;
    if ($action !== null) {
        $entries = array_filter($entries, fn($e) => str_starts_with($e['action'] ?? '', $action));
        $entries = array_values($entries);
    }

    // Filter by user
    $user = $_GET['user'] ?? null;
    if ($user !== null) {
        $entries = array_filter($entries, fn($e) => ($e['user'] ?? '') === $user);
        $entries = array_values($entries);
    }

    // Most recent first
    $entries = array_reverse($entries);

    [$items, $meta] = api_paginate($entries, 50);
    api_success($items, $meta);
}
