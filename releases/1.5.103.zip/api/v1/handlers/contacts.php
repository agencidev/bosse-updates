<?php
declare(strict_types=1);
/**
 * Contacts API Handler
 * Manage contact form submissions.
 */

define('CONTACTS_FILE', DATA_PATH . '/contacts.json');

function handle_contacts(string $method, ?string $identifier): void {
    match(true) {
        $method === 'GET' && $identifier === null    => contacts_list(),
        $method === 'GET' && $identifier !== null     => contacts_get($identifier),
        $method === 'POST' && $identifier === null    => contacts_create(),
        $method === 'PATCH' && $identifier !== null   => contacts_patch($identifier),
        $method === 'DELETE' && $identifier !== null   => contacts_delete($identifier),
        default => api_error(405, 'Method not allowed', allowed: 'GET, POST, PATCH, DELETE'),
    };
}

function contacts_list(): void {
    api_etag(CONTACTS_FILE);

    $contacts = [];
    if (file_exists(CONTACTS_FILE)) {
        $contacts = json_decode(file_get_contents(CONTACTS_FILE), true) ?? [];
    }

    // Filters
    $read   = $_GET['read'] ?? null;
    $source = $_GET['source'] ?? null;

    if ($read !== null) {
        $isRead   = $read === 'true' || $read === '1';
        $contacts = array_filter($contacts, fn($c) => ($c['read'] ?? false) === $isRead);
    }
    if ($source !== null) {
        $contacts = array_filter($contacts, fn($c) => ($c['source'] ?? '') === $source);
    }

    $contacts = array_values($contacts);

    // Sort (newest first by default)
    $contacts = api_sort($contacts, ['createdAt', 'name', 'email', 'read'], 'createdAt', 'desc');

    [$items, $meta] = api_paginate($contacts);
    api_success($items, $meta);
}

function contacts_get(string $id): void {
    $contacts = [];
    if (file_exists(CONTACTS_FILE)) {
        $contacts = json_decode(file_get_contents(CONTACTS_FILE), true) ?? [];
    }

    foreach ($contacts as $contact) {
        if (($contact['id'] ?? '') === $id) {
            api_success($contact);
            return;
        }
    }

    api_error(404, "Contact '$id' not found");
}

function contacts_create(): void {
    $body = api_get_json_body();

    $errors = [];
    if (empty($body['name']) || !validate_text($body['name'], 1, 200)) {
        $errors['name'] = 'Name is required (1-200 characters)';
    }
    if (empty($body['email']) || !validate_email($body['email'])) {
        $errors['email'] = 'A valid email is required';
    }
    if (!empty($errors)) {
        api_error(422, 'Validation failed', details: $errors);
    }

    $contact = [
        'id'        => uniqid('msg_', true),
        'name'      => sanitize_text($body['name']),
        'email'     => sanitize_text($body['email']),
        'company'   => isset($body['company']) ? sanitize_text($body['company']) : '',
        'phone'     => isset($body['phone']) ? sanitize_text($body['phone']) : '',
        'message'   => isset($body['message']) ? sanitize_text($body['message']) : '',
        'source'    => isset($body['source']) ? sanitize_text($body['source']) : 'api',
        'ip'        => get_client_ip(),
        'read'      => false,
        'createdAt' => date('c'),
    ];

    $ok = atomic_json_update(CONTACTS_FILE, function (array $data) use ($contact): array {
        $data[] = $contact;
        return $data;
    });

    if (!$ok) {
        api_error(500, 'Failed to save contact');
    }

    audit_log('api.contact.create', "Contact from: {$contact['name']} <{$contact['email']}>", 'api');
    api_success($contact, status: 201);
}

function contacts_patch(string $id): void {
    $body = api_get_json_body();

    // Only allow updating specific fields
    $allowed  = ['read', 'notes'];
    $updates  = array_intersect_key($body, array_flip($allowed));

    if (empty($updates)) {
        api_error(422, 'No valid fields to update. Allowed: ' . implode(', ', $allowed));
    }

    $found  = false;
    $result = null;

    $ok = atomic_json_update(CONTACTS_FILE, function (array $data) use ($id, $updates, &$found, &$result): array {
        foreach ($data as $i => $contact) {
            if (($contact['id'] ?? '') === $id) {
                $found = true;
                foreach ($updates as $k => $v) {
                    $data[$i][$k] = is_string($v) ? sanitize_text($v) : $v;
                }
                $result = $data[$i];
                break;
            }
        }
        return $data;
    });

    if (!$found) {
        api_error(404, "Contact '$id' not found");
    }
    if (!$ok) {
        api_error(500, 'Failed to update contact');
    }

    audit_log('api.contact.patch', "Updated contact: $id", 'api');
    api_success($result);
}

function contacts_delete(string $id): void {
    $found = false;

    $ok = atomic_json_update(CONTACTS_FILE, function (array $data) use ($id, &$found): array {
        foreach ($data as $i => $contact) {
            if (($contact['id'] ?? '') === $id) {
                $found = true;
                array_splice($data, $i, 1);
                break;
            }
        }
        return $data;
    });

    if (!$found) {
        api_error(404, "Contact '$id' not found");
    }
    if (!$ok) {
        api_error(500, 'Failed to delete contact');
    }

    audit_log('api.contact.delete', "Deleted contact: $id", 'api');
    api_success(null);
}
