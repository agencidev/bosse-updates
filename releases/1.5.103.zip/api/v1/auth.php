<?php
declare(strict_types=1);
/**
 * API Authentication
 * Bearer token validation via API_KEY
 */

/**
 * Validate Bearer token from Authorization header.
 * Returns true if valid, sends 401 and exits on failure.
 */
function api_authenticate(): void {
    $header = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';

    if (!preg_match('/^Bearer\s+([a-fA-F0-9]{64})$/', $header, $matches)) {
        api_error(401, 'Invalid or missing Bearer token');
    }

    $token = $matches[1];
    $expected = defined('API_KEY') ? API_KEY : '';

    if ($expected === '' || !hash_equals($expected, $token)) {
        audit_log('api.auth_failed', 'Invalid API key attempt', 'anonymous');
        api_error(401, 'Invalid API key');
    }
}
