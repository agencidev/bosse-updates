<?php
declare(strict_types=1);
/**
 * API Rate Limiting
 * Per-IP rate limiting with JSON file storage
 */

define('API_RATE_LIMIT_FILE', DATA_PATH . '/api_rate_limits.json');

/**
 * Check and enforce API rate limit for current IP.
 * Sends rate limit headers on every request.
 * Returns 429 and exits if limit exceeded.
 */
function check_api_rate_limit(): void {
    $limit  = defined('API_RATE_LIMIT') ? (int)API_RATE_LIMIT : 60;
    $window = defined('API_RATE_WINDOW') ? (int)API_RATE_WINDOW : 60;
    $ip     = get_client_ip();
    $now    = time();

    // Read current rate data
    $data = [];
    if (file_exists(API_RATE_LIMIT_FILE)) {
        $data = json_decode(file_get_contents(API_RATE_LIMIT_FILE), true) ?? [];
    }

    // Clean expired entries
    foreach ($data as $stored_ip => $entry) {
        if ($now - $entry['window_start'] >= $window) {
            unset($data[$stored_ip]);
        }
    }

    // Get or create entry for this IP
    if (!isset($data[$ip]) || ($now - $data[$ip]['window_start'] >= $window)) {
        $data[$ip] = [
            'count'        => 0,
            'window_start' => $now,
        ];
    }

    $data[$ip]['count']++;
    $remaining = max(0, $limit - $data[$ip]['count']);
    $reset     = $data[$ip]['window_start'] + $window;

    // Save updated data
    file_put_contents(
        API_RATE_LIMIT_FILE,
        json_encode($data, JSON_PRETTY_PRINT),
        LOCK_EX
    );

    // Always send rate limit headers
    header("X-RateLimit-Limit: $limit");
    header("X-RateLimit-Remaining: $remaining");
    header("X-RateLimit-Reset: $reset");

    if ($data[$ip]['count'] > $limit) {
        $retryAfter = $reset - $now;
        header("Retry-After: $retryAfter");
        api_error(429, 'Rate limit exceeded. Try again in ' . $retryAfter . ' seconds');
    }
}
