<?php
/**
 * Analytics Data Access Layer
 * SQLite-baserad besöksstatistik med lazy singleton PDO
 */

/**
 * Get or create analytics SQLite PDO connection (lazy singleton)
 */
function get_analytics_db(): PDO {
    static $pdo = null;
    if ($pdo !== null) {
        return $pdo;
    }

    $dbPath = DATA_PATH . '/analytics.db';

    $pdo = new PDO('sqlite:' . $dbPath, null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    $pdo->exec('PRAGMA journal_mode=WAL');
    $pdo->exec('PRAGMA busy_timeout=5000');

    // Create tables if not exists
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS sessions (
            id TEXT PRIMARY KEY,
            visitor_id TEXT NOT NULL,
            ip_hash TEXT,
            user_agent TEXT,
            device_type TEXT,
            browser TEXT,
            os TEXT,
            screen_width INTEGER,
            screen_height INTEGER,
            referrer TEXT,
            referrer_domain TEXT,
            utm_source TEXT,
            utm_medium TEXT,
            utm_campaign TEXT,
            landing_page TEXT,
            exit_page TEXT,
            page_count INTEGER DEFAULT 1,
            duration INTEGER DEFAULT 0,
            is_bounce INTEGER DEFAULT 1,
            started_at TEXT DEFAULT (datetime('now')),
            ended_at TEXT DEFAULT (datetime('now'))
        )
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS pageviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            visitor_id TEXT NOT NULL,
            path TEXT NOT NULL,
            title TEXT,
            scroll_depth INTEGER DEFAULT 0,
            time_on_page INTEGER DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now'))
        )
    ");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS clicks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            session_id TEXT NOT NULL,
            path TEXT NOT NULL,
            x_percent REAL NOT NULL,
            y_percent REAL NOT NULL,
            element_tag TEXT,
            element_text TEXT,
            viewport_width INTEGER,
            page_height INTEGER,
            created_at TEXT DEFAULT (datetime('now'))
        )
    ");

    // Create indexes (IF NOT EXISTS)
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_sessions_started ON sessions(started_at)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_sessions_visitor ON sessions(visitor_id)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_pageviews_created ON pageviews(created_at)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_pageviews_path ON pageviews(path)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_clicks_path ON clicks(path)");
    $pdo->exec("CREATE INDEX IF NOT EXISTS idx_clicks_created ON clicks(created_at)");

    return $pdo;
}

/**
 * Record a new session
 */
function analytics_create_session(array $data): void {
    $db = get_analytics_db();
    $stmt = $db->prepare("
        INSERT OR IGNORE INTO sessions (id, visitor_id, ip_hash, user_agent, device_type, browser, os,
            screen_width, screen_height, referrer, referrer_domain,
            utm_source, utm_medium, utm_campaign, landing_page)
        VALUES (:id, :visitor_id, :ip_hash, :user_agent, :device_type, :browser, :os,
            :screen_width, :screen_height, :referrer, :referrer_domain,
            :utm_source, :utm_medium, :utm_campaign, :landing_page)
    ");
    $stmt->execute([
        ':id' => $data['session_id'],
        ':visitor_id' => $data['visitor_id'],
        ':ip_hash' => $data['ip_hash'] ?? '',
        ':user_agent' => $data['user_agent'] ?? '',
        ':device_type' => $data['device_type'] ?? 'desktop',
        ':browser' => $data['browser'] ?? '',
        ':os' => $data['os'] ?? '',
        ':screen_width' => $data['screen_width'] ?? 0,
        ':screen_height' => $data['screen_height'] ?? 0,
        ':referrer' => $data['referrer'] ?? '',
        ':referrer_domain' => $data['referrer_domain'] ?? '',
        ':utm_source' => $data['utm_source'] ?? '',
        ':utm_medium' => $data['utm_medium'] ?? '',
        ':utm_campaign' => $data['utm_campaign'] ?? '',
        ':landing_page' => $data['landing_page'] ?? '',
    ]);
}

/**
 * Record a pageview
 */
function analytics_record_pageview(array $data): void {
    $db = get_analytics_db();

    $stmt = $db->prepare("
        INSERT INTO pageviews (session_id, visitor_id, path, title)
        VALUES (:session_id, :visitor_id, :path, :title)
    ");
    $stmt->execute([
        ':session_id' => $data['session_id'],
        ':visitor_id' => $data['visitor_id'],
        ':path' => $data['path'],
        ':title' => $data['title'] ?? '',
    ]);

    // Update session: page_count, exit_page, is_bounce, ended_at
    $db->prepare("
        UPDATE sessions SET
            page_count = page_count + 1,
            exit_page = :path,
            is_bounce = CASE WHEN page_count >= 1 THEN 0 ELSE 1 END,
            ended_at = datetime('now')
        WHERE id = :session_id
    ")->execute([':path' => $data['path'], ':session_id' => $data['session_id']]);
}

/**
 * Update pageview with scroll depth and time on page (heartbeat)
 */
function analytics_heartbeat(array $data): void {
    $db = get_analytics_db();

    // Update the latest pageview for this session+path
    $stmt = $db->prepare("
        UPDATE pageviews SET
            scroll_depth = MAX(scroll_depth, :scroll_depth),
            time_on_page = :time_on_page
        WHERE id = (
            SELECT id FROM pageviews
            WHERE session_id = :session_id AND path = :path
            ORDER BY created_at DESC LIMIT 1
        )
    ");
    $stmt->execute([
        ':scroll_depth' => $data['scroll_depth'] ?? 0,
        ':time_on_page' => $data['time_on_page'] ?? 0,
        ':session_id' => $data['session_id'],
        ':path' => $data['path'],
    ]);

    // Update session duration
    $db->prepare("
        UPDATE sessions SET
            duration = CAST((julianday('now') - julianday(started_at)) * 86400 AS INTEGER),
            ended_at = datetime('now')
        WHERE id = :session_id
    ")->execute([':session_id' => $data['session_id']]);
}

/**
 * Record click events (batch)
 */
function analytics_record_clicks(string $sessionId, string $path, array $clicks): void {
    $db = get_analytics_db();
    $stmt = $db->prepare("
        INSERT INTO clicks (session_id, path, x_percent, y_percent, element_tag, element_text, viewport_width, page_height)
        VALUES (:session_id, :path, :x, :y, :tag, :text, :vw, :ph)
    ");

    foreach ($clicks as $click) {
        $stmt->execute([
            ':session_id' => $sessionId,
            ':path' => $path,
            ':x' => $click['x'] ?? 0,
            ':y' => $click['y'] ?? 0,
            ':tag' => substr($click['tag'] ?? '', 0, 50),
            ':text' => substr($click['text'] ?? '', 0, 100),
            ':vw' => $click['vw'] ?? 0,
            ':ph' => $click['ph'] ?? 0,
        ]);
    }
}

// ── Query functions for dashboard/analytics ──

/**
 * Get overview stats for a date range
 */
function analytics_overview(string $from, string $to): array {
    $db = get_analytics_db();

    $visitors = $db->prepare("SELECT COUNT(DISTINCT visitor_id) FROM sessions WHERE started_at >= :from AND started_at < :to");
    $visitors->execute([':from' => $from, ':to' => $to]);
    $visitorCount = (int) $visitors->fetchColumn();

    $pageviews = $db->prepare("SELECT COUNT(*) FROM pageviews WHERE created_at >= :from AND created_at < :to");
    $pageviews->execute([':from' => $from, ':to' => $to]);
    $pageviewCount = (int) $pageviews->fetchColumn();

    $sessions = $db->prepare("SELECT COUNT(*) FROM sessions WHERE started_at >= :from AND started_at < :to");
    $sessions->execute([':from' => $from, ':to' => $to]);
    $sessionCount = (int) $sessions->fetchColumn();

    $bounce = $db->prepare("SELECT COALESCE(AVG(is_bounce) * 100, 0) FROM sessions WHERE started_at >= :from AND started_at < :to");
    $bounce->execute([':from' => $from, ':to' => $to]);
    $bounceRate = round((float) $bounce->fetchColumn(), 1);

    $avgDuration = $db->prepare("SELECT COALESCE(AVG(duration), 0) FROM sessions WHERE started_at >= :from AND started_at < :to AND duration > 0");
    $avgDuration->execute([':from' => $from, ':to' => $to]);
    $avgTime = round((float) $avgDuration->fetchColumn());

    $pagesPerSession = $sessionCount > 0 ? round($pageviewCount / $sessionCount, 1) : 0;

    return [
        'visitors' => $visitorCount,
        'pageviews' => $pageviewCount,
        'sessions' => $sessionCount,
        'bounce_rate' => $bounceRate,
        'avg_duration' => $avgTime,
        'pages_per_session' => $pagesPerSession,
    ];
}

/**
 * Get timeseries data (visitors + pageviews per day)
 */
function analytics_timeseries(string $from, string $to): array {
    $db = get_analytics_db();
    $stmt = $db->prepare("
        SELECT date(started_at) as day,
               COUNT(DISTINCT visitor_id) as visitors,
               0 as pageviews
        FROM sessions
        WHERE started_at >= :from AND started_at < :to
        GROUP BY date(started_at)
        ORDER BY day
    ");
    $stmt->execute([':from' => $from, ':to' => $to]);
    $sessionData = [];
    while ($row = $stmt->fetch()) {
        $sessionData[$row['day']] = (int) $row['visitors'];
    }

    $stmt2 = $db->prepare("
        SELECT date(created_at) as day, COUNT(*) as cnt
        FROM pageviews
        WHERE created_at >= :from AND created_at < :to
        GROUP BY date(created_at)
    ");
    $stmt2->execute([':from' => $from, ':to' => $to]);
    $pvData = [];
    while ($row = $stmt2->fetch()) {
        $pvData[$row['day']] = (int) $row['cnt'];
    }

    // Build full date range
    $result = [];
    $current = new DateTime($from);
    $end = new DateTime($to);
    while ($current < $end) {
        $day = $current->format('Y-m-d');
        $result[] = [
            'day' => $day,
            'visitors' => $sessionData[$day] ?? 0,
            'pageviews' => $pvData[$day] ?? 0,
        ];
        $current->modify('+1 day');
    }

    return $result;
}

/**
 * Get top pages
 */
function analytics_top_pages(string $from, string $to, int $limit = 10): array {
    $db = get_analytics_db();
    $stmt = $db->prepare("
        SELECT path, COUNT(*) as views, COALESCE(AVG(time_on_page), 0) as avg_time
        FROM pageviews
        WHERE created_at >= :from AND created_at < :to
        GROUP BY path
        ORDER BY views DESC
        LIMIT :limit
    ");
    $stmt->bindValue(':from', $from);
    $stmt->bindValue(':to', $to);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

/**
 * Get traffic sources (referrer domains)
 */
function analytics_sources(string $from, string $to, int $limit = 10): array {
    $db = get_analytics_db();
    $stmt = $db->prepare("
        SELECT CASE WHEN referrer_domain = '' THEN 'Direkt' ELSE referrer_domain END as source,
               COUNT(*) as sessions
        FROM sessions
        WHERE started_at >= :from AND started_at < :to
        GROUP BY source
        ORDER BY sessions DESC
        LIMIT :limit
    ");
    $stmt->bindValue(':from', $from);
    $stmt->bindValue(':to', $to);
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

/**
 * Get device/browser/OS breakdown
 */
function analytics_devices(string $from, string $to): array {
    $db = get_analytics_db();

    $devices = $db->prepare("
        SELECT device_type, COUNT(*) as cnt FROM sessions
        WHERE started_at >= :from AND started_at < :to
        GROUP BY device_type ORDER BY cnt DESC
    ");
    $devices->execute([':from' => $from, ':to' => $to]);

    $browsers = $db->prepare("
        SELECT browser, COUNT(*) as cnt FROM sessions
        WHERE started_at >= :from AND started_at < :to AND browser != ''
        GROUP BY browser ORDER BY cnt DESC LIMIT 5
    ");
    $browsers->execute([':from' => $from, ':to' => $to]);

    $oses = $db->prepare("
        SELECT os, COUNT(*) as cnt FROM sessions
        WHERE started_at >= :from AND started_at < :to AND os != ''
        GROUP BY os ORDER BY cnt DESC LIMIT 5
    ");
    $oses->execute([':from' => $from, ':to' => $to]);

    return [
        'devices' => $devices->fetchAll(),
        'browsers' => $browsers->fetchAll(),
        'os' => $oses->fetchAll(),
    ];
}

/**
 * Get UTM campaign data
 */
function analytics_campaigns(string $from, string $to): array {
    $db = get_analytics_db();
    $stmt = $db->prepare("
        SELECT utm_source, utm_medium, utm_campaign,
               COUNT(DISTINCT visitor_id) as visitors,
               COUNT(*) as sessions,
               COALESCE(AVG(is_bounce) * 100, 0) as bounce_rate
        FROM sessions
        WHERE started_at >= :from AND started_at < :to AND utm_source != ''
        GROUP BY utm_source, utm_medium, utm_campaign
        ORDER BY visitors DESC
        LIMIT 20
    ");
    $stmt->execute([':from' => $from, ':to' => $to]);
    return $stmt->fetchAll();
}

/**
 * Get heatmap click data for a specific path
 */
function analytics_heatmap(string $path, string $from, string $to): array {
    $db = get_analytics_db();

    $count = $db->prepare("SELECT COUNT(*) FROM clicks WHERE path = :path AND created_at >= :from AND created_at < :to");
    $count->execute([':path' => $path, ':from' => $from, ':to' => $to]);
    $total = (int) $count->fetchColumn();

    // If >1000 clicks, aggregate to grid
    if ($total > 1000) {
        $stmt = $db->prepare("
            SELECT ROUND(x_percent, 0) as x, ROUND(y_percent, 0) as y, COUNT(*) as count
            FROM clicks
            WHERE path = :path AND created_at >= :from AND created_at < :to
            GROUP BY ROUND(x_percent, 0), ROUND(y_percent, 0)
            ORDER BY count DESC
        ");
    } else {
        $stmt = $db->prepare("
            SELECT x_percent as x, y_percent as y, element_tag as tag, element_text as text,
                   viewport_width as vw, page_height as ph
            FROM clicks
            WHERE path = :path AND created_at >= :from AND created_at < :to
            ORDER BY created_at DESC
        ");
    }
    $stmt->execute([':path' => $path, ':from' => $from, ':to' => $to]);

    return [
        'total' => $total,
        'aggregated' => $total > 1000,
        'clicks' => $stmt->fetchAll(),
    ];
}

/**
 * Get distinct paths that have click data (for heatmap dropdown)
 */
function analytics_heatmap_pages(): array {
    $db = get_analytics_db();
    $stmt = $db->query("SELECT DISTINCT path, COUNT(*) as clicks FROM clicks GROUP BY path ORDER BY clicks DESC LIMIT 50");
    return $stmt->fetchAll();
}

/**
 * Get realtime active visitors (sessions active in last 5 minutes)
 */
function analytics_realtime(): array {
    $db = get_analytics_db();
    $stmt = $db->prepare("
        SELECT COUNT(DISTINCT visitor_id) as active_visitors,
               COUNT(DISTINCT id) as active_sessions
        FROM sessions
        WHERE ended_at >= datetime('now', '-5 minutes')
    ");
    $stmt->execute();
    $counts = $stmt->fetch();

    $pages = $db->prepare("
        SELECT p.path, COUNT(*) as cnt
        FROM pageviews p
        JOIN sessions s ON s.id = p.session_id
        WHERE s.ended_at >= datetime('now', '-5 minutes')
        AND p.created_at >= datetime('now', '-5 minutes')
        GROUP BY p.path ORDER BY cnt DESC LIMIT 5
    ");
    $pages->execute();

    return [
        'active_visitors' => (int) ($counts['active_visitors'] ?? 0),
        'active_sessions' => (int) ($counts['active_sessions'] ?? 0),
        'pages' => $pages->fetchAll(),
    ];
}

/**
 * Get recent visitors timeline
 */
function analytics_visitors_timeline(int $limit = 50): array {
    $db = get_analytics_db();
    $stmt = $db->prepare("
        SELECT s.visitor_id, s.device_type, s.browser, s.os, s.referrer_domain,
               s.landing_page, s.page_count, s.duration, s.started_at,
               GROUP_CONCAT(p.path, ' > ') as pages
        FROM sessions s
        LEFT JOIN pageviews p ON p.session_id = s.id
        GROUP BY s.id
        ORDER BY s.started_at DESC
        LIMIT :limit
    ");
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll();
}

/**
 * Purge data older than N days
 */
function analytics_purge(int $days = 90): int {
    $db = get_analytics_db();
    $cutoff = date('Y-m-d H:i:s', strtotime("-{$days} days"));

    $db->prepare("DELETE FROM clicks WHERE created_at < :cutoff")->execute([':cutoff' => $cutoff]);
    $db->prepare("DELETE FROM pageviews WHERE created_at < :cutoff")->execute([':cutoff' => $cutoff]);
    $stmt = $db->prepare("DELETE FROM sessions WHERE started_at < :cutoff");
    $stmt->execute([':cutoff' => $cutoff]);

    $db->exec("PRAGMA optimize");

    return $stmt->rowCount();
}
