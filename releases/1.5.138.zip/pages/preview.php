<?php
/**
 * Preview — visar draft-inlägg med sajtens riktiga design
 * Kräver inloggning. Data hämtas från session (sparad via CMS).
 */
ini_set('display_errors', 1);
error_reporting(E_ALL);
require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../security/session.php';
if (file_exists(__DIR__ . '/../security/validation.php')) {
    require_once __DIR__ . '/../security/validation.php';
}
require_once __DIR__ . '/../cms/content.php';
require_once __DIR__ . '/../seo/meta.php';
if (file_exists(__DIR__ . '/../seo/schema.php')) {
    require_once __DIR__ . '/../seo/schema.php';
}

// Only logged-in admins can preview
if (!is_logged_in()) {
    http_response_code(404);
    exit;
}

$project = $_SESSION['preview_draft'] ?? null;
if (!$project) {
    echo '<p style="padding:2rem;text-align:center;font-family:sans-serif;">Ingen förhandsvisning tillgänglig. Gå tillbaka och klicka "Förhandsgranska".</p>';
    exit;
}

$_uri_prefix = '/inlagg';
$_back_label = 'Tillbaka';
?>
<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php
    generateMeta(
        ($project['title'] ?? 'Förhandsvisning') . ' — Förhandsvisning',
        $project['summary'] ?? '',
        $project['coverImage'] ?? '/assets/images/og-image.jpg'
    );
    ?>
    <meta name="robots" content="noindex, nofollow">

    <?php if (file_exists(__DIR__ . '/../assets/images/favicon.png')): ?>
    <link rel="icon" type="image/png" href="/assets/images/favicon.png">
    <?php endif; ?>
    <link rel="stylesheet" href="/assets/css/main.css?v=<?php echo BOSSE_VERSION; ?>">
    <?php
    if (file_exists(__DIR__ . '/../assets/css/inlagg-single-custom.css')) {
        echo '<link rel="stylesheet" href="/assets/css/inlagg-single-custom.css?v=' . BOSSE_VERSION . '">';
    } else {
        echo '<link rel="stylesheet" href="/assets/css/inlagg-single-default.css?v=' . BOSSE_VERSION . '">';
    }
    ?>
    <?php if (file_exists(__DIR__ . '/../includes/fonts.php')) include __DIR__ . '/../includes/fonts.php'; ?>

    <style>
    .preview-banner {
        background: #f59e0b;
        color: #000;
        text-align: center;
        padding: 0.5rem 1rem;
        font-size: 0.8125rem;
        font-weight: 600;
        position: sticky;
        top: 0;
        z-index: 10001;
    }
    .preview-banner a {
        color: #000;
        margin-left: 1rem;
        text-decoration: underline;
    }
    </style>
</head>
<body>
    <?php include __DIR__ . '/../includes/admin-bar.php'; ?>

    <div class="preview-banner">
        Förhandsvisning — detta är inte publicerat
        <a href="javascript:window.close();">Stäng</a>
    </div>

    <?php include __DIR__ . '/../includes/header.php'; ?>

    <main id="main-content">
        <article class="projekt-single">
            <div class="projekt-single__container" style="max-width: 800px; margin: 0 auto; padding: 0 1.5rem;">
                <a href="<?php echo htmlspecialchars($_uri_prefix); ?>" class="projekt-single__back">
                    &larr; <?php echo htmlspecialchars($_back_label); ?>
                </a>

                <?php if (!empty($project['category'])): ?>
                    <span class="projekt-single__category"><?php echo htmlspecialchars($project['category']); ?></span>
                <?php endif; ?>

                <h1 class="projekt-single__title"><?php echo htmlspecialchars($project['title'] ?? 'Utan titel', ENT_QUOTES, 'UTF-8'); ?></h1>

                <div class="projekt-single__meta">
                    <span><?php echo date('j M Y'); ?></span>
                </div>

                <?php if (!empty($project['coverImage'])): ?>
                    <img src="<?php echo htmlspecialchars($project['coverImage'], ENT_QUOTES, 'UTF-8'); ?>"
                         alt="<?php echo htmlspecialchars($project['title'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                         class="projekt-single__cover" fetchpriority="high"
                         width="1200" height="675" style="aspect-ratio:16/9;object-fit:cover;width:100%;height:auto;">
                <?php endif; ?>

                <div class="projekt-single__content">
                    <?php if (!empty($project['summary'])): ?>
                        <p class="projekt-single__summary"><?php echo htmlspecialchars($project['summary'], ENT_QUOTES, 'UTF-8'); ?></p>
                    <?php endif; ?>

                    <?php if (!empty($project['content'])): ?>
                        <div class="projekt-single__body">
                            <?php echo function_exists('sanitize_rich_content') ? sanitize_rich_content($project['content']) : $project['content']; ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </article>
    </main>

    <?php include __DIR__ . '/../includes/footer.php'; ?>
</body>
</html>
