# CLAUDE.md

Se `.rules/ai-rules.md` för fullständiga AI-regler och kodstandarder.
Se `.rules/brand-guide.md` för varumärkesguide (färger, typsnitt, tonalitet).

## ⛔ CORE-FILER — RÖR INTE!

Dessa filer/mappar tillhör Bosse-ramverket och skrivs över vid uppdatering:
`bootstrap.php`, `router.php`, `setup.php`, `bosse-health.php`, `cms/`, `security/`, `bin/`, `seo/`, `api/`, `includes/admin-bar.php`, `includes/cookie-consent.php`, `includes/mailer.php`, `assets/css/variables.css`, `assets/css/components.css`, `assets/js/cms.js`, `assets/js/tracker.js`, `includes/peys-badge.php`, `cms/analytics.php`, `cms/analytics-db.php`, `cms/analytics-collect.php`

**Du får ändra:** `index.php` (startsidan), `pages/errors/` (felsidor), `assets/css/overrides.css`, `assets/css/inlagg-custom.css`, `assets/css/inlagg-single-custom.css`, `includes/header.php`, `includes/footer.php`, sidor i `pages/`, `cms/extensions/routes.php`, `data/content.json`, `data/projects.json`, `uploads/`

Se `.rules/ai-rules.md` → "CORE vs SAFE" för komplett lista.

## ⚠️ KRITISKT — Läs först!

### STOPP! Inlägg/nyheter/event/projekt — MÅSTE gå via `data/projects.json`

**ALDRIG** skapa inlägg genom att:
- Hårdkoda HTML/PHP i `index.php` eller andra PHP-filer
- Skapa nya PHP-filer för enskilda inlägg
- Lägga innehåll i `data/content.json` (det är för sidinnehåll, INTE inlägg)

**ALLTID** följ dessa steg exakt:

1. **Läs** `data/projects.json` med Read-verktyget
2. **Lägg till** ett nytt objekt i arrayen med ALLA obligatoriska fält (se nedan)
3. **Skriv tillbaka** hela arrayen till `data/projects.json`
4. **Verifiera** att filen är giltig JSON (`php -r "json_decode(file_get_contents('data/projects.json')) ?: exit(1);"`)

**Obligatoriska fält** (saknas något visas inlägget INTE korrekt):
```json
{
  "id": "unikt-id-2026",
  "title": "Titel på inlägget",
  "slug": "url-vänlig-slug",
  "category": "Inlägg",
  "summary": "Kort beskrivning (visas i listvy)",
  "content": "Fullständig text (HTML tillåtet)",
  "status": "published",
  "coverImage": "/uploads/bild.jpg",
  "gallery": [],
  "displayDate": "2026-04-15 18:00:00",
  "createdAt": "2026-03-02 12:00:00"
}
```

**Viktigt:**
- `status` MÅSTE vara `"published"` för att synas publikt
- `slug` MÅSTE vara unik — den blir URL:en (`/inlagg/min-slug`)
- `id` MÅSTE vara unik — används av CMS:et för redigering
- `category` styr vilken kategorisida inlägget visas på — matchar mot `pages.php`-konfiguration (se "Kategori- och innehållssidor" nedan)
- `displayDate` — valfritt, visas istället för `createdAt` om satt (t.ex. eventdatum)
- Inlägget syns automatiskt i CMS-admin (`/projects`) och publikt — ingen extra konfiguration behövs

## Snabbref

### Nya sidor (VIKTIGT!)
När du skapar nya sidor (om-oss.php, tjanster.php etc.):
1. **Skapa filen i `pages/`-mappen** (t.ex. `pages/om-oss.php`)
2. **Kopiera** `templates/page-template.php` som bas
3. **MÅSTE inkludera:** `header.php` och `footer.php` med `__DIR__ . '/../'`-prefix
4. **Lägg till rutt** i `cms/extensions/routes.php`

```php
// Minsta struktur för ny sida i pages/:
<?php include __DIR__ . '/../includes/admin-bar.php'; ?>
<?php include __DIR__ . '/../includes/header.php'; ?>
<main id="main-content">
    <!-- Innehåll -->
</main>
<?php include __DIR__ . '/../includes/footer.php'; ?>
```

### CSS-ändringar
- **Skriv alltid i:** `assets/css/overrides.css`
- **Ändra ALDRIG:** `variables.css` eller `components.css`
- **Egen design för inlägg:** Skapa `assets/css/inlagg-custom.css` (listvy) eller `assets/css/inlagg-single-custom.css` (enskild vy) — dessa filer finns **inte** i template som standard, utan skapas vid behov. När filen finns **ersätter** den `inlagg-default.css` / `inlagg-single-default.css` helt. SAFE-filer som överlever uppdateringar

### Innehåll
- **Sidinnehåll:** `data/content.json`
- **Inlägg/projekt:** `data/projects.json` (status: `"published"` för att synas)

### Nya sektioner
Använd ALLTID `editable_text()` och `editable_image()` för redigerbart innehåll:

```php
<?php editable_text('sektion', 'titel', 'Standardrubrik', 'h2', 'css-klass'); ?>
<?php editable_text('sektion', 'text', 'Standardtext', 'p', 'css-klass'); ?>
<?php editable_image('sektion', 'bild', '/uploads/placeholder.jpg', 'Alt-text', 'css-klass'); ?>
```

### SEO i meta-taggar — använd `get_content_raw()`
`generateMeta()` kör egen `htmlspecialchars()`. Använd `get_content_raw()` (inte `get_content()`) för att undvika dubbel-escaping:

```php
generateMeta(
    get_content_raw('sida.meta_title', 'Standardtitel'),
    get_content_raw('sida.meta_description', 'Standardbeskrivning'),
    '/assets/images/og-image.jpg'
);
```

SEO-metadata per sida hanteras i CMS-admin under `/seo`.

### Projekt/Inlägg-format
```json
{
  "id": "unikt-id",
  "title": "Titel",
  "slug": "url-slug",
  "category": "Inlägg",
  "summary": "Kort beskrivning",
  "content": "Fullständig text",
  "status": "published|draft",
  "coverImage": "/uploads/bild.jpg",
  "displayDate": "2026-04-15 18:00:00",
  "createdAt": "2026-02-04 12:00:00"
}
```

**`displayDate`** — Valfritt datum som visas publikt (t.ex. eventdatum). Om tomt används `createdAt`. Sorterar inlägg efter `displayDate` om satt.

### Kategori- och innehållssidor

Bosse separerar **kategorier** (etiketter på inlägg) och **kategorisidor** (URL-routade listsidor). En sida kan visa inlägg från flera kategorier.

Konfigureras via CMS-admin (`/categories`) eller genom att redigera **2 filer**:

#### `cms/extensions/categories.php` — Kategorietiketter
```php
return ['Inlägg', 'Nyheter', 'Event', 'Blogg'];
```

#### `cms/extensions/pages.php` — Kategorisidor (multi-kategori)
```php
return [
    '/inlagg' => ['title_sv' => 'Inlägg', 'title_en' => 'Posts', 'categories' => ['Inlägg'], 'base_url' => '/inlagg'],
    '/happenings' => ['title_sv' => 'Happenings', 'title_en' => 'Happenings', 'categories' => ['Nyheter', 'Event'], 'base_url' => '/happenings'],
];
```

Routes i `cms/extensions/routes.php` genereras automatiskt av CMS-admin.

#### Resultat
- Listvy: `/happenings` visar alla inlägg med kategori "Nyheter" ELLER "Event"
- Enskild: `/happenings/mitt-event` visar detalj
- CMS-dropdown i "Skapa inlägg" visar alla kategorier från categories.php

#### Exempelprompts som triggar detta
- "Skapa kategorier Nyheter och Event, visa båda under /happenings"
- "Lägg till en blogg på /blogg"
- "Ta bort kategorin Blogg"

**Viktigt:** `category`-värdena i `pages.php` MÅSTE matcha kategorinamn i `categories.php` och `category`-fältet i `data/projects.json`. Exakt match, case-sensitive.

### CTA-knappar i inlägg
Editorn har en "Knapp"-funktion i toolbaren. Infogar `<a class="button button--primary">` som ärver sajtens varumärkesstyling (färger, border-radius, typsnitt via CSS-variabler). Klasser bevaras av sanitizer — tillåtna: `button`, `button--primary`, `button--secondary`, `button--outline`.

### Publika sidor
- `/` — Huvudsida (`index.php` i rot)
- `/kontakt` — Kontaktformulär (`pages/kontakt.php`)
- `/inlagg` — Alla inlägg (`pages/inlagg.php`)
- `/inlagg/{slug}` — Enskilt inlägg (`pages/inlagg-single.php`)
- `/integritetspolicy` — GDPR-policy (`pages/integritetspolicy.php`)
- `/cookies` — Cookie-policy (`pages/cookies.php`)
- Extra kategorisidor (t.ex. `/blogg`, `/happenings`) konfigureras per projekt (se ovan)

**Routing:** `/inlagg` hanteras av `.htaccess`. Extra kategorisidor routas via `cms/extensions/routes.php`. Samma PHP-filer, kontextväxling via URL-prefix.

### CMS-admin (kräver inloggning)
- `/admin` — Logga in
- `/dashboard` — Översikt (med analytics-kort)
- `/projects` — Hantera inlägg
- `/seo` — SEO-admin (meta-titel/beskrivning per sida)
- `/analytics` — Besöksstatistik (egen tracker, cookiesamtycke)
- `/tickets` — Ärendehantering
- `/support` — Skapa supportärende (skapar ticket direkt, inget SMTP krävs)
- `/categories` — Hantera innehållskategorier
- `/media` — Mediabibliotek
- `/settings` — Inställningar
