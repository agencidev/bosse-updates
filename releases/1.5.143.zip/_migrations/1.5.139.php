<?php
/**
 * Migration 1.5.139 → 1.5.140
 * Convert old categories.php format (route-keyed objects) to:
 *   - categories.php: simple array of category name strings
 *   - pages.php: page config with multi-category support
 */

$root = defined('ROOT_PATH') ? ROOT_PATH : dirname(__DIR__);
$catFile = $root . '/cms/extensions/categories.php';
$pagesFile = $root . '/cms/extensions/pages.php';

// Only migrate if categories.php exists and uses old format
if (!file_exists($catFile)) return;

$cats = require $catFile;
if (!is_array($cats) || empty($cats)) return;

// Detect old format: keys are route prefixes like "/inlagg", values are arrays
$first = reset($cats);
if (!is_array($first)) return; // Already new format (simple string array)

// Extract category names
$categoryNames = array_unique(array_values(array_column($cats, 'category')));
$categoryNames = array_values(array_filter($categoryNames));

// Build pages config (one page per old category entry, preserving behavior)
$pages = [];
foreach ($cats as $prefix => $cfg) {
    $pages[$prefix] = [
        'title_sv' => $cfg['title_sv'] ?? $cfg['category'] ?? '',
        'title_en' => $cfg['title_en'] ?? '',
        'categories' => [$cfg['category'] ?? ''],
        'base_url' => $cfg['base_url'] ?? $prefix,
    ];
}

// Write new categories.php (simple array)
$catContent = "<?php\n";
$catContent .= "/**\n";
$catContent .= " * Category labels (SAFE — survives updates)\n";
$catContent .= " * Managed via CMS admin (/categories). Manual edits are also OK.\n";
$catContent .= " */\n";
$catContent .= "return " . var_export($categoryNames, true) . ";\n";
file_put_contents($catFile, $catContent, LOCK_EX);

// Write pages.php
$pagesContent = "<?php\n";
$pagesContent .= "/**\n";
$pagesContent .= " * Category page configuration (SAFE — survives updates)\n";
$pagesContent .= " * Managed via CMS admin (/categories). Manual edits are also OK.\n";
$pagesContent .= " */\n";
$pagesContent .= "return [\n";
foreach ($pages as $prefix => $cfg) {
    $catsExport = var_export($cfg['categories'], true);
    $pagesContent .= "    " . var_export($prefix, true) . " => ["
        . "'title_sv' => " . var_export($cfg['title_sv'], true) . ", "
        . "'title_en' => " . var_export($cfg['title_en'], true) . ", "
        . "'categories' => " . $catsExport . ", "
        . "'base_url' => " . var_export($cfg['base_url'], true)
        . "],\n";
}
$pagesContent .= "];\n";
file_put_contents($pagesFile, $pagesContent, LOCK_EX);

error_log("Migration 1.5.139: Converted categories.php to new format + created pages.php");
