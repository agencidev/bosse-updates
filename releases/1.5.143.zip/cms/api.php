<?php
/**
 * CMS API
 * API-endpoints för CMS-funktionalitet
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../security/csrf.php';
require_once __DIR__ . '/../security/session.php';
require_once __DIR__ . '/../security/validation.php';
require_once __DIR__ . '/content.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

// ai-resolve supports cron token auth — check before session gate
if ($action === 'ai-resolve') {
    $cronToken = $_GET['cron_token'] ?? '';
    $hasCronAuth = defined('CRON_SECRET') && CRON_SECRET !== '' && $cronToken !== ''
        && hash_equals(CRON_SECRET, $cronToken);
    $hasSuperAdmin = is_logged_in() && is_super_admin();

    if (!$hasCronAuth && !$hasSuperAdmin) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Forbidden']);
        exit;
    }
    handleAiResolve();
    exit;
}

// Kräv inloggning — returnera 404 för att inte avslöja endpoint
if (!is_logged_in()) {
    http_response_code(404);
    exit;
}

switch ($action) {
    case 'get':
        handleGet();
        break;

    case 'update':
        handleUpdate();
        break;

    case 'upload':
        handleUpload();
        break;

    case 'backup':
        handleBackup();
        break;

    case 'media-list':
        handleMediaList();
        break;

    case 'media-delete':
        handleMediaDelete();
        break;

    case 'media-select':
        handleMediaSelect();
        break;

    case 'media-optimize':
        handleMediaOptimize();
        break;

    case 'ticket-list':
        handleTicketList();
        break;

    case 'ticket-update':
        handleTicketUpdate();
        break;

    case 'analytics-overview':
    case 'analytics-timeseries':
    case 'analytics-pages':
    case 'analytics-sources':
    case 'analytics-devices':
    case 'analytics-heatmap':
    case 'analytics-realtime':
        handleAnalytics($action);
        break;

    case 'save-navigation':
        handleSaveNavigation();
        break;

    case 'save-redirects':
        handleSaveRedirects();
        break;

    default:
        $customHandled = false;
        if (file_exists(__DIR__ . '/extensions/api-handlers.php')) {
            $customHandled = include __DIR__ . '/extensions/api-handlers.php';
        }
        if (!$customHandled) {
            http_response_code(404);
            exit;
        }
}

/**
 * Hämta innehåll - EXAKT som Next.js /api/content
 */
function handleGet() {
    // Returnera hela content-objektet med CSRF token för efterföljande requests
    $response = get_all_content();
    $response['_csrf'] = csrf_token();
    echo json_encode($response);
}

/**
 * Uppdatera innehåll - EXAKT som Next.js /api/admin/content
 */
function handleUpdate() {
    // Validera Content-Type
    $content_type = $_SERVER['CONTENT_TYPE'] ?? '';
    if (!str_contains($content_type, 'application/json')) {
        http_response_code(415);
        echo json_encode(['success' => false, 'error' => 'Content-Type must be application/json']);
        exit;
    }

    // Validera CSRF token (via header eller body)
    if (!csrf_verify_json()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'CSRF validation failed']);
        exit;
    }

    $data = json_decode(file_get_contents('php://input'), true);
    $key = $data['key'] ?? '';
    $value = $data['value'] ?? null;

    if (empty($key)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Key is required']);
        exit;
    }

    // Läs nuvarande content
    $content = get_all_content();

    // Uppdatera section (value är ett objekt med fields)
    $content[$key] = $value;

    // Atomic write: tmp file + rename
    $encoded = json_encode($content, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    $tmp = CONTENT_FILE . '.tmp.' . getmypid();
    if (file_put_contents($tmp, $encoded, LOCK_EX) !== false && rename($tmp, CONTENT_FILE)) {
        clear_content_cache();
        echo json_encode(['success' => true, '_version' => time()]);
    } else {
        @unlink($tmp);
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Failed to save content']);
    }
}

/**
 * Ladda upp bild
 */
function handleUpload() {
    // Validera CSRF
    if (!csrf_verify()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'CSRF validation failed']);
        exit;
    }

    if (!isset($_FILES['image'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'No file uploaded']);
        exit;
    }

    $key = $_POST['key'] ?? '';
    $field = $_POST['field'] ?? '';
    if (empty($key)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Key is required']);
        exit;
    }

    // Validera fil
    $validation = validate_file_upload($_FILES['image']);
    if (!$validation['valid']) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => $validation['error']]);
        exit;
    }

    // Generera säkert filnamn baserat på faktisk MIME-typ
    $filename = generate_safe_filename($_FILES['image']['name'], $_FILES['image']['tmp_name']);
    $upload_path = UPLOADS_PATH . '/' . $filename;

    // Flytta fil
    if (move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
        // Optimera bild (resize + komprimering + WebP)
        $optResult = optimize_image($upload_path);
        $url = '/uploads/' . $filename;

        // Build full content key (e.g. "hero.image" for nested storage)
        $fullKey = !empty($field) ? $key . '.' . $field : $key;

        // Spara URL + bilddimensioner i en atomisk skrivning
        $updates = [$fullKey => $url];
        $imgSize = @getimagesize($upload_path);
        if ($imgSize !== false) {
            $updates[$fullKey . '_width'] = $imgSize[0];
            $updates[$fullKey . '_height'] = $imgSize[1];
        }
        save_content_bulk($updates);

        echo json_encode(['success' => true, 'url' => $url, 'optimized' => $optResult['optimized'] ?? false]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Failed to upload file']);
    }
}

/**
 * Skapa och ladda ner backup
 */
function handleBackup() {
    // Kontrollera att ZipArchive finns
    if (!class_exists('ZipArchive')) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'ZipArchive är inte tillgänglig på servern']);
        exit;
    }

    $siteName = defined('SITE_NAME') ? preg_replace('/[^a-z0-9]/i', '-', SITE_NAME) : 'bosse';
    $filename = 'backup-' . strtolower($siteName) . '-' . date('Y-m-d') . '.zip';

    // Skapa temporär ZIP-fil
    $tmpFile = sys_get_temp_dir() . '/' . $filename;

    $zip = new ZipArchive();
    if ($zip->open($tmpFile, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Kunde inte skapa ZIP-fil']);
        exit;
    }

    // Lägg till data-filer
    $dataPath = DATA_PATH;
    $filesToBackup = ['content.json', 'projects.json'];
    foreach ($filesToBackup as $file) {
        $fullPath = $dataPath . '/' . $file;
        if (file_exists($fullPath)) {
            $zip->addFile($fullPath, 'data/' . $file);
        }
    }

    // Lägg till uploads-mapp (med storleksbegränsning)
    $uploadsPath = UPLOADS_PATH;
    if (is_dir($uploadsPath)) {
        $totalSize = 0;
        $maxSize = 50 * 1024 * 1024; // 50 MB max för uploads

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($uploadsPath, RecursiveDirectoryIterator::SKIP_DOTS)
        );

        foreach ($iterator as $file) {
            if ($file->isFile()) {
                $fileSize = $file->getSize();
                if ($totalSize + $fileSize > $maxSize) {
                    // Stoppa om vi når gränsen
                    break;
                }
                $relativePath = 'uploads/' . substr($file->getPathname(), strlen($uploadsPath) + 1);
                $zip->addFile($file->getPathname(), $relativePath);
                $totalSize += $fileSize;
            }
        }
    }

    $zip->close();

    // Skicka filen
    header('Content-Type: application/zip');
    header('Content-Disposition: attachment; filename="' . $filename . '"');
    header('Content-Length: ' . filesize($tmpFile));
    header('Cache-Control: no-cache, must-revalidate');
    header('Pragma: no-cache');

    readfile($tmpFile);

    // Rensa upp
    @unlink($tmpFile);
    exit;
}

/**
 * Bulk-optimera alla bilder i uploads
 */
function handleMediaOptimize() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
        exit;
    }

    if (!csrf_verify_json()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'CSRF validation failed']);
        exit;
    }

    $optimizableExt = ['jpg', 'jpeg', 'png', 'gif'];
    $optimizedCount = 0;
    $skippedCount = 0;
    $savedBytes = 0;

    if (is_dir(UPLOADS_PATH)) {
        $files = scandir(UPLOADS_PATH);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            if (!in_array($ext, $optimizableExt, true)) continue;

            $fullPath = UPLOADS_PATH . '/' . $file;
            if (!is_file($fullPath)) continue;

            $sizeBefore = filesize($fullPath);
            $result = optimize_image($fullPath);

            if ($result['optimized']) {
                clearstatcache(true, $fullPath);
                $sizeAfter = filesize($fullPath);
                $savedBytes += max(0, $sizeBefore - $sizeAfter);
                $optimizedCount++;
            } else {
                $skippedCount++;
            }
        }
    }

    echo json_encode([
        'success' => true,
        'optimized_count' => $optimizedCount,
        'skipped_count' => $skippedCount,
        'saved_bytes' => $savedBytes,
        '_csrf' => csrf_token(),
    ]);
}

/**
 * Lista bilder i mediabiblioteket
 */
function handleMediaList() {
    $allowedExt = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'];
    $images = [];

    if (is_dir(UPLOADS_PATH)) {
        $files = scandir(UPLOADS_PATH);
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
            if (!in_array($ext, $allowedExt, true)) continue;

            $fullPath = UPLOADS_PATH . '/' . $file;
            if (!is_file($fullPath)) continue;

            // Skip WebP companion files (generated by optimize_image)
            if ($ext === 'webp') {
                $baseName = pathinfo($file, PATHINFO_FILENAME);
                foreach (['jpg', 'jpeg', 'png'] as $origExt) {
                    if (file_exists(UPLOADS_PATH . '/' . $baseName . '.' . $origExt)) {
                        continue 2;
                    }
                }
            }

            $images[] = [
                'filename' => $file,
                'url' => '/uploads/' . $file,
                'size' => filesize($fullPath),
                'modified' => filemtime($fullPath),
            ];
        }
    }

    // Sort newest first
    usort($images, fn($a, $b) => $b['modified'] - $a['modified']);

    echo json_encode([
        'success' => true,
        'images' => $images,
        '_csrf' => csrf_token(),
    ]);
}

/**
 * Radera bild från mediabiblioteket
 */
function handleMediaDelete() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
        exit;
    }

    if (!csrf_verify_json()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'CSRF validation failed']);
        exit;
    }

    $data = json_decode(file_get_contents('php://input'), true);
    $filename = $data['filename'] ?? '';

    // Validate filename — no path traversal
    if (empty($filename) || str_contains($filename, '/') || str_contains($filename, '\\') || str_contains($filename, '..')) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Invalid filename']);
        exit;
    }

    $filePath = UPLOADS_PATH . '/' . $filename;
    $realPath = realpath($filePath);
    $realUploads = realpath(UPLOADS_PATH);

    // Ensure file is inside uploads directory
    if ($realPath === false || $realUploads === false || !str_starts_with($realPath, $realUploads . '/')) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'File not found']);
        exit;
    }

    // Check if referenced
    $referenced = false;
    $contentFile = DATA_PATH . '/content.json';
    $projectsFile = DATA_PATH . '/projects.json';
    $rawJson = '';
    if (file_exists($contentFile)) $rawJson .= file_get_contents($contentFile);
    if (file_exists($projectsFile)) $rawJson .= file_get_contents($projectsFile);
    if (str_contains($rawJson, $filename)) {
        $referenced = true;
    }

    // Delete file
    if (!@unlink($realPath)) {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Could not delete file']);
        exit;
    }

    // Delete WebP companion if it exists
    $pathInfo = pathinfo($realPath);
    $webpPath = $pathInfo['dirname'] . '/' . $pathInfo['filename'] . '.webp';
    if (file_exists($webpPath)) {
        @unlink($webpPath);
    }

    echo json_encode([
        'success' => true,
        'referenced' => $referenced,
        '_csrf' => csrf_token(),
    ]);
}

/**
 * Välj befintlig bild från mediabiblioteket
 */
function handleMediaSelect() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
        exit;
    }

    if (!csrf_verify_json()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'CSRF validation failed']);
        exit;
    }

    $data = json_decode(file_get_contents('php://input'), true);
    $key = $data['key'] ?? '';
    $field = $data['field'] ?? '';
    $url = $data['url'] ?? '';

    if (empty($key) || empty($field) || empty($url)) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'key, field and url are required']);
        exit;
    }

    // Use save_content_bulk with dot-notation to update only the specific field
    $fullKey = $key . '.' . $field;
    $result = save_content_bulk([$fullKey => $url]);

    if ($result) {
        echo json_encode(['success' => true, '_csrf' => csrf_token()]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Failed to save content']);
    }
}

/**
 * List tickets (GET)
 */
function handleTicketList() {
    require_once __DIR__ . '/tickets-db.php';

    $superAdmin = is_super_admin();
    $page = max(1, (int) ($_GET['page'] ?? 1));
    $limit = 20;
    $offset = ($page - 1) * $limit;

    $filters = [];
    if (!empty($_GET['status'])) $filters['status'] = $_GET['status'];
    if ($superAdmin && !empty($_GET['source'])) $filters['source'] = $_GET['source'];
    if ($superAdmin && !empty($_GET['category'])) $filters['category'] = $_GET['category'];

    $result = ticket_list($filters, $limit, $offset);

    // Strip sensitive fields for non-super admin
    if (!$superAdmin) {
        $result['tickets'] = array_map(function ($t) {
            return [
                'id' => $t['id'],
                'subject' => $t['subject'],
                'status' => $t['status'],
                'created_at' => $t['created_at'],
            ];
        }, $result['tickets']);
    }

    echo json_encode(['success' => true, 'data' => $result]);
}

/**
 * Update ticket (POST, requires super admin)
 */
function handleTicketUpdate() {
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        echo json_encode(['success' => false, 'error' => 'Method not allowed']);
        exit;
    }

    if (!is_super_admin()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'Super admin required']);
        exit;
    }

    if (!csrf_verify_json()) {
        http_response_code(403);
        echo json_encode(['success' => false, 'error' => 'CSRF validation failed']);
        exit;
    }

    require_once __DIR__ . '/tickets-db.php';

    $data = json_decode(file_get_contents('php://input'), true);
    $id = (int) ($data['id'] ?? 0);

    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Ticket ID required']);
        exit;
    }

    $updates = [];
    if (isset($data['status'])) $updates['status'] = $data['status'];
    if (isset($data['admin_notes'])) $updates['admin_notes'] = $data['admin_notes'];
    if (isset($data['category'])) $updates['category'] = $data['category'];

    $result = ticket_update($id, $updates);
    echo json_encode(['success' => $result]);
}

/**
 * Analytics API endpoints
 */
function handleAnalytics(string $action) {
    require_once __DIR__ . '/analytics-db.php';

    $range = $_GET['range'] ?? '7d';
    $now = new DateTime();
    $to = $now->format('Y-m-d H:i:s');

    switch ($range) {
        case '30d': $from = (clone $now)->modify('-30 days')->format('Y-m-d H:i:s'); break;
        case '90d': $from = (clone $now)->modify('-90 days')->format('Y-m-d H:i:s'); break;
        default: $from = (clone $now)->modify('-7 days')->format('Y-m-d H:i:s'); break;
    }

    switch ($action) {
        case 'analytics-overview':
            echo json_encode(['success' => true, 'data' => analytics_overview($from, $to)]);
            break;
        case 'analytics-timeseries':
            echo json_encode(['success' => true, 'data' => analytics_timeseries($from, $to)]);
            break;
        case 'analytics-pages':
            echo json_encode(['success' => true, 'data' => analytics_top_pages($from, $to)]);
            break;
        case 'analytics-sources':
            echo json_encode(['success' => true, 'data' => analytics_sources($from, $to)]);
            break;
        case 'analytics-devices':
            echo json_encode(['success' => true, 'data' => analytics_devices($from, $to)]);
            break;
        case 'analytics-heatmap':
            $path = $_GET['path'] ?? '/';
            echo json_encode(['success' => true, 'data' => analytics_heatmap($path, $from, $to)]);
            break;
        case 'analytics-realtime':
            echo json_encode(['success' => true, 'data' => analytics_realtime()]);
            break;
    }
}

/**
 * AI resolve endpoint (supports cron token + super admin auth)
 */
function handleAiResolve() {
    require_once __DIR__ . '/tickets-db.php';
    require_once __DIR__ . '/ai-agent.php';

    $ticketId = (int) ($_GET['ticket_id'] ?? 0);

    if ($ticketId > 0) {
        // Resolve single ticket
        $result = ai_resolve_ticket($ticketId);
        echo json_encode(['success' => $result['success'], 'message' => $result['message'], 'actions' => $result['actions'] ?? []]);
    } else {
        // Batch process new tickets
        $processed = ai_process_new_tickets();
        echo json_encode([
            'success' => true,
            'processed' => count($processed),
            'details' => $processed,
        ]);
    }
}

/**
 * Save navigation menu items
 */
function handleSaveNavigation(): void {
    csrf_require();

    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input) || !isset($input['items'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Ogiltig data']);
        return;
    }

    // Sanitize items
    $items = [];
    foreach ($input['items'] as $item) {
        if (empty($item['label']) || empty($item['url'])) continue;
        $items[] = [
            'label' => htmlspecialchars(strip_tags(trim($item['label'])), ENT_QUOTES, 'UTF-8'),
            'url' => htmlspecialchars(strip_tags(trim($item['url'])), ENT_QUOTES, 'UTF-8'),
        ];
    }

    $navData = ['items' => $items];
    $file = DATA_PATH . '/navigation.json';
    $encoded = json_encode($navData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $tmp = $file . '.tmp.' . getmypid();
    if (file_put_contents($tmp, $encoded, LOCK_EX) !== false && rename($tmp, $file)) {
        echo json_encode(['success' => true, 'count' => count($items)]);
    } else {
        @unlink($tmp);
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Kunde inte spara navigation']);
    }
}

/**
 * Save URL redirects
 */
function handleSaveRedirects(): void {
    csrf_require();

    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input) || !isset($input['redirects'])) {
        http_response_code(400);
        echo json_encode(['success' => false, 'error' => 'Ogiltig data']);
        return;
    }

    $redirects = [];
    foreach ($input['redirects'] as $r) {
        $from = trim($r['from'] ?? '');
        $to = trim($r['to'] ?? '');
        if (empty($from) || empty($to)) continue;
        if ($from[0] !== '/') $from = '/' . $from;
        $redirects[] = [
            'from' => $from,
            'to' => $to,
            'code' => ($r['code'] ?? 301) == 302 ? 302 : 301,
        ];
    }

    $file = DATA_PATH . '/redirects.json';
    $encoded = json_encode($redirects, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

    $tmp = $file . '.tmp.' . getmypid();
    if (file_put_contents($tmp, $encoded, LOCK_EX) !== false && rename($tmp, $file)) {
        echo json_encode(['success' => true, 'count' => count($redirects)]);
    } else {
        @unlink($tmp);
        http_response_code(500);
        echo json_encode(['success' => false, 'error' => 'Kunde inte spara redirects']);
    }
}
