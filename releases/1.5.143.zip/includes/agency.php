<?php
/**
 * Agency branding helper — CORE file
 * Returns agency config with three-tier priority:
 * 1. config.php AGENCY_* constants (per-site override)
 * 2. agency-defaults.json (shipped with update repo, per-partner)
 * 3. Hardcoded Peys defaults (ultimate fallback)
 */

function agency_config(?string $key = null) {
    static $config = null;
    if ($config === null) {
        // 1. Hardcoded defaults
        $defaults = [
            'name'        => 'PEYS',
            'url'         => 'https://peys.se',
            'logo_light'  => '/assets/images/cms/peys-logo-light.png',
            'logo_dark'   => '/assets/images/cms/peys-logo-dark.png',
            'badge_text'  => 'Sidan drivs och hanteras av',
            'badge_bg'    => '#033234',
            'corner_text' => 'Skapad av oss 🥳',
            'login_tab'   => 'PEYS',
            // CMS theme
            'cms_bg'      => '#033234',
            'cms_accent'  => '#379b83',
            'cms_font'    => 'DM Sans',
            'cms_font_heading' => 'Space Grotesk',
        ];

        // 2. agency-defaults.json (from update repo — partner-specific)
        $jsonPath = (defined('ROOT_PATH') ? ROOT_PATH : dirname(__DIR__)) . '/agency-defaults.json';
        if (file_exists($jsonPath)) {
            $json = json_decode(file_get_contents($jsonPath), true);
            if (is_array($json)) {
                $defaults = array_merge($defaults, $json);
            }
        }

        // 3. config.php overrides (highest priority)
        $map = [
            'name'        => 'AGENCY_NAME',
            'url'         => 'AGENCY_URL',
            'logo_light'  => 'AGENCY_LOGO_LIGHT',
            'logo_dark'   => 'AGENCY_LOGO_DARK',
            'badge_text'  => 'AGENCY_BADGE_TEXT',
            'badge_bg'    => 'AGENCY_BADGE_BG',
            'corner_text' => 'AGENCY_CORNER_TEXT',
            'login_tab'   => 'AGENCY_LOGIN_TAB',
            'cms_bg'      => 'AGENCY_CMS_BG',
            'cms_accent'  => 'AGENCY_CMS_ACCENT',
            'cms_font'    => 'AGENCY_CMS_FONT',
            'cms_font_heading' => 'AGENCY_CMS_FONT_HEADING',
        ];
        $config = $defaults;
        foreach ($map as $k => $const) {
            if (defined($const)) {
                $config[$k] = constant($const);
            }
        }
    }
    return $key !== null ? ($config[$key] ?? null) : $config;
}

/**
 * Returns a <style> block that overrides CMS colors/fonts based on agency config.
 * Include this in all CMS pages to apply agency theming.
 */
function agency_cms_theme(): string {
    $bg = htmlspecialchars(agency_config('cms_bg'));
    $accent = htmlspecialchars(agency_config('cms_accent'));
    $font = htmlspecialchars(agency_config('cms_font'));
    $fontHeading = htmlspecialchars(agency_config('cms_font_heading'));

    // Lighter variant of bg for modals/panels
    $bgLight = agency_hex_lighten($bg, 15);
    // Darker variant of accent for hover
    $accentDark = agency_hex_lighten($accent, -15);

    return <<<CSS
<style data-agency-theme>
/* === Agency CMS Theme Override === */

/* CSS Variables */
:root { --color-woodsmoke: {$bg}; --color-persimmon: {$accent}; --cms-bg: {$bg}; --cms-accent: {$accent}; --cms-bg-light: {$bgLight}; }

/* Body & typography */
body { background-color: {$bg} !important; font-family: '{$font}', sans-serif !important; }
h1, h2, h3, h4, h5, h6 { font-family: '{$fontHeading}', sans-serif !important; }
p, span, label, td, th, li, div, a, input, select, textarea, button { font-family: '{$font}', sans-serif !important; }

/* ALL backgrounds that use Peys teal (#033234 and variants) */
.bg-woodsmoke { background-color: {$bg} !important; }
.admin-bar { background-color: {$bg} !important; background: {$bg} !important; }

/* Modals & panels — slightly lighter bg */
[class*="modal-content"], [class*="forgot-modal"], .forgot-modal-content { background: {$bgLight} !important; background-color: {$bgLight} !important; }
select option { background-color: {$bg} !important; }

/* ALL buttons */
.button, .btn, .btn-primary, .button-primary, .sa-btn--primary, button[type="submit"],
[class*="btn-primary"], [class*="btn--primary"], [class*="button-primary"],
.admin-bar__btn-logout { background-color: {$accent} !important; background: {$accent} !important; color: #fff !important; border-color: {$accent} !important; }
.button:hover, .btn:hover, .btn-primary:hover, .button-primary:hover, .sa-btn--primary:hover,
button[type="submit"]:hover, [class*="btn-primary"]:hover, [class*="button-primary"]:hover,
.admin-bar__btn-logout:hover { background-color: {$accentDark} !important; background: {$accentDark} !important; }

/* Edit mode button active */
.admin-bar__btn-edit.active { background: {$accent} !important; border-color: {$accent} !important; color: #fff !important; }
.admin-bar__btn-edit.active:hover { background: {$accentDark} !important; }

/* Tabs — login, category filters, pagination */
.login-tab.active, .cat-tab--active, [class*="tab--active"], [class*="tab-active"],
.pagination .active, .page-link.active { background: {$accent} !important; color: #fff !important; border-color: {$accent} !important; }

/* Badges */
.sa-badge--ok, .badge--ok, [class*="badge--ok"] { background-color: {$accent} !important; color: #fff !important; }
.bg-persimmon { background-color: {$accent} !important; }

/* Links */
a { color: {$accent} !important; }
a:hover { color: {$accentDark} !important; }
/* Reset white links in nav/header */
.admin-bar a, .admin-bar__btn-edit, nav a { color: rgba(255,255,255,0.85) !important; }
.admin-bar a:hover, nav a:hover { color: #fff !important; }

/* Forgot password link */
.forgot-password a, .forgot-password a:hover { color: {$accent} !important; }
.forgot-modal-content a, .email-link { color: {$accent} !important; }

/* Focus states */
input:focus, select:focus, textarea:focus { border-color: {$accent} !important; box-shadow: 0 0 0 2px {$accent}40 !important; outline: none !important; }

/* Borders that use accent */
[class*="active"], .active { border-color: {$accent} !important; }

/* Hover states — card icons (stroke-based, not fill) */
[class*="card"]:hover .icon svg { color: {$accent} !important; }
[class*="card"]:hover .icon { color: {$accent} !important; }
[class*="hover"][class*="persimmon"]:hover { color: {$accent} !important; }

/* Bar fills & progress indicators */
.bar-fill, [class*="bar-fill"] { background: {$accent} !important; }

/* Gradients */
[style*="linear-gradient"] { background: {$accent} !important; }

/* Back links */
.back-link:hover { color: {$accent} !important; }

/* Status colors — keep green/red/yellow but override accent-colored ones */
[style*="color:#379b83"], [style*="color: #379b83"] { color: {$accent} !important; }
[style*="background:#379b83"], [style*="background: #379b83"], [style*="background-color:#379b83"], [style*="background-color: #379b83"] { background-color: {$accent} !important; }
[style*="border-color:#379b83"], [style*="border-color: #379b83"] { border-color: {$accent} !important; }

/* Catch-all: override any remaining Peys green (#379b83) used as background */
.manage-categories-btn, [class*="manage-categor"] { color: {$accent} !important; border-color: {$accent} !important; }
.bulk-actions button, .bulk-actions select { border-color: rgba(255,255,255,0.15) !important; }
</style>
<script>window.CMS_BG='{$bg}';window.CMS_ACCENT='{$accent}';window.CMS_FONT='{$font}';</script>
CSS;
}

/**
 * Lighten or darken a hex color by percentage.
 */
function agency_hex_lighten(string $hex, int $percent): string {
    $hex = ltrim($hex, '#');
    if (strlen($hex) === 3) $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
    $r = hexdec(substr($hex, 0, 2));
    $g = hexdec(substr($hex, 2, 2));
    $b = hexdec(substr($hex, 4, 2));
    if ($percent > 0) {
        $r += (255 - $r) * $percent / 100;
        $g += (255 - $g) * $percent / 100;
        $b += (255 - $b) * $percent / 100;
    } else {
        $f = (100 + $percent) / 100;
        $r *= $f; $g *= $f; $b *= $f;
    }
    return '#' . str_pad(dechex(max(0,min(255,(int)round($r)))),2,'0',STR_PAD_LEFT)
               . str_pad(dechex(max(0,min(255,(int)round($g)))),2,'0',STR_PAD_LEFT)
               . str_pad(dechex(max(0,min(255,(int)round($b)))),2,'0',STR_PAD_LEFT);
}

/**
 * Returns Google Fonts <link> tags for CMS fonts.
 */
function agency_cms_fonts(): string {
    $font = agency_config('cms_font');
    $fontHeading = agency_config('cms_font_heading');
    $families = [];
    foreach ([$font, $fontHeading] as $f) {
        if ($f !== 'DM Sans' && $f !== 'Space Grotesk' && $f !== 'System UI' && !in_array($f, $families)) {
            $families[] = $f;
        }
    }
    if (empty($families)) return '';
    $params = [];
    foreach ($families as $f) {
        $params[] = 'family=' . urlencode($f) . ':wght@400;500;600;700';
    }
    $url = 'https://fonts.googleapis.com/css2?' . implode('&', $params) . '&display=swap';
    return '<link href="' . htmlspecialchars($url) . '" rel="stylesheet">';
}
