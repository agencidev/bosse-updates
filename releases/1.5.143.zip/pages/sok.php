<?php
/**
 * Söksida — söker bland inlägg och sidor
 */
require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../security/session.php';
require_once __DIR__ . '/../cms/content.php';
require_once __DIR__ . '/../seo/meta.php';

$query = trim($_GET['q'] ?? '');
$safeQuery = htmlspecialchars($query, ENT_QUOTES, 'UTF-8');
$results = [];

if (mb_strlen($query) >= 2) {
    $q = mb_strtolower($query);

    // Search in projects.json
    $projectsFile = DATA_PATH . '/projects.json';
    if (file_exists($projectsFile)) {
        $projects = json_decode(file_get_contents($projectsFile), true) ?? [];
        foreach ($projects as $project) {
            if (($project['status'] ?? 'draft') !== 'published') continue;

            $score = 0;
            $title = mb_strtolower($project['title'] ?? '');
            $summary = mb_strtolower($project['summary'] ?? '');
            $content = mb_strtolower(strip_tags($project['content'] ?? ''));
            $category = mb_strtolower($project['category'] ?? '');

            // Score: exact title match > title contains > summary > content > category
            if ($title === $q) $score = 100;
            elseif (mb_strpos($title, $q) !== false) $score = 80;
            elseif (mb_strpos($summary, $q) !== false) $score = 60;
            elseif (mb_strpos($content, $q) !== false) $score = 40;
            elseif (mb_strpos($category, $q) !== false) $score = 20;

            if ($score > 0) {
                // Get URL prefix from categories
                $prefix = '/inlagg';
                $catFile = ROOT_PATH . '/cms/extensions/categories.php';
                if (file_exists($catFile)) {
                    $cats = include $catFile;
                    if (is_array($cats)) {
                        foreach ($cats as $url => $cat) {
                            if (($cat['category'] ?? '') === ($project['category'] ?? '')) {
                                $prefix = $cat['base_url'] ?? $url;
                                break;
                            }
                        }
                    }
                }

                // Create snippet
                $snippet = $project['summary'] ?? '';
                if (empty($snippet)) {
                    $plain = strip_tags($project['content'] ?? '');
                    $snippet = mb_substr($plain, 0, 160) . (mb_strlen($plain) > 160 ? '...' : '');
                }

                $results[] = [
                    'score' => $score,
                    'title' => $project['title'] ?? '',
                    'url' => $prefix . '/' . ($project['slug'] ?? ''),
                    'snippet' => $snippet,
                    'category' => $project['category'] ?? '',
                    'date' => $project['createdAt'] ?? '',
                    'image' => $project['coverImage'] ?? '',
                    'type' => 'post',
                ];
            }
        }
    }

    // Sort by score descending
    usort($results, fn($a, $b) => $b['score'] - $a['score']);
}

$resultCount = count($results);
$pageTitle = $query ? "Sökresultat för \"{$safeQuery}\"" : 'Sök';

include __DIR__ . '/../includes/admin-bar.php';
?>
<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php generateMeta($pageTitle, 'Sök bland alla inlägg och sidor.', '/assets/images/og-image.jpg'); ?>
    <meta name="robots" content="noindex, nofollow">
    <?php if (file_exists(ROOT_PATH . '/includes/fonts.php')) include ROOT_PATH . '/includes/fonts.php'; ?>
    <link rel="preload" href="/assets/css/main.css?v=<?php echo BOSSE_VERSION; ?>" as="style">
    <link rel="stylesheet" href="/assets/css/main.css?v=<?php echo BOSSE_VERSION; ?>">
</head>
<body>
    <?php include __DIR__ . '/../includes/header.php'; ?>

    <main id="main-content">
        <section class="section" style="padding: var(--section-padding, 4rem) 0;">
            <div class="container" style="max-width: 48rem;">
                <h1 style="font-size: 2rem; margin-bottom: 1.5rem;"><?php echo $query ? "Resultat för \"{$safeQuery}\"" : 'Sök'; ?></h1>

                <!-- Search form -->
                <form action="/sok" method="get" style="margin-bottom: 2rem;">
                    <div style="display: flex; gap: 0.5rem;">
                        <input type="search" name="q" value="<?php echo $safeQuery; ?>"
                               placeholder="Sök bland inlägg..."
                               autofocus
                               style="flex: 1; padding: 0.75rem 1rem; border: 1px solid var(--color-gray-300, #d1d5db); border-radius: var(--radius-md, 0.5rem); font-size: 1rem; background: white; color: var(--color-foreground, #111);">
                        <button type="submit"
                                style="padding: 0.75rem 1.5rem; background: var(--color-primary); color: white; border: none; border-radius: var(--radius-md, 0.5rem); font-size: 1rem; font-weight: 600; cursor: pointer;">
                            Sök
                        </button>
                    </div>
                </form>

                <?php if ($query && mb_strlen($query) < 2): ?>
                    <p style="color: var(--color-gray-500);">Ange minst 2 tecken för att söka.</p>

                <?php elseif ($query && $resultCount === 0): ?>
                    <p style="color: var(--color-gray-500);">Inga resultat hittades för "<?php echo $safeQuery; ?>". Prova ett annat sökord.</p>

                <?php elseif ($resultCount > 0): ?>
                    <p style="color: var(--color-gray-500); margin-bottom: 1.5rem; font-size: 0.875rem;"><?php echo $resultCount; ?> resultat</p>

                    <div style="display: flex; flex-direction: column; gap: 1.5rem;">
                        <?php foreach ($results as $result): ?>
                        <a href="<?php echo htmlspecialchars($result['url']); ?>" style="display: flex; gap: 1rem; text-decoration: none; color: inherit; padding: 1rem; border-radius: var(--radius-md, 0.5rem); border: 1px solid var(--color-gray-200, #e5e7eb); transition: box-shadow 0.2s;">
                            <?php if (!empty($result['image'])): ?>
                            <img src="<?php echo htmlspecialchars($result['image']); ?>"
                                 alt="" loading="lazy"
                                 width="120" height="80"
                                 style="width: 120px; height: 80px; object-fit: cover; border-radius: 0.375rem; flex-shrink: 0;">
                            <?php endif; ?>
                            <div style="min-width: 0;">
                                <?php if (!empty($result['category'])): ?>
                                <span style="font-size: 0.75rem; font-weight: 600; color: var(--color-primary); text-transform: uppercase; letter-spacing: 0.05em;"><?php echo htmlspecialchars($result['category']); ?></span>
                                <?php endif; ?>
                                <h2 style="font-size: 1.125rem; font-weight: 600; margin: 0.25rem 0; color: var(--color-foreground, #111);"><?php echo htmlspecialchars($result['title']); ?></h2>
                                <p style="font-size: 0.875rem; color: var(--color-gray-500); margin: 0; overflow: hidden; display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical;"><?php echo htmlspecialchars($result['snippet']); ?></p>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </section>
    </main>

    <?php include __DIR__ . '/../includes/footer.php'; ?>
    <script src="/assets/js/cms.js?v=<?php echo BOSSE_VERSION; ?>" defer></script>
    <?php include __DIR__ . '/../includes/cookie-consent.php'; ?>
</body>
</html>
