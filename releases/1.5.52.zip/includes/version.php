<?php
/**
 * Bosse Template Version
 * CORE-fil - skrivs över vid uppdatering
 */

define('BOSSE_VERSION', '1.5.52');
define('BOSSE_VERSION_DATE', '2026-02-26');
