<?php
/**
 * Inlägg-lista (publik)
 * Visar alla publicerade inlägg från data/projects.json
 * CORE-fil — skrivs över vid uppdatering.
 * Anpassa design via assets/css/inlagg-custom.css (SAFE).
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../security/session.php';
require_once __DIR__ . '/../cms/content.php';
require_once __DIR__ . '/../seo/meta.php';
require_once __DIR__ . '/../seo/schema.php';

// If POSTS_BASE_URL is set and we're on /inlagg (not included from a custom page), redirect
if (defined('POSTS_BASE_URL') && POSTS_BASE_URL !== '/inlagg' && !isset($_uri_prefix)) {
    $uri = strtok($_SERVER['REQUEST_URI'] ?? '', '?');
    if ($uri === '/inlagg' || $uri === '/inlagg/') {
        header('Location: ' . POSTS_BASE_URL, true, 301);
        exit;
    }
    // /inlagg/{slug} → redirect to POSTS_BASE_URL/{slug}
    if (preg_match('#^/inlagg/([a-z0-9-]+)/?$#', $uri, $m)) {
        header('Location: ' . POSTS_BASE_URL . '/' . $m[1], true, 301);
        exit;
    }
}

// Context: set these variables BEFORE including this file to customize
// Example: $_uri_prefix = '/happenings'; $_page_label = 'Happenings'; $_category_filters = ['Event'];
$_uri_prefix = $_uri_prefix ?? '/inlagg';
$_category_filters = $_category_filters ?? [];
$_page_label = $_page_label ?? 'Inlägg';

// SEO metadata from content.json or defaults
$seo_key = ltrim($_uri_prefix, '/') ?: 'inlagg';
$_site_name = defined('SITE_NAME') ? SITE_NAME : '';
$page_title = (string) get_content_raw($seo_key . '.meta_title', $_page_label) . ($_site_name ? ' - ' . $_site_name : '');
$page_description = (string) get_content_raw($seo_key . '.meta_description', 'Läs våra senaste inlägg.');

// Load projects
$projects_file = __DIR__ . '/../data/projects.json';
$all_projects = [];

if (file_exists($projects_file)) {
    $json = file_get_contents($projects_file);
    $all_projects = json_decode($json, true) ?? [];
}

// Filter to published or scheduled (if publish date has passed)
$now = date('Y-m-d H:i:s');
$projects = array_filter($all_projects, function($p) use ($now) {
    if (!isset($p['status'])) return false;
    if ($p['status'] === 'published') return true;
    if ($p['status'] === 'scheduled' && !empty($p['publishAt']) && $p['publishAt'] <= $now) return true;
    return false;
});

// Category filter from page config (supports multiple categories per page)
if (!empty($_category_filters)) {
    $projects = array_filter($projects, fn($p) => isset($p['category']) && in_array($p['category'], $_category_filters, true));
}

// Sort by display date (newest first), fallback to createdAt
usort($projects, function($a, $b) {
    $dateA = !empty($a['displayDate']) ? $a['displayDate'] : ($a['createdAt'] ?? '1970-01-01');
    $dateB = !empty($b['displayDate']) ? $b['displayDate'] : ($b['createdAt'] ?? '1970-01-01');
    return strtotime($dateB) - strtotime($dateA);
});

?>
<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <?php generateMeta($page_title, $page_description, '/assets/images/og-image.jpg'); ?>

    <?php if (file_exists(__DIR__ . '/../assets/images/favicon.png')): ?>
    <link rel="icon" type="image/png" href="/assets/images/favicon.png">
    <?php endif; ?>
    <?php if (file_exists(__DIR__ . '/../assets/images/apple-touch-icon.png')): ?>
    <link rel="apple-touch-icon" href="/assets/images/apple-touch-icon.png">
    <?php endif; ?>
    <link rel="stylesheet" href="/assets/css/main.css?v=<?php echo BOSSE_VERSION; ?>">
    <?php
    // Custom CSS overrides default completely (SAFE — survives updates)
    if (file_exists(__DIR__ . '/../assets/css/inlagg-custom.css')) {
        echo '<link rel="stylesheet" href="/assets/css/inlagg-custom.css?v=' . BOSSE_VERSION . '">';
    } else {
        echo '<link rel="stylesheet" href="/assets/css/inlagg-default.css?v=' . BOSSE_VERSION . '">';
    }
    ?>
    <?php if (file_exists(__DIR__ . '/../includes/fonts.php')) include __DIR__ . '/../includes/fonts.php'; ?>
    <?php if (file_exists(__DIR__ . '/../includes/analytics.php')) include __DIR__ . '/../includes/analytics.php'; ?>
</head>
<body>
    <?php include __DIR__ . '/../includes/admin-bar.php'; ?>
    <?php include __DIR__ . '/../includes/header.php'; ?>

    <main id="main-content">
        <section class="projekt-hero">
            <h1><?php echo htmlspecialchars($_page_label); ?></h1>
        </section>

        <section style="max-width: 1200px; margin: 0 auto; padding: 0 1.5rem;">
            <?php if (empty($projects)): ?>
                <div class="projekt-empty">
                    <p>Inga inlägg att visa just nu.</p>
                </div>
            <?php else: ?>
                <div class="projekt-grid">
                    <?php foreach ($projects as $project): ?>
                        <a href="<?php echo htmlspecialchars($_uri_prefix); ?>/<?php echo htmlspecialchars($project['slug'] ?? '', ENT_QUOTES, 'UTF-8'); ?>" class="projekt-card">
                            <?php if (!empty($project['coverImage'])): ?>
                                <?php picture_tag($project['coverImage'], $project['title'] ?? '', 'class="projekt-card__image" loading="lazy" width="800" height="450" style="aspect-ratio:16/9;object-fit:cover;"'); ?>
                            <?php endif; ?>
                            <div class="projekt-card__content">
                                <?php if (!empty($project['category'])): ?>
                                    <span class="projekt-card__category"><?php echo htmlspecialchars($project['category']); ?></span>
                                <?php endif; ?>
                                <h2 class="projekt-card__title"><?php echo htmlspecialchars($project['title'] ?? '', ENT_QUOTES, 'UTF-8'); ?></h2>
                                <p class="projekt-card__summary"><?php echo htmlspecialchars($project['summary'] ?? '', ENT_QUOTES, 'UTF-8'); ?></p>
                                <?php
                                $displayDate = !empty($project['displayDate']) ? $project['displayDate'] : ($project['createdAt'] ?? '');
                                if (!empty($displayDate)): ?>
                                    <span class="projekt-card__date"><?php echo date('j M Y', strtotime($displayDate)); ?></span>
                                <?php endif; ?>
                            </div>
                        </a>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </section>
    </main>

    <?php include __DIR__ . '/../includes/footer.php'; ?>

    <script src="/assets/js/cms.js?v=<?php echo BOSSE_VERSION; ?>" defer></script>
    <?php include __DIR__ . '/../includes/cookie-consent.php'; ?>
</body>
</html>
