<?php
/**
 * TILLFÄLLIG super-admin reset — ta bort denna fil efter användning.
 *
 * Giltig token: 2417b184564357e39bdbaad0f2ad11680ad6807e187937eb6782ad3928ccbff5
 * Upphör: 2026-04-15 23:59 CEST
 *
 * URL: /super-admin/reset?token=2417b184564357e39bdbaad0f2ad11680ad6807e187937eb6782ad3928ccbff5
 */

// Ladda bootstrap FÖRST (den hanterar session-start + ini_set)
$bootstrapFile = __DIR__ . '/../bootstrap.php';
if (file_exists($bootstrapFile)) {
    @require_once $bootstrapFile;
}
// Fallback om bootstrap saknas eller inte startade session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$root = defined('ROOT_PATH') ? ROOT_PATH : dirname(__DIR__);
$configFile = $root . '/config.php';

// === Hårdkodad token + utgångsdatum ===
const RESET_TOKEN   = '2417b184564357e39bdbaad0f2ad11680ad6807e187937eb6782ad3928ccbff5';
const RESET_EXPIRES = 1776290399; // 2026-04-15 23:59:59 CEST

if (time() > RESET_EXPIRES) {
    http_response_code(410);
    exit('Denna reset-länk har upphört. Ta bort security/super-admin-reset.php.');
}

if (!file_exists($configFile)) {
    http_response_code(503);
    exit('config.php saknas.');
}

// === Rate limit: 5 försök / 15 min / IP ===
$ip = $_SERVER['REMOTE_ADDR'] ?? 'unknown';
$ipHash = hash('sha256', $ip);
$attemptsFile = $root . '/data/sa-reset-attempts.json';
$now = time();
$attempts = [];
if (file_exists($attemptsFile)) {
    $attempts = json_decode(file_get_contents($attemptsFile), true) ?: [];
}
$attempts = array_filter($attempts, fn($a) => ($a['t'] ?? 0) > $now - 900);
if (count(array_filter($attempts, fn($a) => ($a['i'] ?? '') === $ipHash)) >= 5) {
    http_response_code(429);
    exit('För många försök. Vänta 15 minuter.');
}

// === Token ===
$token = $_GET['token'] ?? $_POST['token'] ?? '';
if (!is_string($token) || !hash_equals(RESET_TOKEN, $token)) {
    $attempts[] = ['i' => $ipHash, 't' => $now];
    @file_put_contents($attemptsFile, json_encode(array_values($attempts)), LOCK_EX);
    http_response_code(404);
    exit;
}

// === CSRF ===
if (empty($_SESSION['sa_csrf'])) {
    $_SESSION['sa_csrf'] = bin2hex(random_bytes(32));
}
$csrf = $_SESSION['sa_csrf'];

$errors = [];
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!isset($_POST['csrf']) || !hash_equals($csrf, $_POST['csrf'])) {
        $errors[] = 'Ogiltig token. Ladda om sidan.';
    } else {
        $user = trim($_POST['username'] ?? '');
        $pass = $_POST['password'] ?? '';
        $pass2 = $_POST['password_confirm'] ?? '';

        if (strlen($user) < 3) $errors[] = 'Användarnamn: minst 3 tecken.';
        if (!preg_match('/^[a-zA-Z0-9._-]+$/', $user)) $errors[] = 'Ogiltiga tecken i användarnamn.';
        if (strlen($pass) < 8) $errors[] = 'Lösenord: minst 8 tecken.';
        if ($pass !== $pass2) $errors[] = 'Lösenorden matchar inte.';

        if (empty($errors)) {
            $hash = password_hash($pass, PASSWORD_BCRYPT, ['cost' => 12]);
            $config = file_get_contents($configFile);

            $uDef = "define('AGENCY_USERNAME', '" . addslashes($user) . "');";
            $hDef = "define('AGENCY_PASSWORD_HASH', '" . $hash . "');";

            // str_replace — ALDRIG preg_replace (bcrypt $2y$12 = backreferences)
            $uOk = false;
            $hOk = false;
            if (preg_match("/define\(\s*'AGENCY_USERNAME'\s*,\s*'[^']*'\s*\);/", $config, $m)) {
                $config = str_replace($m[0], $uDef, $config);
                $uOk = true;
            }
            if (preg_match("/define\(\s*'AGENCY_PASSWORD_HASH'\s*,\s*'[^']*'\s*\);/", $config, $m)) {
                $config = str_replace($m[0], $hDef, $config);
                $hOk = true;
            }
            if (!$uOk || !$hOk) {
                $config .= "\n// Agency super-admin\n";
                if (!$uOk) $config .= $uDef . "\n";
                if (!$hOk) $config .= $hDef . "\n";
            }

            if (file_put_contents($configFile, $config, LOCK_EX) !== false) {
                $success = true;
                error_log("sa-reset: OK on " . ($_SERVER['HTTP_HOST'] ?? '?') . " by {$ipHash}");
                unset($_SESSION['sa_csrf']);
            } else {
                $errors[] = 'Kunde inte skriva config.php.';
            }
        }
    }
    if (!$success) {
        $attempts[] = ['i' => $ipHash, 't' => $now];
        @file_put_contents($attemptsFile, json_encode(array_values($attempts)), LOCK_EX);
    }
}
?>
<!DOCTYPE html>
<html lang="sv">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow,noarchive">
<title>Reset</title>
<style>
*{margin:0;padding:0;box-sizing:border-box}
body{font-family:system-ui,sans-serif;background:#0F172A;color:#E2E8F0;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1.5rem}
.m{background:#1E293B;border:1px solid rgba(255,255,255,0.08);border-radius:16px;padding:2.5rem;max-width:440px;width:100%;box-shadow:0 25px 50px rgba(0,0,0,0.5)}
h1{font-size:1.375rem;font-weight:700;margin-bottom:0.25rem}
.lead{font-size:0.875rem;color:#94A3B8;margin-bottom:1.5rem;line-height:1.5}
.f{margin-bottom:1rem}
.f label{display:block;font-size:0.8125rem;font-weight:600;color:#CBD5E1;margin-bottom:0.4rem}
.f input{width:100%;padding:0.75rem;background:rgba(0,0,0,0.25);border:1px solid rgba(255,255,255,0.1);border-radius:8px;color:#F1F5F9;font-size:0.9375rem;font-family:inherit;outline:none}
.f input:focus{border-color:#3B82F6;box-shadow:0 0 0 3px rgba(59,130,246,0.2)}
.f .h{font-size:0.75rem;color:#64748B;margin-top:0.375rem}
.b{width:100%;padding:0.875rem;background:#3B82F6;color:#fff;border:none;border-radius:8px;font-size:0.9375rem;font-weight:600;cursor:pointer;margin-top:0.5rem}
.b:hover{background:#2563EB}
.ok{padding:1rem;background:rgba(16,185,129,0.1);border:1px solid rgba(16,185,129,0.3);border-radius:8px;color:#6EE7B7;font-size:0.875rem;line-height:1.5}
.ok a{color:#6EE7B7}
.err{padding:1rem;background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.3);border-radius:8px;color:#FCA5A5;font-size:0.875rem;margin-bottom:1rem}
.exp{font-size:0.75rem;color:#64748B;margin-top:1.25rem;text-align:center}
</style>
</head>
<body>
<div class="m">
<h1>Super-admin reset</h1>
<p class="lead">Sätt nya inlogg för <strong><?=htmlspecialchars($_SERVER['HTTP_HOST']??'sajten')?></strong></p>

<?php if ($success): ?>
<div class="ok">Klart! Logga in på <a href="/admin">/admin</a> med dina nya uppgifter.<br><br><strong>Ta nu bort</strong> filen <code>security/super-admin-reset.php</code> från sajten.</div>
<?php else: ?>

<?php if ($errors): ?>
<div class="err"><?php foreach ($errors as $e) echo '• ' . htmlspecialchars($e) . '<br>'; ?></div>
<?php endif; ?>

<form method="post" action="/super-admin/reset?token=<?=urlencode($token)?>">
<input type="hidden" name="csrf" value="<?=htmlspecialchars($csrf)?>">
<input type="hidden" name="token" value="<?=htmlspecialchars($token)?>">
<div class="f"><label>Användarnamn</label><input type="text" name="username" required minlength="3" maxlength="64" pattern="[a-zA-Z0-9._-]+" autocomplete="off" autofocus></div>
<div class="f"><label>Lösenord</label><input type="password" name="password" required minlength="8" autocomplete="new-password"><div class="h">Minst 8 tecken</div></div>
<div class="f"><label>Bekräfta lösenord</label><input type="password" name="password_confirm" required minlength="8" autocomplete="new-password"></div>
<button type="submit" class="b">Spara</button>
</form>
<?php endif; ?>

<p class="exp">Länken upphör 2026-04-15 23:59. Ta bort filen efter användning.</p>
</div>
</body>
</html>
