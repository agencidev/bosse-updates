<?php
/**
 * CMS Content Management
 * Hanterar innehåll från JSON-fil
 */

require_once __DIR__ . '/../bootstrap.php';

// Path till content-fil
define('CONTENT_FILE', DATA_PATH . '/content.json');

/**
 * Hämta innehåll från JSON
 */
function get_content($key, $default = '') {
    if (!file_exists(CONTENT_FILE)) {
        return $default;
    }

    $raw = file_get_contents(CONTENT_FILE);
    $content = json_decode($raw, true);
    if ($content === null && json_last_error() !== JSON_ERROR_NONE) {
        error_log('JSON corruption in ' . CONTENT_FILE . ': ' . json_last_error_msg());
        return $default;
    }

    // Stöd för nested keys (t.ex. "hero.title")
    $keys = explode('.', $key);
    $value = $content;
    
    foreach ($keys as $k) {
        if (!isset($value[$k])) {
            return $default;
        }
        $value = $value[$k];
    }
    
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

/**
 * Hämta innehåll utan HTML-escaping (för kontexter som escapar själva, t.ex. generateMeta)
 */
function get_content_raw($key, $default = '') {
    $content = get_all_content();
    $keys = explode('.', $key);
    $value = $content;
    foreach ($keys as $k) {
        if (!isset($value[$k])) return $default;
        $value = $value[$k];
    }
    return $value;
}

/**
 * Spara innehåll till JSON
 */
function save_content($key, $value) {
    $content = [];

    if (file_exists(CONTENT_FILE)) {
        $raw = file_get_contents(CONTENT_FILE);
        $decoded = json_decode($raw, true);
        if ($decoded === null && json_last_error() !== JSON_ERROR_NONE) {
            error_log('JSON corruption in ' . CONTENT_FILE . ': ' . json_last_error_msg());
            // Try to continue with empty content rather than losing the update
        } else {
            $content = $decoded ?? [];
        }
    }

    // Stöd för nested keys
    $keys = explode('.', $key);
    $temp = &$content;

    foreach ($keys as $i => $k) {
        if ($i === count($keys) - 1) {
            $temp[$k] = $value;
        } else {
            if (!isset($temp[$k]) || !is_array($temp[$k])) {
                $temp[$k] = [];
            }
            $temp = &$temp[$k];
        }
    }

    // Atomic write: write to temp file, then rename (unique name to prevent race condition)
    $tmp = CONTENT_FILE . '.' . getmypid() . '.' . hrtime(true) . '.tmp';
    $encoded = json_encode($content, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if (file_put_contents($tmp, $encoded, LOCK_EX) === false) {
        error_log('Failed to write temp file: ' . $tmp);
        return false;
    }
    return rename($tmp, CONTENT_FILE);
}

/**
 * Spara flera nycklar i en atomisk skrivning
 * @param array $updates Associative array ['key' => 'value', ...]
 */
function save_content_bulk(array $updates) {
    $content = [];

    if (file_exists(CONTENT_FILE)) {
        $raw = file_get_contents(CONTENT_FILE);
        $decoded = json_decode($raw, true);
        if ($decoded === null && json_last_error() !== JSON_ERROR_NONE) {
            error_log('JSON corruption in ' . CONTENT_FILE . ': ' . json_last_error_msg());
        } else {
            $content = $decoded ?? [];
        }
    }

    foreach ($updates as $key => $value) {
        $keys = explode('.', $key);
        $temp = &$content;
        foreach ($keys as $i => $k) {
            if ($i === count($keys) - 1) {
                $temp[$k] = $value;
            } else {
                if (!isset($temp[$k]) || !is_array($temp[$k])) {
                    $temp[$k] = [];
                }
                $temp = &$temp[$k];
            }
        }
        unset($temp);
    }

    $tmp = CONTENT_FILE . '.' . getmypid() . '.' . hrtime(true) . '.tmp';
    $encoded = json_encode($content, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if (file_put_contents($tmp, $encoded, LOCK_EX) === false) {
        error_log('Failed to write temp file: ' . $tmp);
        return false;
    }
    return rename($tmp, CONTENT_FILE);
}

/**
 * Hämta allt innehåll (med cache för prestanda)
 */
function get_all_content() {
    static $cache = null;

    if ($cache !== null) {
        return $cache;
    }

    if (!file_exists(CONTENT_FILE)) {
        $cache = [];
        return $cache;
    }

    $raw = file_get_contents(CONTENT_FILE);
    $decoded = json_decode($raw, true);
    if ($decoded === null && json_last_error() !== JSON_ERROR_NONE) {
        error_log('JSON corruption in ' . CONTENT_FILE . ': ' . json_last_error_msg());
        $cache = [];
        return $cache;
    }
    $cache = $decoded ?? [];
    return $cache;
}

/**
 * Rensa content-cache (anropas efter uppdatering)
 */
function clear_content_cache() {
    // Statisk variabel kan inte nollställas utifrån,
    // men vid nästa request laddas filen om ändå
    // Denna funktion finns för tydlighet och framtida utbyggnad
}

/**
 * Redigerbar text - EXAKT som EditableText.jsx i Next.js
 * 
 * @param string $contentKey - Content key (e.g., 'hero')
 * @param string $field - Field name (e.g., 'title')
 * @param string $defaultValue - Default value
 * @param string $as - HTML tag (h1, h2, p, span, etc.)
 * @param string $className - CSS classes
 * @param string $placeholder - Placeholder text
 */
function editable_text($contentKey, $field, $defaultValue = '', $as = 'p', $className = '', $placeholder = 'Klicka för att redigera...') {
    $is_admin = isset($_SESSION['logged_in']) && $_SESSION['logged_in'];

    // Get value from content
    $content = get_all_content();
    $value = isset($content[$contentKey][$field]) ? $content[$contentKey][$field] : $defaultValue;
    $displayValue = !empty($value) ? htmlspecialchars($value, ENT_QUOTES, 'UTF-8') : htmlspecialchars($placeholder, ENT_QUOTES, 'UTF-8');

    // Escape alla attribut
    $safeAs = preg_replace('/[^a-z0-9]/i', '', $as); // Endast alfanumeriska tecken för taggen
    $safeClassName = htmlspecialchars($className, ENT_QUOTES, 'UTF-8');

    if (!$is_admin) {
        echo "<{$safeAs} class=\"{$safeClassName}\">{$displayValue}</{$safeAs}>";
        return;
    }

    // Escape attributes för admin-läge
    $safeContentKey = htmlspecialchars($contentKey, ENT_QUOTES, 'UTF-8');
    $safeField = htmlspecialchars($field, ENT_QUOTES, 'UTF-8');
    $safeDefault = htmlspecialchars($defaultValue, ENT_QUOTES, 'UTF-8');

    // Output with data attributes for JavaScript
    echo "<{$safeAs}
        class=\"{$safeClassName} cms-editable-active\"
        data-editable-text=\"true\"
        data-content-key=\"{$safeContentKey}\"
        data-field=\"{$safeField}\"
        data-default-value=\"{$safeDefault}\"
        title=\"Klicka för att redigera\"
    >{$displayValue}</{$safeAs}>";
}

/**
 * Redigerbar bild - EXAKT som EditableImage.jsx i Next.js
 * 
 * @param string $contentKey - Content key (e.g., 'hero')
 * @param string $field - Field name (e.g., 'image')
 * @param string $defaultValue - Default image path
 * @param string $alt - Alt text
 * @param string $className - CSS classes
 */
function editable_image($contentKey, $field, $defaultValue = '/assets/images/placeholder.jpg', $alt = '', $className = '') {
    $is_admin = isset($_SESSION['logged_in']) && $_SESSION['logged_in'];

    // Get value from content
    $content = get_all_content();
    $src = isset($content[$contentKey][$field]) ? $content[$contentKey][$field] : $defaultValue;

    // Escape alla attribut
    $safeSrc = htmlspecialchars($src, ENT_QUOTES, 'UTF-8');
    $safeAlt = htmlspecialchars($alt, ENT_QUOTES, 'UTF-8');
    $safeClassName = htmlspecialchars($className, ENT_QUOTES, 'UTF-8');

    // Get width/height from content if stored, or detect from file
    $widthKey = $field . '_width';
    $heightKey = $field . '_height';
    $imgWidth = isset($content[$contentKey][$widthKey]) ? (int)$content[$contentKey][$widthKey] : 0;
    $imgHeight = isset($content[$contentKey][$heightKey]) ? (int)$content[$contentKey][$heightKey] : 0;

    if ($imgWidth === 0 && $imgHeight === 0 && !empty($src)) {
        $filePath = (defined('ROOT_PATH') ? ROOT_PATH : dirname(__DIR__)) . $src;
        if (file_exists($filePath)) {
            $size = @getimagesize($filePath);
            if ($size !== false) {
                $imgWidth = $size[0];
                $imgHeight = $size[1];
            }
        }
    }

    $sizeAttrs = ($imgWidth > 0 && $imgHeight > 0)
        ? ' width="' . $imgWidth . '" height="' . $imgHeight . '"'
        : '';

    // Focal point
    $focalX = isset($content[$contentKey][$field . '_focal_x']) ? (int)$content[$contentKey][$field . '_focal_x'] : 50;
    $focalY = isset($content[$contentKey][$field . '_focal_y']) ? (int)$content[$contentKey][$field . '_focal_y'] : 50;
    $focalStyle = ($focalX !== 50 || $focalY !== 50) ? ' style="object-position:' . $focalX . '% ' . $focalY . '%"' : '';

    if (!$is_admin) {
        picture_tag($src, $alt, 'class="' . $safeClassName . '"' . $sizeAttrs . $focalStyle . ' loading="lazy"');
        return;
    }

    $safeContentKey = htmlspecialchars($contentKey, ENT_QUOTES, 'UTF-8');
    $safeField = htmlspecialchars($field, ENT_QUOTES, 'UTF-8');

    echo '<img
        src="' . $safeSrc . '"
        alt="' . $safeAlt . '"
        class="' . $safeClassName . '"' . $sizeAttrs . $focalStyle . '
        data-editable-image="true"
        data-content-key="' . $safeContentKey . '"
        data-field="' . $safeField . '"
        data-focal-x="' . $focalX . '"
        data-focal-y="' . $focalY . '"
        loading="lazy"
    >';
}

/**
 * Output <picture> with WebP source if available, otherwise plain <img>
 *
 * @param string $src - Image source URL
 * @param string $alt - Alt text
 * @param string $attrs - Extra HTML attributes string (class, loading, width, height, style, etc.)
 */
function picture_tag($src, $alt = '', $attrs = '') {
    $safeSrc = htmlspecialchars($src, ENT_QUOTES, 'UTF-8');
    $safeAlt = htmlspecialchars($alt, ENT_QUOTES, 'UTF-8');
    $rootPath = defined('ROOT_PATH') ? ROOT_PATH : dirname(__DIR__);

    $webpSrc = preg_replace('/\.(jpe?g|png|gif)$/i', '.webp', $src);
    $webpExists = ($webpSrc !== $src) && file_exists($rootPath . $webpSrc);

    if ($webpExists) {
        $safeWebp = htmlspecialchars($webpSrc, ENT_QUOTES, 'UTF-8');
        echo '<picture>';
        echo '<source srcset="' . $safeWebp . '" type="image/webp">';
        echo '<img src="' . $safeSrc . '" alt="' . $safeAlt . '" ' . $attrs . '>';
        echo '</picture>';
    } else {
        echo '<img src="' . $safeSrc . '" alt="' . $safeAlt . '" ' . $attrs . '>';
    }
}

/**
 * Redigerbar knapp (text + länk)
 *
 * Lagrar {field}_text och {field}_href i content.json under $contentKey.
 *
 * @param string $contentKey - Content key (e.g., 'hero')
 * @param string $field - Field name prefix (e.g., 'cta')
 * @param string $defaultText - Default button text
 * @param string $defaultHref - Default link URL
 * @param string $className - CSS classes for the <a> element
 */
function editable_button($contentKey, $field, $defaultText = 'Klicka här', $defaultHref = '#', $className = 'button button--primary') {
    $is_admin = isset($_SESSION['logged_in']) && $_SESSION['logged_in'];

    $content = get_all_content();
    $text = isset($content[$contentKey][$field . '_text']) ? $content[$contentKey][$field . '_text'] : $defaultText;
    $href = isset($content[$contentKey][$field . '_href']) ? $content[$contentKey][$field . '_href'] : $defaultHref;

    $safeText = htmlspecialchars($text, ENT_QUOTES, 'UTF-8');
    $safeHref = htmlspecialchars($href, ENT_QUOTES, 'UTF-8');
    $safeClassName = htmlspecialchars($className, ENT_QUOTES, 'UTF-8');

    if (!$is_admin) {
        echo '<a href="' . $safeHref . '" class="' . $safeClassName . '">' . $safeText . '</a>';
        return;
    }

    $safeContentKey = htmlspecialchars($contentKey, ENT_QUOTES, 'UTF-8');
    $safeField = htmlspecialchars($field, ENT_QUOTES, 'UTF-8');
    $safeDefaultText = htmlspecialchars($defaultText, ENT_QUOTES, 'UTF-8');
    $safeDefaultHref = htmlspecialchars($defaultHref, ENT_QUOTES, 'UTF-8');

    echo '<a href="' . $safeHref . '"
        class="' . $safeClassName . '"
        data-editable-button="true"
        data-content-key="' . $safeContentKey . '"
        data-field="' . $safeField . '"
        data-default-text="' . $safeDefaultText . '"
        data-default-href="' . $safeDefaultHref . '"
        title="Klicka för att redigera knapp"
    >' . $safeText . '</a>';
}
