<?php
/**
 * SEO Score Calculator
 * Analyserar inlägg och returnerar poäng + förbättringsförslag.
 */

/**
 * Calculate SEO score for a project/post.
 *
 * @param array $project - Project data from projects.json
 * @return array ['score' => int 0-100, 'issues' => [...], 'level' => 'good'|'warning'|'poor']
 */
function calculate_seo_score(array $project): array {
    $score = 0;
    $max = 0;
    $issues = [];

    $title = $project['title'] ?? '';
    $summary = $project['summary'] ?? '';
    $content = $project['content'] ?? '';
    $slug = $project['slug'] ?? '';
    $coverImage = $project['coverImage'] ?? '';

    $titleLen = mb_strlen($title);
    $summaryLen = mb_strlen($summary);
    $contentText = strip_tags($content);
    $wordCount = str_word_count($contentText, 0, 'åäöÅÄÖéèêëüûùúïîìíóòôõ');

    // 1. Title length (20 pts)
    $max += 20;
    if ($titleLen >= 30 && $titleLen <= 60) {
        $score += 20;
    } elseif ($titleLen >= 20 && $titleLen <= 70) {
        $score += 12;
        $issues[] = 'Titeln bör vara 30–60 tecken (nu ' . $titleLen . ')';
    } else {
        $score += 4;
        $issues[] = 'Titeln är ' . ($titleLen < 20 ? 'för kort' : 'för lång') . ' (' . $titleLen . ' tecken, mål: 30–60)';
    }

    // 2. Meta/summary (20 pts)
    $max += 20;
    if ($summaryLen >= 120 && $summaryLen <= 160) {
        $score += 20;
    } elseif ($summaryLen >= 80 && $summaryLen <= 200) {
        $score += 12;
        $issues[] = 'Sammanfattningen bör vara 120–160 tecken (nu ' . $summaryLen . ')';
    } elseif ($summaryLen > 0) {
        $score += 5;
        $issues[] = 'Sammanfattningen är ' . ($summaryLen < 80 ? 'för kort' : 'för lång') . ' (' . $summaryLen . ' tecken)';
    } else {
        $issues[] = 'Sammanfattning saknas — viktig för sökmotorer och delning';
    }

    // 3. Content length (20 pts)
    $max += 20;
    if ($wordCount >= 300) {
        $score += 20;
    } elseif ($wordCount >= 150) {
        $score += 12;
        $issues[] = 'Innehållet bör vara minst 300 ord (nu ' . $wordCount . ')';
    } elseif ($wordCount >= 50) {
        $score += 5;
        $issues[] = 'Innehållet är kort (' . $wordCount . ' ord, rekommenderat: 300+)';
    } else {
        $issues[] = 'Innehållet är mycket kort (' . $wordCount . ' ord)';
    }

    // 4. Cover image (10 pts)
    $max += 10;
    if (!empty($coverImage)) {
        $score += 10;
    } else {
        $issues[] = 'Omslagsbild saknas — viktigt för delning och visuellt intryck';
    }

    // 5. Slug quality (10 pts)
    $max += 10;
    $slugLen = mb_strlen($slug);
    if ($slugLen > 0 && $slugLen <= 60 && preg_match('/^[a-z0-9-]+$/', $slug)) {
        $score += 10;
    } elseif ($slugLen > 0) {
        $score += 5;
        if ($slugLen > 60) {
            $issues[] = 'URL-slug är lång (' . $slugLen . ' tecken, mål: <60)';
        }
    } else {
        $issues[] = 'URL-slug saknas';
    }

    // 6. H2 headings in content (10 pts)
    $max += 10;
    if (preg_match('/<h2[\s>]/i', $content)) {
        $score += 10;
    } else {
        $issues[] = 'Lägg till minst en H2-rubrik för bättre struktur';
    }

    // 7. Images have alt text (10 pts)
    $max += 10;
    if (preg_match_all('/<img[^>]*>/i', $content, $imgMatches)) {
        $total = count($imgMatches[0]);
        $withAlt = 0;
        foreach ($imgMatches[0] as $imgTag) {
            if (preg_match('/alt\s*=\s*"[^"]+"/i', $imgTag)) {
                $withAlt++;
            }
        }
        if ($withAlt === $total) {
            $score += 10;
        } elseif ($withAlt > 0) {
            $score += 5;
            $issues[] = ($total - $withAlt) . ' av ' . $total . ' bilder saknar alt-text';
        } else {
            $issues[] = 'Bilder i innehållet saknar alt-texter';
        }
    } else {
        // No images in content — not penalized, just no bonus
        $score += 10;
    }

    $pct = $max > 0 ? round(($score / $max) * 100) : 0;
    $level = $pct >= 70 ? 'good' : ($pct >= 40 ? 'warning' : 'poor');

    return [
        'score' => $pct,
        'issues' => $issues,
        'level' => $level,
        'wordCount' => $wordCount,
    ];
}

/**
 * Get CSS color for SEO score level
 */
function seo_score_color(string $level): string {
    switch ($level) {
        case 'good': return '#10b981';
        case 'warning': return '#f59e0b';
        case 'poor': return '#ef4444';
        default: return '#71717a';
    }
}
