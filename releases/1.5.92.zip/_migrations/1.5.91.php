<?php
/**
 * Migration 1.5.91
 * Add peys-badge include to footer.php (SAFE file — needs migration)
 *
 * 1. Inject peys-badge.php include after </footer> in footer.php
 * 2. Remove old inline Peys banner if present
 * 3. Remove kontakt route from .htaccess if present
 *
 * Idempotent: safe to run multiple times.
 */

$base = defined('BASE_PATH') ? BASE_PATH : dirname(__DIR__);

// --- 1. Add peys-badge include to footer.php ---
$footerFile = $base . '/includes/footer.php';
if (file_exists($footerFile)) {
    $content = file_get_contents($footerFile);

    // Skip if already included
    if (strpos($content, 'peys-badge.php') === false) {
        // Remove inline Peys banner if present (from v1.5.91 pre-release)
        $content = preg_replace(
            '/\s*<!-- Peys Banner -->.*?<\/div>\s*<\/div>\s*<\/div>\s*/s',
            "\n",
            $content
        );

        // Remove inline Peys CSS if present
        $content = preg_replace(
            '/\.footer__peys\s*\{.*?\.footer__peys-link:hover\s+\.footer__peys-logo\s*\{[^}]*\}\s*/s',
            '',
            $content
        );

        // Inject include after </footer>
        $content = str_replace(
            '</footer>',
            "</footer>\n\n<?php include __DIR__ . '/peys-badge.php'; ?>",
            $content
        );

        file_put_contents($footerFile, $content, LOCK_EX);
    }
}

// --- 2. Remove kontakt route from .htaccess ---
$htaccess = $base . '/.htaccess';
if (file_exists($htaccess)) {
    $content = file_get_contents($htaccess);
    if (strpos($content, 'kontakt') !== false) {
        $content = preg_replace(
            '/# \/kontakt -> \/pages\/kontakt\.php\s*\nRewriteRule \^kontakt\/\?\$ pages\/kontakt\.php \[L\]\s*\n/',
            '',
            $content
        );
        file_put_contents($htaccess, $content, LOCK_EX);
    }
}

return 'ok';
