<?php
/**
 * Uppdateringssystem för Bosse Template
 * Hanterar versionskontroll, nedladdning, backup och applicering
 */

// Filer som far skrivas over vid uppdatering
const UPDATABLE_FILES = [
    'bootstrap.php', 'router.php', 'setup.php', 'includes/version.php',
    '.htaccess', '.user.ini',
    'seo/robots.php', 'public/site.webmanifest',
    'pages/projekt.php', 'pages/projekt-single.php', 'CLAUDE.md',
    // CMS-logotyper (explicit för bakåtkompatibilitet med äldre updaters)
    'assets/images/cms/agenci-logo-dark.png',
    'assets/images/cms/agenci-logo-light.png',
    'cms/admin.php', 'cms/dashboard.php', 'cms/content.php',
    'cms/api.php', 'cms/api-super.php', 'cms/super-admin.php',
    'cms/seo.php', 'cms/support.php', 'cms/ai.php', 'cms/settings.php',
    'cms/helpers.php', 'cms/media.php',
    'cms/tickets-db.php', 'cms/tickets.php', 'cms/ticket-single.php', 'cms/ai-agent.php',
    'cms/projects/index.php', 'cms/projects/new.php', 'cms/projects/edit.php',
    'security/csrf.php', 'security/session.php', 'security/validation.php',
    'security/super-admin.php', 'security/updater.php', 'security/csp.php',
    'seo/meta.php', 'seo/schema.php', 'seo/sitemap.php',
    'includes/admin-bar.php', 'includes/cookie-consent.php',
    'includes/mailer.php', 'includes/agenci-badge.php',
    'assets/css/reset.css', 'assets/css/cms.css',
    'assets/js/cms.js',
    '.windsurfrules',
    'bosse-health.php',
];

// Wildcard-matchade uppdateringsbara mappar
const UPDATABLE_DIRS = ['bin', 'templates', '.github', 'assets/images/cms'];

// Filer som ALDRIG rörs
const PROTECTED_FILES = [
    'config.php', '.env',
    'data/content.json', 'data/projects.json',
    'assets/css/variables.css', 'assets/css/overrides.css',
    'assets/css/main.css', 'assets/css/components.css',
    'includes/header.php', 'includes/footer.php', 'includes/fonts.php',
    'index.php', 'pages/kontakt.php', 'pages/cookies.php', 'pages/integritetspolicy.php',
    'pages/errors/403.php', 'pages/errors/404.php', 'pages/errors/500.php',
];

// Wildcard-skyddade mappar
const PROTECTED_DIRS = ['assets/images', 'uploads'];

/**
 * Kolla om en fil ar uppdateringsbar
 */
function is_updatable_file(string $relativePath): bool {
    // Blocka path traversal
    if (str_contains($relativePath, '..') || $relativePath[0] === '/') {
        return false;
    }

    // Kolla exakt match i UPDATABLE_FILES
    if (in_array($relativePath, UPDATABLE_FILES, true)) {
        return true;
    }

    // Kolla wildcard-mappar
    foreach (UPDATABLE_DIRS as $dir) {
        if (str_starts_with($relativePath, $dir . '/')) {
            return true;
        }
    }

    return false;
}

/**
 * Kolla om en fil ar skyddad
 * OBS: UPDATABLE_DIRS har prioritet over PROTECTED_DIRS
 */
function is_protected_file(string $relativePath): bool {
    if (in_array($relativePath, PROTECTED_FILES, true)) {
        return true;
    }

    // Kolla forst om filen ar i en uppdateringsbar mapp (de har prioritet)
    foreach (UPDATABLE_DIRS as $dir) {
        if (str_starts_with($relativePath, $dir . '/')) {
            return false; // Inte skyddad - uppdateringsbar mapp har prioritet
        }
    }

    foreach (PROTECTED_DIRS as $dir) {
        if (str_starts_with($relativePath, $dir . '/')) {
            return true;
        }
    }

    return false;
}

/**
 * Hämta uppdateringsstatus från cache
 */
function get_update_state(): array {
    $stateFile = DATA_PATH . '/update-state.json';
    if (!file_exists($stateFile)) {
        return [
            'last_check' => 0,
            'latest_version' => null,
            'current_version' => BOSSE_VERSION,
            'update_available' => false,
            'changelog' => '',
            'download_url' => '',
            'signature' => '',
            'critical' => false,
            'min_php_version' => '8.0',
            'release_date' => '',
        ];
    }

    $data = json_decode(file_get_contents($stateFile), true);
    return is_array($data) ? $data : get_update_state_defaults();
}

function get_update_state_defaults(): array {
    return [
        'last_check' => 0,
        'latest_version' => null,
        'current_version' => BOSSE_VERSION,
        'update_available' => false,
        'changelog' => '',
        'download_url' => '',
        'signature' => '',
        'critical' => false,
        'min_php_version' => '8.0',
        'release_date' => '',
    ];
}

/**
 * Spara uppdateringsstatus
 */
function save_update_state(array $state): void {
    $stateFile = DATA_PATH . '/update-state.json';
    if (!is_dir(DATA_PATH)) {
        mkdir(DATA_PATH, 0755, true);
    }
    file_put_contents($stateFile, json_encode($state, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
}

/**
 * Kolla om uppdatering finns tillgänglig
 * Hämtar manifest.json från update-servern
 */
function check_for_update(): array {
    $updateUrl = defined('AGENCI_UPDATE_URL') ? AGENCI_UPDATE_URL : '';
    if (empty($updateUrl)) {
        return ['error' => 'AGENCI_UPDATE_URL är inte konfigurerad'];
    }

    $manifestUrl = rtrim($updateUrl, '/') . '/manifest.json';

    // HTTP-request med 5s timeout
    $context = stream_context_create([
        'http' => [
            'timeout' => 5,
            'method' => 'GET',
            'header' => "User-Agent: BosseTemplate/" . BOSSE_VERSION . "\r\n",
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);

    $response = @file_get_contents($manifestUrl, false, $context);
    if ($response === false) {
        return ['error' => 'Kunde inte nå uppdateringsservern'];
    }

    $manifest = json_decode($response, true);
    if (!is_array($manifest) || !isset($manifest['latest_version'])) {
        return ['error' => 'Ogiltigt manifest-format'];
    }

    $updateAvailable = version_compare($manifest['latest_version'], BOSSE_VERSION, '>');

    // PHP-versionskontroll
    $minPhp = $manifest['min_php_version'] ?? '8.0';
    $phpCompatible = version_compare(PHP_VERSION, $minPhp, '>=');

    $state = [
        'last_check' => time(),
        'latest_version' => $manifest['latest_version'],
        'current_version' => BOSSE_VERSION,
        'update_available' => $updateAvailable,
        'changelog' => $manifest['changelog'] ?? '',
        'download_url' => $manifest['download_url'] ?? '',
        'signature' => $manifest['signature'] ?? '',
        'critical' => $manifest['critical'] ?? false,
        'min_php_version' => $minPhp,
        'php_compatible' => $phpCompatible,
        'release_date' => $manifest['release_date'] ?? '',
        'migrations' => $manifest['migrations'] ?? [],
    ];

    save_update_state($state);

    return $state;
}

/**
 * Verifiera HMAC-signatur på en fil
 */
function verify_signature(string $filePath, string $expected): bool {
    if (!defined('AGENCI_UPDATE_KEY') || AGENCI_UPDATE_KEY === '') {
        return false;
    }

    // Forväntat format: "sha256:hexhash"
    $parts = explode(':', $expected, 2);
    if (count($parts) !== 2 || $parts[0] !== 'sha256') {
        return false;
    }

    $expectedHash = $parts[1];
    $actualHash = hash_hmac('sha256', file_get_contents($filePath), AGENCI_UPDATE_KEY);

    return hash_equals($expectedHash, $actualHash);
}

/**
 * Ladda ner uppdatering
 */
function download_update(string $url, string $signature): string|false {
    // Skapa tmp-mapp
    $tmpDir = DATA_PATH . '/tmp';
    if (!is_dir($tmpDir)) {
        mkdir($tmpDir, 0755, true);
    }

    // Lock-fil för att forhindra parallella uppdateringar
    $lockFile = $tmpDir . '/.update-lock';
    if (file_exists($lockFile)) {
        $lockAge = time() - filemtime($lockFile);
        if ($lockAge < 600) { // 10 min
            return false;
        }
        // Gammal lock, ta bort
        unlink($lockFile);
    }
    file_put_contents($lockFile, time());

    // Ladda ner
    $context = stream_context_create([
        'http' => [
            'timeout' => 60,
            'method' => 'GET',
            'header' => "User-Agent: BosseTemplate/" . BOSSE_VERSION . "\r\n",
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ]);

    $zipContent = @file_get_contents($url, false, $context);
    if ($zipContent === false) {
        @unlink($lockFile);
        return false;
    }

    $zipPath = $tmpDir . '/update-' . time() . '.zip';
    file_put_contents($zipPath, $zipContent);

    // Verifiera signatur
    if (!empty($signature) && defined('AGENCI_UPDATE_KEY') && AGENCI_UPDATE_KEY !== '') {
        if (!verify_signature($zipPath, $signature)) {
            @unlink($zipPath);
            @unlink($lockFile);
            return false;
        }
    }

    return $zipPath;
}

/**
 * Skapa backup av alla UPDATABLE_FILES
 */
function create_backup(): string {
    $backupDir = DATA_PATH . '/backups/backup-' . BOSSE_VERSION . '-' . date('Ymd-His');
    if (!is_dir($backupDir)) {
        mkdir($backupDir, 0755, true);
    }

    $rootPath = defined('ROOT_PATH') ? ROOT_PATH : dirname(__DIR__);
    $backedUp = [];

    // Kopiera exakta filer
    foreach (UPDATABLE_FILES as $file) {
        $src = $rootPath . '/' . $file;
        if (file_exists($src)) {
            $dest = $backupDir . '/' . $file;
            $destDir = dirname($dest);
            if (!is_dir($destDir)) {
                mkdir($destDir, 0755, true);
            }
            copy($src, $dest);
            $backedUp[] = $file;
        }
    }

    // Kopiera wildcard-mappar
    foreach (UPDATABLE_DIRS as $dir) {
        $srcDir = $rootPath . '/' . $dir;
        if (is_dir($srcDir)) {
            backup_directory($srcDir, $backupDir . '/' . $dir);
        }
    }

    // Spara metadata
    $meta = [
        'version' => BOSSE_VERSION,
        'date' => date('Y-m-d H:i:s'),
        'files' => $backedUp,
        'php_version' => PHP_VERSION,
    ];
    file_put_contents($backupDir . '/backup-meta.json', json_encode($meta, JSON_PRETTY_PRINT));

    return $backupDir;
}

/**
 * Rekursiv kopieringsfunktion för backup
 */
function backup_directory(string $src, string $dest): void {
    if (!is_dir($dest)) {
        mkdir($dest, 0755, true);
    }

    $items = scandir($src);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $srcPath = $src . '/' . $item;
        $destPath = $dest . '/' . $item;
        if (is_dir($srcPath)) {
            backup_directory($srcPath, $destPath);
        } else {
            copy($srcPath, $destPath);
        }
    }
}

/**
 * Applicera uppdatering från ZIP
 */
function apply_update(string $zipPath): array {
    $result = [
        'success' => false,
        'updated_files' => [],
        'skipped_files' => [],
        'errors' => [],
        'backup_dir' => '',
    ];

    if (!class_exists('ZipArchive')) {
        $result['errors'][] = 'ZipArchive är inte tillgänglig på servern';
        return $result;
    }

    $rootPath = defined('ROOT_PATH') ? ROOT_PATH : dirname(__DIR__);

    // Skapa backup
    $backupDir = create_backup();
    $result['backup_dir'] = $backupDir;

    // Öppna ZIP
    $zip = new ZipArchive();
    $res = $zip->open($zipPath);
    if ($res !== true) {
        $result['errors'][] = 'Kunde inte öppna ZIP-filen (felkod: ' . $res . ')';
        return $result;
    }

    // Read allowlist from ZIP's updater to avoid chicken-and-egg problem
    $zipUpdatableFiles = UPDATABLE_FILES;
    $zipUpdatableDirs = UPDATABLE_DIRS;
    $zipUpdaterContent = $zip->getFromName('security/updater.php');
    if ($zipUpdaterContent !== false) {
        if (preg_match("/UPDATABLE_FILES\s*=\s*\[([^\]]+)\]/s", $zipUpdaterContent, $m)) {
            preg_match_all("/'([^']+)'/", $m[1], $files);
            if (!empty($files[1])) {
                $zipUpdatableFiles = $files[1];
            }
        }
        if (preg_match("/UPDATABLE_DIRS\s*=\s*\[([^\]]+)\]/s", $zipUpdaterContent, $m)) {
            preg_match_all("/'([^']+)'/", $m[1], $dirs);
            if (!empty($dirs[1])) {
                $zipUpdatableDirs = $dirs[1];
            }
        }
    }

    // Extrahera bara godkända filer
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $filename = $zip->getNameIndex($i);

        // Hoppa över mappar
        if (str_ends_with($filename, '/')) {
            continue;
        }

        // Path traversal-skydd
        if (str_contains($filename, '..') || $filename[0] === '/') {
            $result['skipped_files'][] = $filename . ' (path traversal)';
            continue;
        }

        // Migreringsfiler (hanteras separat)
        if (str_starts_with($filename, '_migrations/')) {
            continue;
        }

        // Kolla om filen far uppdateras (mot ZIP:ens allowlist)
        $isUpdatable = in_array($filename, $zipUpdatableFiles, true);
        if (!$isUpdatable) {
            foreach ($zipUpdatableDirs as $dir) {
                if (str_starts_with($filename, $dir . '/')) {
                    $isUpdatable = true;
                    break;
                }
            }
        }
        if (!$isUpdatable) {
            $result['skipped_files'][] = $filename . ' (inte i allowlist)';
            continue;
        }

        // Kolla att den inte ar skyddad
        if (is_protected_file($filename)) {
            $result['skipped_files'][] = $filename . ' (skyddad)';
            continue;
        }

        // Extrahera filen
        $content = $zip->getFromIndex($i);
        if ($content === false) {
            $result['errors'][] = 'Kunde inte läsa ' . $filename . ' från ZIP';
            continue;
        }

        $destPath = $rootPath . '/' . $filename;
        $destDir = dirname($destPath);
        if (!is_dir($destDir)) {
            mkdir($destDir, 0755, true);
        }

        if (file_put_contents($destPath, $content) !== false) {
            $result['updated_files'][] = $filename;
        } else {
            $result['errors'][] = 'Kunde inte skriva ' . $filename;
        }
    }

    $zip->close();

    // Kör migrationer
    $state = get_update_state();
    $migrations = $state['migrations'] ?? [];
    if (!empty($migrations)) {
        $migrationResults = run_migrations(BOSSE_VERSION, $state['latest_version'] ?? BOSSE_VERSION, $zipPath);
        $result['migrations'] = $migrationResults;
    }

    // Rensa
    @unlink($zipPath);
    $lockFile = DATA_PATH . '/tmp/.update-lock';
    @unlink($lockFile);

    if (empty($result['errors'])) {
        $result['success'] = true;

        // Skapa .installed om den saknas (för sites byggda före v1.5.23)
        if (!file_exists($rootPath . '/.installed')) {
            @file_put_contents($rootPath . '/.installed', 'installed');
        }

        // Pusha till GitHub om konfigurerat
        $state = get_update_state();
        $githubResult = push_to_github($result['updated_files'], $state['latest_version'] ?? BOSSE_VERSION);
        $result['github_push'] = $githubResult;
    }

    return $result;
}

/**
 * Kör migrationer från ZIP
 */
function run_migrations(string $fromVersion, string $toVersion, string $zipPath): array {
    $results = [];

    if (!class_exists('ZipArchive')) {
        return ['error' => 'ZipArchive är inte tillgänglig'];
    }

    $zip = new ZipArchive();
    if ($zip->open($zipPath) !== true) {
        return ['error' => 'Kunde inte öppna ZIP för migrationer'];
    }

    // Samla alla migreringsfiler
    $migrations = [];
    for ($i = 0; $i < $zip->numFiles; $i++) {
        $name = $zip->getNameIndex($i);
        if (preg_match('#^_migrations/(\d+\.\d+\.\d+)\.php$#', $name, $matches)) {
            $version = $matches[1];
            if (version_compare($version, $fromVersion, '>') && version_compare($version, $toVersion, '<=')) {
                $migrations[$version] = $name;
            }
        }
    }

    // Sortera efter version
    uksort($migrations, 'version_compare');

    // Kör i ordning
    foreach ($migrations as $version => $migrationFile) {
        $content = $zip->getFromName($migrationFile);
        if ($content === false) {
            $results[] = ['version' => $version, 'status' => 'error', 'message' => 'Kunde inte läsa migreringsfilen'];
            continue;
        }

        // Spara temporärt och kor
        $tmpFile = DATA_PATH . '/tmp/_migration_' . $version . '.php';
        file_put_contents($tmpFile, $content);

        try {
            $migrationResult = require $tmpFile;
            $results[] = ['version' => $version, 'status' => 'ok', 'result' => $migrationResult];
        } catch (\Throwable $e) {
            $results[] = ['version' => $version, 'status' => 'error', 'message' => $e->getMessage()];
        }

        @unlink($tmpFile);
    }

    $zip->close();
    return $results;
}

/**
 * Återställ från backup
 */
function rollback_update(string $backupDir): bool {
    if (!is_dir($backupDir)) {
        return false;
    }

    $rootPath = defined('ROOT_PATH') ? ROOT_PATH : dirname(__DIR__);
    $metaFile = $backupDir . '/backup-meta.json';

    if (!file_exists($metaFile)) {
        return false;
    }

    $meta = json_decode(file_get_contents($metaFile), true);
    if (!is_array($meta)) {
        return false;
    }

    // Kopiera tillbaka alla filer
    $files = $meta['files'] ?? [];
    foreach ($files as $file) {
        $src = $backupDir . '/' . $file;
        $dest = $rootPath . '/' . $file;
        if (file_exists($src)) {
            $destDir = dirname($dest);
            if (!is_dir($destDir)) {
                mkdir($destDir, 0755, true);
            }
            copy($src, $dest);
        }
    }

    // Kopiera tillbaka wildcard-mappar
    foreach (UPDATABLE_DIRS as $dir) {
        $srcDir = $backupDir . '/' . $dir;
        if (is_dir($srcDir)) {
            restore_directory($srcDir, $rootPath . '/' . $dir);
        }
    }

    return true;
}

/**
 * Rekursiv återställning från backup
 */
function restore_directory(string $src, string $dest): void {
    if (!is_dir($dest)) {
        mkdir($dest, 0755, true);
    }

    $items = scandir($src);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..' || $item === 'backup-meta.json') {
            continue;
        }
        $srcPath = $src . '/' . $item;
        $destPath = $dest . '/' . $item;
        if (is_dir($srcPath)) {
            restore_directory($srcPath, $destPath);
        } else {
            copy($srcPath, $destPath);
        }
    }
}

/**
 * Lista befintliga backups
 */
function list_backups(): array {
    $backupsDir = DATA_PATH . '/backups';
    if (!is_dir($backupsDir)) {
        return [];
    }

    $backups = [];
    $items = scandir($backupsDir, SCANDIR_SORT_DESCENDING);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $dir = $backupsDir . '/' . $item;
        $metaFile = $dir . '/backup-meta.json';
        if (is_dir($dir) && file_exists($metaFile)) {
            $meta = json_decode(file_get_contents($metaFile), true);
            if (is_array($meta)) {
                $meta['path'] = $dir;
                $meta['dir_name'] = $item;
                $backups[] = $meta;
            }
        }
    }

    return $backups;
}

/**
 * Ta bort en backup
 */
function delete_backup(string $backupDir): bool {
    // Sakerhetscheck - maste vara under backups-mappen
    $backupsDir = DATA_PATH . '/backups';
    $realBackup = realpath($backupDir);
    $realBackupsDir = realpath($backupsDir);

    if ($realBackup === false || $realBackupsDir === false) {
        return false;
    }

    if (!str_starts_with($realBackup, $realBackupsDir)) {
        return false;
    }

    // Rekursiv borttagning
    return delete_directory($backupDir);
}

/**
 * Rekursiv borttagning av mapp
 */
function delete_directory(string $dir): bool {
    if (!is_dir($dir)) {
        return false;
    }

    $items = scandir($dir);
    foreach ($items as $item) {
        if ($item === '.' || $item === '..') {
            continue;
        }
        $path = $dir . '/' . $item;
        if (is_dir($path)) {
            delete_directory($path);
        } else {
            unlink($path);
        }
    }

    return rmdir($dir);
}

/**
 * Kontrollera om uppdateringskoll behovs (var 12:e timme)
 */
function should_check_for_update(): bool {
    $state = get_update_state();
    $lastCheck = $state['last_check'] ?? 0;
    return (time() - $lastCheck) > 43200; // 12 timmar
}

/**
 * Automatisk uppdatering — kör hela flodet tyst
 * Kollar → laddar ner → backup → applicerar → loggar
 * Returnerar true om uppdatering applicerades
 */
function auto_update(): bool {
    // Kolla om update URL ar konfigurerad
    if (!defined('AGENCI_UPDATE_URL') || AGENCI_UPDATE_URL === '') {
        return false;
    }

    // Kolla om det ar dags
    if (!should_check_for_update()) {
        // Kolla cachad state — kanske redan vetat om update men inte applicerat
        $state = get_update_state();
        if (empty($state['update_available'])) {
            return false;
        }
        // Finns cachad update — forsok applicera
        return auto_apply_from_state($state);
    }

    // Gor ny koll mot servern
    $state = check_for_update();

    if (isset($state['error']) || empty($state['update_available'])) {
        return false;
    }

    return auto_apply_from_state($state);
}

/**
 * Applicera uppdatering från cachad state (intern funktion)
 */
function auto_apply_from_state(array $state): bool {
    // PHP-versionskontroll
    if (!empty($state['min_php_version']) && version_compare(PHP_VERSION, $state['min_php_version'], '<')) {
        log_update_event('skip', $state['latest_version'] ?? '?', 'Kräver PHP ' . $state['min_php_version']);
        return false;
    }

    // Ladda ner
    $zipPath = download_update($state['download_url'] ?? '', $state['signature'] ?? '');
    if ($zipPath === false) {
        log_update_event('error', $state['latest_version'] ?? '?', 'Nedladdning misslyckades');
        return false;
    }

    // Applicera (skapar backup automatiskt)
    $result = apply_update($zipPath);

    if ($result['success']) {
        // Rensa update-available-flaggan
        $state['update_available'] = false;
        $state['current_version'] = $state['latest_version'];
        save_update_state($state);

        log_update_event('success', $state['latest_version'] ?? '?',
            count($result['updated_files']) . ' filer uppdaterade');

        // Logga GitHub push-resultat
        $ghPush = $result['github_push'] ?? null;
        if ($ghPush) {
            if ($ghPush['success']) {
                log_update_event('github_push', $state['latest_version'] ?? '?', $ghPush['message'] ?? 'OK');
            } else {
                log_update_event('github_push_error', $state['latest_version'] ?? '?', $ghPush['message'] ?? 'Okänt fel');
            }
        }

        // Städa gamla backups och tmp-filer
        cleanup_old_data();

        return true;
    }

    // Misslyckades — rollback skedde automatiskt i apply_update
    log_update_event('error', $state['latest_version'] ?? '?',
        implode('; ', $result['errors'] ?? ['Okänt fel']));
    return false;
}

/**
 * Logga uppdateringshandelse till data/update-log.json
 */
function log_update_event(string $type, string $version, string $message): void {
    $logFile = DATA_PATH . '/update-log.json';
    $log = [];

    if (file_exists($logFile)) {
        $existing = json_decode(file_get_contents($logFile), true);
        if (is_array($existing)) {
            $log = $existing;
        }
    }

    $log[] = [
        'type' => $type,
        'version' => $version,
        'message' => $message,
        'date' => date('Y-m-d H:i:s'),
        'from_version' => BOSSE_VERSION,
        'php_version' => PHP_VERSION,
    ];

    // Behall max 50 poster
    if (count($log) > 50) {
        $log = array_slice($log, -50);
    }

    if (!is_dir(DATA_PATH)) {
        mkdir(DATA_PATH, 0755, true);
    }
    file_put_contents($logFile, json_encode($log, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
}

/**
 * Rensa gamla backups — behall max 3 stycken
 * + ta bort allt i data/tmp/
 */
function cleanup_old_data(): void {
    // --- Backups: behall max 3 ---
    $backups = list_backups(); // sorterade nyast forst
    if (count($backups) > 3) {
        $toDelete = array_slice($backups, 3);
        foreach ($toDelete as $old) {
            if (!empty($old['path'])) {
                delete_backup($old['path']);
            }
        }
    }

    // --- Tmp: rensa allt utom lock-filen ---
    $tmpDir = DATA_PATH . '/tmp';
    if (is_dir($tmpDir)) {
        $items = scandir($tmpDir);
        foreach ($items as $item) {
            if ($item === '.' || $item === '..' || $item === '.update-lock') {
                continue;
            }
            $path = $tmpDir . '/' . $item;
            if (is_file($path)) {
                @unlink($path);
            } elseif (is_dir($path)) {
                delete_directory($path);
            }
        }
    }
}

/**
 * HTTP-anrop till GitHub API
 */
function github_api(string $method, string $endpoint, array $data = []): array {
    $token = defined('GITHUB_TOKEN') ? GITHUB_TOKEN : '';
    $url = 'https://api.github.com' . $endpoint;

    $headers = [
        "Authorization: Bearer " . $token,
        "Accept: application/vnd.github+json",
        "User-Agent: BosseTemplate/" . BOSSE_VERSION,
        "X-GitHub-Api-Version: 2022-11-28",
    ];

    $options = [
        'http' => [
            'method' => $method,
            'header' => implode("\r\n", $headers) . "\r\n",
            'timeout' => 15,
            'ignore_errors' => true,
        ],
        'ssl' => [
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
    ];

    if (!empty($data)) {
        $json = json_encode($data);
        $options['http']['content'] = $json;
        $options['http']['header'] .= "Content-Type: application/json\r\n";
        $options['http']['header'] .= "Content-Length: " . strlen($json) . "\r\n";
    }

    $context = stream_context_create($options);
    $response = @file_get_contents($url, false, $context);

    if ($response === false) {
        return ['error' => 'Kunde inte nå GitHub API'];
    }

    $decoded = json_decode($response, true);
    if (!is_array($decoded)) {
        return ['error' => 'Ogiltigt svar från GitHub API'];
    }

    // Kolla HTTP-statuskod
    $statusCode = 0;
    $responseHeaders = function_exists('http_get_last_response_headers')
        ? http_get_last_response_headers()
        : ($http_response_header ?? []);
    if (!empty($responseHeaders) && is_array($responseHeaders)) {
        if (preg_match('/HTTP\/[\d.]+ (\d+)/', $responseHeaders[0], $matches)) {
            $statusCode = (int)$matches[1];
        }
    }

    if ($statusCode >= 400) {
        $msg = $decoded['message'] ?? 'HTTP ' . $statusCode;
        return ['error' => 'GitHub API-fel: ' . $msg, 'status' => $statusCode];
    }

    return $decoded;
}

/**
 * Pusha uppdaterade filer till GitHub via Git Data API (atomisk commit)
 */
function push_to_github(array $updatedFiles, string $version): array {
    if (!defined('GITHUB_REPO') || !defined('GITHUB_TOKEN') || GITHUB_REPO === '' || GITHUB_TOKEN === '') {
        return ['success' => false, 'message' => 'GitHub ej konfigurerat — hoppar över push'];
    }

    $repo = GITHUB_REPO;
    $rootPath = defined('ROOT_PATH') ? ROOT_PATH : dirname(__DIR__);

    // Filtrera bort filer som inte finns på disk
    $filesToPush = [];
    foreach ($updatedFiles as $file) {
        $fullPath = $rootPath . '/' . $file;
        if (file_exists($fullPath) && is_file($fullPath)) {
            $filesToPush[] = $file;
        }
    }

    if (empty($filesToPush)) {
        return ['success' => false, 'message' => 'Inga filer att pusha'];
    }

    // 1. Hämta current commit SHA för main
    $ref = github_api('GET', "/repos/{$repo}/git/ref/heads/main");
    if (isset($ref['error'])) {
        return ['success' => false, 'message' => 'Kunde inte hämta branch-ref: ' . $ref['error']];
    }
    $commitSha = $ref['object']['sha'] ?? '';
    if (empty($commitSha)) {
        return ['success' => false, 'message' => 'Kunde inte läsa commit SHA'];
    }

    // 2. Hämta tree SHA från commit
    $commit = github_api('GET', "/repos/{$repo}/git/commits/{$commitSha}");
    if (isset($commit['error'])) {
        return ['success' => false, 'message' => 'Kunde inte hämta commit: ' . $commit['error']];
    }
    $treeSha = $commit['tree']['sha'] ?? '';
    if (empty($treeSha)) {
        return ['success' => false, 'message' => 'Kunde inte läsa tree SHA'];
    }

    // 3. Bygg ny tree med alla uppdaterade filer
    $treeItems = [];
    foreach ($filesToPush as $file) {
        $fullPath = $rootPath . '/' . $file;
        $content = file_get_contents($fullPath);

        // Kolla om binärfil (bilder etc.)
        $finfo = new \finfo(FILEINFO_MIME_TYPE);
        $mime = $finfo->file($fullPath);
        $isBinary = !str_starts_with($mime, 'text/') && !in_array($mime, ['application/json', 'application/javascript', 'application/xml', 'application/x-httpd-php']);

        if ($isBinary) {
            $treeItems[] = [
                'path' => $file,
                'mode' => '100644',
                'type' => 'blob',
                'content' => base64_encode($content),
                'encoding' => 'base64',
            ];
        } else {
            $treeItems[] = [
                'path' => $file,
                'mode' => '100644',
                'type' => 'blob',
                'content' => $content,
            ];
        }
    }

    // Skapa blobs för binärfiler separat (tree API stödjer inte encoding)
    $finalTreeItems = [];
    foreach ($treeItems as $item) {
        if (isset($item['encoding']) && $item['encoding'] === 'base64') {
            // Skapa blob via API
            $blob = github_api('POST', "/repos/{$repo}/git/blobs", [
                'content' => $item['content'],
                'encoding' => 'base64',
            ]);
            if (isset($blob['error'])) {
                return ['success' => false, 'message' => 'Kunde inte skapa blob för ' . $item['path'] . ': ' . $blob['error']];
            }
            $finalTreeItems[] = [
                'path' => $item['path'],
                'mode' => '100644',
                'type' => 'blob',
                'sha' => $blob['sha'],
            ];
        } else {
            $finalTreeItems[] = [
                'path' => $item['path'],
                'mode' => '100644',
                'type' => 'blob',
                'content' => $item['content'],
            ];
        }
    }

    $newTree = github_api('POST', "/repos/{$repo}/git/trees", [
        'base_tree' => $treeSha,
        'tree' => $finalTreeItems,
    ]);
    if (isset($newTree['error'])) {
        return ['success' => false, 'message' => 'Kunde inte skapa tree: ' . $newTree['error']];
    }
    $newTreeSha = $newTree['sha'] ?? '';

    // 4. Skapa ny commit
    $newCommit = github_api('POST', "/repos/{$repo}/git/commits", [
        'message' => "chore: Uppdatera Bosse core-filer till v{$version}",
        'tree' => $newTreeSha,
        'parents' => [$commitSha],
    ]);
    if (isset($newCommit['error'])) {
        return ['success' => false, 'message' => 'Kunde inte skapa commit: ' . $newCommit['error']];
    }
    $newCommitSha = $newCommit['sha'] ?? '';

    // 5. Uppdatera branch-referensen
    $updateRef = github_api('PATCH', "/repos/{$repo}/git/refs/heads/main", [
        'sha' => $newCommitSha,
    ]);
    if (isset($updateRef['error'])) {
        return ['success' => false, 'message' => 'Kunde inte uppdatera branch: ' . $updateRef['error']];
    }

    return [
        'success' => true,
        'message' => count($filesToPush) . ' filer pushade till GitHub',
        'commit_sha' => $newCommitSha,
        'files_pushed' => $filesToPush,
    ];
}

/**
 * Hämta uppdateringslogg
 */
function get_update_log(): array {
    $logFile = DATA_PATH . '/update-log.json';
    if (!file_exists($logFile)) {
        return [];
    }
    $data = json_decode(file_get_contents($logFile), true);
    return is_array($data) ? array_reverse($data) : [];
}
