<?php
/**
 * Peys Badge — Footer banner
 * CORE-fil — skrivs över vid uppdatering
 */
?>
<div class="peys-badge">
    <div class="container">
        <a href="https://peys.se" target="_blank" rel="noopener" class="peys-badge__link">
            <span>Sidan drivs och hanteras av</span>
            <img src="/assets/images/cms/peys-logo-light.png" alt="PEYS" class="peys-badge__logo">
        </a>
    </div>
</div>

<style>
.peys-badge {
    background: #033234;
    padding: var(--spacing-4, 1rem) var(--spacing-4, 1rem);
    text-align: center;
}

.peys-badge__link {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    text-decoration: none;
    color: rgba(255, 255, 255, 0.7);
    font-size: 13px;
    line-height: 1;
    transition: color 0.2s;
}

.peys-badge__link:hover {
    color: white;
    text-decoration: none;
}

.peys-badge__logo {
    height: 18px;
    width: auto;
    opacity: 0.8;
    transition: opacity 0.2s;
}

.peys-badge__link:hover .peys-badge__logo {
    opacity: 1;
}
</style>
