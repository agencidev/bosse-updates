<?php
/**
 * CMS Settings Page
 * Allows editing site configuration after initial setup
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../security/session.php';
require_once __DIR__ . '/../security/csrf.php';
require_once __DIR__ . '/../includes/version.php';

// Inkludera helpers om den finns, annars definiera inline (bakåtkompatibilitet)
$helpersFile = __DIR__ . '/helpers.php';
if (file_exists($helpersFile)) {
    require_once $helpersFile;
}
if (!function_exists('convertToBytes')) {
    function convertToBytes(string $value): int {
        $value = trim($value);
        $unit = strtolower(substr($value, -1));
        $bytes = (int) $value;
        $bytes *= match ($unit) {
            'g' => 1024 * 1024 * 1024,
            'm' => 1024 * 1024,
            'k' => 1024,
            default => 1,
        };
        return $bytes;
    }
}
if (!function_exists('adjustBrightness')) {
    function adjustBrightness(string $hex, int $percent): string {
        $hex = ltrim($hex, '#');
        if (strlen($hex) === 3) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        if ($percent > 0) {
            $r = $r + (255 - $r) * $percent / 100;
            $g = $g + (255 - $g) * $percent / 100;
            $b = $b + (255 - $b) * $percent / 100;
        } else {
            $factor = (100 + $percent) / 100;
            $r = $r * $factor;
            $g = $g * $factor;
            $b = $b * $factor;
        }
        $r = max(0, min(255, round($r)));
        $g = max(0, min(255, round($g)));
        $b = max(0, min(255, round($b)));
        return '#' . str_pad(dechex($r), 2, '0', STR_PAD_LEFT)
                   . str_pad(dechex($g), 2, '0', STR_PAD_LEFT)
                   . str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
    }
}

if (!is_logged_in()) {
    header('Location: /cms/admin.php');
    exit;
}

$error = '';

// Load current values from config and CSS
$currentConfig = [
    'site_name' => defined('SITE_NAME') ? SITE_NAME : '',
    'site_description' => defined('SITE_DESCRIPTION') ? SITE_DESCRIPTION : '',
    'contact_email' => defined('CONTACT_EMAIL') ? CONTACT_EMAIL : '',
    'contact_phone' => defined('CONTACT_PHONE') ? CONTACT_PHONE : '',
    'site_url' => defined('SITE_URL') ? SITE_URL : '',
    'social_facebook' => defined('SOCIAL_FACEBOOK') ? SOCIAL_FACEBOOK : '',
    'social_instagram' => defined('SOCIAL_INSTAGRAM') ? SOCIAL_INSTAGRAM : '',
    'social_linkedin' => defined('SOCIAL_LINKEDIN') ? SOCIAL_LINKEDIN : '',
    'hours_weekdays' => defined('HOURS_WEEKDAYS') ? HOURS_WEEKDAYS : '',
    'hours_weekends' => defined('HOURS_WEEKENDS') ? HOURS_WEEKENDS : '',
    'ga_id' => defined('GOOGLE_ANALYTICS_ID') ? GOOGLE_ANALYTICS_ID : '',
    'smtp_host' => defined('SMTP_HOST') ? SMTP_HOST : '',
    'smtp_port' => defined('SMTP_PORT') ? SMTP_PORT : 465,
    'smtp_encryption' => defined('SMTP_ENCRYPTION') ? SMTP_ENCRYPTION : 'ssl',
    'smtp_username' => defined('SMTP_USERNAME') ? SMTP_USERNAME : '',
];

// Read colors from variables.css
$cssFile = __DIR__ . '/../assets/css/variables.css';
$primaryColor = '#379b83';
$secondaryColor = '#FF6B35';
$accentColor = '#379b83';

if (file_exists($cssFile)) {
    $css = file_get_contents($cssFile);
    if (preg_match('/--color-primary:\s*(#[0-9a-fA-F]{6})/', $css, $m)) {
        $primaryColor = $m[1];
    }
    if (preg_match('/--color-secondary:\s*(#[0-9a-fA-F]{6})/', $css, $m)) {
        $secondaryColor = $m[1];
    }
    if (preg_match('/--color-accent:\s*(#[0-9a-fA-F]{6})/', $css, $m)) {
        $accentColor = $m[1];
    }
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Detektera om POST-data trunkerades pga PHP-gränser
    $contentLength = $_SERVER['CONTENT_LENGTH'] ?? 0;
    $postMaxSize = ini_get('post_max_size');
    $postMaxBytes = convertToBytes($postMaxSize);

    if ($contentLength > $postMaxBytes || (empty($_POST) && $contentLength > 0)) {
        $error = 'Filen är för stor för servern. Max uppladdningsstorlek: ' . $postMaxSize . '. Kontakta din webbhost för att öka gränsen.';
    } else {
        csrf_require();
    }

    $section = $_POST['section'] ?? '';

    if ($section === 'site_info') {
        // Update site info
        $newName = trim($_POST['site_name'] ?? '');
        $newDesc = trim($_POST['site_description'] ?? '');
        $newEmail = trim($_POST['contact_email'] ?? '');
        $newPhone = trim($_POST['contact_phone'] ?? '');

        if (empty($newName)) {
            $error = 'Företagsnamn krävs.';
        } elseif (!filter_var($newEmail, FILTER_VALIDATE_EMAIL)) {
            $error = 'Giltig e-postadress krävs.';
        } else {
            // Update config.php
            $configPath = ROOT_PATH . '/config.php';
            if (file_exists($configPath)) {
                if (function_exists('backup_config')) backup_config();
                $config = file_get_contents($configPath);
                $failures = [];

                $r = safe_config_replace("/define\('SITE_NAME',\s*'[^']*'\);/", "define('SITE_NAME', " . var_export($newName, true) . ");", $config, 'SITE_NAME');
                $config = $r['config']; if (!$r['success']) $failures[] = 'SITE_NAME';

                $r = safe_config_replace("/define\('SITE_DESCRIPTION',\s*'[^']*'\);/", "define('SITE_DESCRIPTION', " . var_export($newDesc, true) . ");", $config, 'SITE_DESCRIPTION');
                $config = $r['config']; if (!$r['success']) $failures[] = 'SITE_DESCRIPTION';

                $r = safe_config_replace("/define\('CONTACT_EMAIL',\s*'[^']*'\);/", "define('CONTACT_EMAIL', " . var_export($newEmail, true) . ");", $config, 'CONTACT_EMAIL');
                $config = $r['config']; if (!$r['success']) $failures[] = 'CONTACT_EMAIL';

                $r = safe_config_replace("/define\('CONTACT_PHONE',\s*'[^']*'\);/", "define('CONTACT_PHONE', " . var_export($newPhone, true) . ");", $config, 'CONTACT_PHONE');
                $config = $r['config']; if (!$r['success']) $failures[] = 'CONTACT_PHONE';

                file_put_contents($configPath, $config, LOCK_EX);

                if (!empty($failures)) {
                    $error = 'Varning: Kunde inte uppdatera: ' . implode(', ', $failures) . '. Kontrollera config.php manuellt.';
                } else {
                    header('Location: /settings?msg=saved'); exit;
                }
            }
        }
    } elseif ($section === 'colors') {
        // Update colors in variables.css
        $newPrimary = $_POST['primary_color'] ?? $primaryColor;
        $newSecondary = $_POST['secondary_color'] ?? $secondaryColor;
        $newAccent = $_POST['accent_color'] ?? $accentColor;

        if (file_exists($cssFile)) {
            $css = file_get_contents($cssFile);
            $css = preg_replace('/(--color-primary:\s*)#[0-9a-fA-F]{6}/', '${1}' . $newPrimary, $css);
            $css = preg_replace('/(--color-secondary:\s*)#[0-9a-fA-F]{6}/', '${1}' . $newSecondary, $css);
            $css = preg_replace('/(--color-accent:\s*)#[0-9a-fA-F]{6}/', '${1}' . $newAccent, $css);

            // Update dark/light variants
            $primaryDark = adjustBrightness($newPrimary, -15);
            $primaryLight = adjustBrightness($newPrimary, 20);
            $secondaryDark = adjustBrightness($newSecondary, -15);

            $css = preg_replace('/(--color-primary-dark:\s*)#[0-9a-fA-F]{6}/', '${1}' . $primaryDark, $css);
            $css = preg_replace('/(--color-primary-light:\s*)#[0-9a-fA-F]{6}/', '${1}' . $primaryLight, $css);
            $css = preg_replace('/(--color-secondary-dark:\s*)#[0-9a-fA-F]{6}/', '${1}' . $secondaryDark, $css);

            file_put_contents($cssFile, $css, LOCK_EX);
            header('Location: /settings?msg=saved'); exit;
        }
    } elseif ($section === 'social') {
        // Update social media links
        $newFacebook = trim($_POST['social_facebook'] ?? '');
        $newInstagram = trim($_POST['social_instagram'] ?? '');
        $newLinkedin = trim($_POST['social_linkedin'] ?? '');

        $configPath = ROOT_PATH . '/config.php';
        if (file_exists($configPath)) {
            if (function_exists('backup_config')) backup_config();
            $config = file_get_contents($configPath);

            // Handle Facebook
            if (preg_match("/define\('SOCIAL_FACEBOOK'/", $config)) {
                $config = preg_replace("/define\('SOCIAL_FACEBOOK',\s*'[^']*'\);/", "define('SOCIAL_FACEBOOK', " . var_export($newFacebook, true) . ");", $config);
            } elseif (!empty($newFacebook)) {
                $config = preg_replace("/(\/\/ Environment)/", "// Sociala medier\ndefine('SOCIAL_FACEBOOK', " . var_export($newFacebook, true) . ");\n\n$1", $config);
            }

            // Handle Instagram
            if (preg_match("/define\('SOCIAL_INSTAGRAM'/", $config)) {
                $config = preg_replace("/define\('SOCIAL_INSTAGRAM',\s*'[^']*'\);/", "define('SOCIAL_INSTAGRAM', " . var_export($newInstagram, true) . ");", $config);
            } elseif (!empty($newInstagram)) {
                $config = preg_replace("/(\/\/ Environment)/", "define('SOCIAL_INSTAGRAM', " . var_export($newInstagram, true) . ");\n\n$1", $config);
            }

            // Handle LinkedIn
            if (preg_match("/define\('SOCIAL_LINKEDIN'/", $config)) {
                $config = preg_replace("/define\('SOCIAL_LINKEDIN',\s*'[^']*'\);/", "define('SOCIAL_LINKEDIN', " . var_export($newLinkedin, true) . ");", $config);
            } elseif (!empty($newLinkedin)) {
                $config = preg_replace("/(\/\/ Environment)/", "define('SOCIAL_LINKEDIN', " . var_export($newLinkedin, true) . ");\n\n$1", $config);
            }

            file_put_contents($configPath, $config, LOCK_EX);
            header('Location: /settings?msg=saved'); exit;
        }
    } elseif ($section === 'logos') {
        // Handle logo uploads - använd samma mönster som projects/new.php
        $imgDir = __DIR__ . '/../assets/images';

        if (!is_dir($imgDir)) {
            mkdir($imgDir, 0755, true);
        }

        $allowedMimes = ['image/png', 'image/jpeg', 'image/svg+xml', 'image/webp'];
        $maxSize = 5 * 1024 * 1024;
        $uploadErrors = [];
        $uploadedAny = false;

        foreach (['logo_dark', 'logo_light'] as $logoField) {
            // Kontrollera om fil valts
            if (!isset($_FILES[$logoField]) || $_FILES[$logoField]['error'] === UPLOAD_ERR_NO_FILE) {
                continue; // Ingen fil vald för detta fält, helt ok
            }

            // Hantera upload-fel
            $uploadErr = $_FILES[$logoField]['error'];
            if ($uploadErr !== UPLOAD_ERR_OK) {
                $errMsg = match($uploadErr) {
                    UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'Filen är för stor (max 5MB)',
                    UPLOAD_ERR_PARTIAL => 'Uppladdningen avbröts',
                    UPLOAD_ERR_NO_TMP_DIR => 'Serverfel: Temp-mapp saknas',
                    UPLOAD_ERR_CANT_WRITE => 'Serverfel: Kan inte skriva till disk',
                    UPLOAD_ERR_EXTENSION => 'Uppladdning blockerad av server',
                    default => 'Uppladdningsfel (kod ' . $uploadErr . ')',
                };
                $uploadErrors[] = ucfirst(str_replace('_', ' ', $logoField)) . ': ' . $errMsg;
                continue;
            }

            // Validera MIME-typ
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mime = $finfo->file($_FILES[$logoField]['tmp_name']);

            if (in_array($mime, $allowedMimes) && $_FILES[$logoField]['size'] <= $maxSize) {
                $ext = strtolower(pathinfo($_FILES[$logoField]['name'], PATHINFO_EXTENSION));
                if (!in_array($ext, ['png', 'jpg', 'jpeg', 'svg', 'webp'])) {
                    $ext = 'png';
                }
                $destFile = str_replace('_', '-', $logoField) . '.' . $ext;
                $destPath = $imgDir . '/' . $destFile;

                // Ta bort gamla logofiler med andra ändelser
                foreach (['png', 'jpg', 'jpeg', 'svg', 'webp'] as $oldExt) {
                    $oldFile = $imgDir . '/' . str_replace('_', '-', $logoField) . '.' . $oldExt;
                    if (file_exists($oldFile) && $oldFile !== $destPath) {
                        @unlink($oldFile);
                    }
                }

                if (move_uploaded_file($_FILES[$logoField]['tmp_name'], $destPath)) {
                    $uploadedAny = true;
                } else {
                    $uploadErrors[] = ucfirst(str_replace('_', ' ', $logoField)) . ': Kunde inte spara till disk.';
                }
            } else {
                $uploadErrors[] = ucfirst(str_replace('_', ' ', $logoField)) . ': Ogiltigt format eller för stor (max 5MB).';
            }
        }

        if (!empty($uploadErrors)) {
            $error = implode(' ', $uploadErrors);
        } elseif ($uploadedAny) {
            header('Location: /settings?msg=saved'); exit;
        } else {
            $error = 'Ingen fil vald. Välj minst en logotyp att ladda upp.';
        }
    } elseif ($section === 'delete_logo') {
        // Ta bort logotyp
        $logoType = $_POST['logo_type'] ?? '';
        if (in_array($logoType, ['logo-dark', 'logo-light'])) {
            $imgDir = __DIR__ . '/../assets/images';
            $deleted = false;
            foreach (['png', 'jpg', 'jpeg', 'svg', 'webp'] as $ext) {
                $file = $imgDir . '/' . $logoType . '.' . $ext;
                if (file_exists($file)) {
                    @unlink($file);
                    $deleted = true;
                }
            }
            header('Location: /settings?msg=saved'); exit;
        }
    } elseif ($section === 'favicon') {
        // Handle favicon upload
        $imgDir = __DIR__ . '/../assets/images';

        if (!is_dir($imgDir)) {
            mkdir($imgDir, 0755, true);
        }

        // Kontrollera om fil valts
        if (!isset($_FILES['favicon']) || $_FILES['favicon']['error'] === UPLOAD_ERR_NO_FILE) {
            $error = 'Ingen fil vald.';
        } else {
            // Hantera upload-fel
            $uploadErr = $_FILES['favicon']['error'];
            if ($uploadErr !== UPLOAD_ERR_OK) {
                $error = match($uploadErr) {
                    UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'Filen är för stor (max 1MB)',
                    UPLOAD_ERR_PARTIAL => 'Uppladdningen avbröts',
                    UPLOAD_ERR_NO_TMP_DIR => 'Serverfel: Temp-mapp saknas',
                    UPLOAD_ERR_CANT_WRITE => 'Serverfel: Kan inte skriva till disk',
                    UPLOAD_ERR_EXTENSION => 'Uppladdning blockerad av server',
                    default => 'Uppladdningsfel (kod ' . $uploadErr . ')',
                };
            } else {
                $faviconMimes = ['image/png', 'image/x-icon', 'image/vnd.microsoft.icon', 'image/svg+xml'];
                $finfo = new finfo(FILEINFO_MIME_TYPE);
                $mime = $finfo->file($_FILES['favicon']['tmp_name']);

                if (in_array($mime, $faviconMimes) && $_FILES['favicon']['size'] <= 1024 * 1024) {
                    $ext = strtolower(pathinfo($_FILES['favicon']['name'], PATHINFO_EXTENSION));

                    // Ta bort gamla favicon-filer
                    @unlink($imgDir . '/favicon.png');
                    @unlink($imgDir . '/favicon.ico');
                    @unlink($imgDir . '/favicon.svg');

                    if ($ext === 'ico') {
                        $destPath = $imgDir . '/favicon.ico';
                    } elseif ($ext === 'svg') {
                        $destPath = $imgDir . '/favicon.svg';
                    } else {
                        $destPath = $imgDir . '/favicon.png';
                    }

                    if (move_uploaded_file($_FILES['favicon']['tmp_name'], $destPath)) {
                        header('Location: /settings?msg=saved'); exit;
                    } else {
                        $error = 'Kunde inte spara favicon till disk.';
                    }
                } else {
                    $error = 'Favicon: Ogiltigt format eller för stor fil (max 1MB).';
                }
            }
        }
    } elseif ($section === 'delete_favicon') {
        // Ta bort favicon
        $imgDir = __DIR__ . '/../assets/images';
        @unlink($imgDir . '/favicon.png');
        @unlink($imgDir . '/favicon.ico');
        @unlink($imgDir . '/favicon.svg');
        header('Location: /settings?msg=saved'); exit;
    } elseif ($section === 'smtp') {
        // Update SMTP settings
        $smtpHost = trim($_POST['smtp_host'] ?? '');
        $smtpPort = (int)($_POST['smtp_port'] ?? 465);
        $smtpEncryption = $_POST['smtp_encryption'] ?? 'ssl';
        $smtpUsername = trim($_POST['smtp_username'] ?? '');
        $smtpPassword = $_POST['smtp_password'] ?? '';

        // Validate
        if (!empty($smtpHost)) {
            if ($smtpPort < 1 || $smtpPort > 65535) {
                $error = 'Ange en giltig SMTP-port (1-65535).';
            } elseif (empty($smtpUsername)) {
                $error = 'SMTP-användarnamn krävs.';
            } elseif (empty($smtpPassword) && !defined('SMTP_PASSWORD')) {
                $error = 'SMTP-lösenord krävs.';
            } elseif (!in_array($smtpEncryption, ['ssl', 'tls'])) {
                $error = 'Ogiltig kryptering.';
            }
        }

        if (empty($error)) {
            $configPath = ROOT_PATH . '/config.php';
            if (file_exists($configPath)) {
                if (function_exists('backup_config')) backup_config();
                $config = file_get_contents($configPath);

                // Check if SMTP section exists
                if (preg_match("/define\('SMTP_HOST'/", $config)) {
                    // Update existing
                    $failures = [];
                    $r = safe_config_replace("/define\('SMTP_HOST',\s*'[^']*'\);/", "define('SMTP_HOST', " . var_export($smtpHost, true) . ");", $config, 'SMTP_HOST');
                    $config = $r['config']; if (!$r['success']) $failures[] = 'SMTP_HOST';

                    $r = safe_config_replace("/define\('SMTP_PORT',\s*\d+\);/", "define('SMTP_PORT', " . $smtpPort . ");", $config, 'SMTP_PORT');
                    $config = $r['config']; if (!$r['success']) $failures[] = 'SMTP_PORT';

                    $r = safe_config_replace("/define\('SMTP_ENCRYPTION',\s*'[^']*'\);/", "define('SMTP_ENCRYPTION', " . var_export($smtpEncryption, true) . ");", $config, 'SMTP_ENCRYPTION');
                    $config = $r['config']; if (!$r['success']) $failures[] = 'SMTP_ENCRYPTION';

                    $r = safe_config_replace("/define\('SMTP_USERNAME',\s*'[^']*'\);/", "define('SMTP_USERNAME', " . var_export($smtpUsername, true) . ");", $config, 'SMTP_USERNAME');
                    $config = $r['config']; if (!$r['success']) $failures[] = 'SMTP_USERNAME';

                    if (!empty($smtpPassword)) {
                        $r = safe_config_replace("/define\('SMTP_PASSWORD',\s*'[^']*'\);/", "define('SMTP_PASSWORD', " . var_export($smtpPassword, true) . ");", $config, 'SMTP_PASSWORD');
                        $config = $r['config']; if (!$r['success']) $failures[] = 'SMTP_PASSWORD';
                    }

                    if (!empty($failures)) {
                        $error = 'Varning: Kunde inte uppdatera: ' . implode(', ', $failures);
                    }
                } elseif (!empty($smtpHost)) {
                    // Add new SMTP section
                    $smtpBlock = "\n// SMTP\n";
                    $smtpBlock .= "define('SMTP_HOST', " . var_export($smtpHost, true) . ");\n";
                    $smtpBlock .= "define('SMTP_PORT', " . $smtpPort . ");\n";
                    $smtpBlock .= "define('SMTP_ENCRYPTION', " . var_export($smtpEncryption, true) . ");\n";
                    $smtpBlock .= "define('SMTP_USERNAME', " . var_export($smtpUsername, true) . ");\n";
                    $smtpBlock .= "define('SMTP_PASSWORD', " . var_export($smtpPassword, true) . ");\n";
                    $config = preg_replace("/(\/\/ Environment)/", $smtpBlock . "\n$1", $config);
                }

                file_put_contents($configPath, $config, LOCK_EX);
                header('Location: /settings?msg=saved'); exit;
            }
        }
    } elseif ($section === 'password') {
        $currentPassword = $_POST['current_password'] ?? '';
        $newPassword = $_POST['new_password'] ?? '';
        $confirmPassword = $_POST['confirm_password'] ?? '';

        if (!defined('ADMIN_PASSWORD_HASH') || !password_verify($currentPassword, ADMIN_PASSWORD_HASH)) {
            $error = 'Nuvarande lösenord är felaktigt.';
        } elseif (strlen($newPassword) < 8) {
            $error = 'Nytt lösenord måste vara minst 8 tecken.';
        } elseif ($newPassword !== $confirmPassword) {
            $error = 'Lösenorden matchar inte.';
        } else {
            $configPath = ROOT_PATH . '/config.php';
            if (file_exists($configPath)) {
                if (function_exists('backup_config')) backup_config();
                $config = file_get_contents($configPath);
                $newHash = password_hash($newPassword, PASSWORD_BCRYPT);
                $replacement = "define('ADMIN_PASSWORD_HASH', " . var_export($newHash, true) . ");";
                $config = preg_replace(
                    "/define\('ADMIN_PASSWORD_HASH',\s*'[^']*'\);/",
                    addcslashes($replacement, '\\$'),
                    $config
                );
                file_put_contents($configPath, $config, LOCK_EX);
                header('Location: /settings?msg=saved'); exit;
            }
        }
    }
}

?>
<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inställningar - CMS</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'DM Sans', sans-serif;
            background-color: #033234;
            min-height: 100vh;
            color: rgba(255,255,255,1.0);
        }
        .page-content {
            padding: 3rem 1.5rem;
        }
        .container {
            max-width: 52rem;
            margin: 0 auto;
        }
        .back-link {
            display: inline-block;
            color: rgba(255,255,255,0.50);
            text-decoration: none;
            font-size: 0.875rem;
            margin-bottom: 1rem;
            transition: color 0.2s;
        }
        .back-link:hover { color: rgba(255,255,255,1.0); }
        .title {
            font-size: 2rem;
            font-weight: bold;
            color: rgba(255,255,255,1.0);
            margin-bottom: 0.5rem;
        }
        .subtitle {
            font-size: 1rem;
            color: rgba(255,255,255,0.50);
            margin-bottom: 2rem;
        }
        .card {
            background: rgba(255,255,255,0.05);
            border-radius: 1rem;
            border: 1px solid rgba(255,255,255,0.10);
            padding: 1.5rem;
            margin-bottom: 1.5rem;
        }
        .card-title {
            font-size: 1rem;
            font-weight: 700;
            color: rgba(255,255,255,1.0);
            margin-bottom: 1rem;
            padding-bottom: 0.75rem;
            border-bottom: 1px solid rgba(255,255,255,0.10);
        }
        .form-group {
            margin-bottom: 1rem;
        }
        .form-label {
            display: block;
            font-size: 0.875rem;
            font-weight: 600;
            color: rgba(255,255,255,1.0);
            margin-bottom: 0.375rem;
        }
        .form-input, .form-textarea {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid rgba(255,255,255,0.15);
            border-radius: 0.5rem;
            font-size: 1rem;
            font-family: inherit;
            outline: none;
            transition: all 0.2s;
            background-color: rgba(255,255,255,0.05);
            color: white;
        }
        .form-input:focus, .form-textarea:focus {
            border-color: #379b83;
            box-shadow: 0 0 0 3px rgba(55, 155, 131, 0.1);
        }
        .form-textarea {
            resize: vertical;
            min-height: 80px;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        .color-group {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .color-group input[type="color"] {
            width: 48px;
            height: 40px;
            padding: 2px;
            border: 1px solid rgba(255,255,255,0.15);
            border-radius: 0.5rem;
            cursor: pointer;
        }
        .color-group input[type="text"] {
            flex: 1;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.75rem 1.5rem;
            border-radius: 9999px;
            font-size: 0.875rem;
            font-weight: 600;
            cursor: pointer;
            border: none;
            transition: all 0.2s;
        }
        .btn-primary {
            background: #379b83;
            color: white;
        }
        .btn-primary:hover {
            background: #2e8570;
        }
        .btn-danger {
            background: #fef2f2;
            color: #dc2626;
            border: 1px solid #fecaca;
        }
        .btn-danger:hover {
            background: #fee2e2;
        }
        .btn-sm {
            padding: 0.375rem 0.75rem;
            font-size: 0.75rem;
        }
        .alert {
            padding: 0.875rem 1rem;
            border-radius: 0.5rem;
            font-size: 0.875rem;
            margin-bottom: 1.5rem;
        }
        .alert-error {
            background: #fef2f2;
            border: 1px solid #fecaca;
            color: #dc2626;
        }
        .file-upload {
            border: 2px dashed rgba(255,255,255,0.15);
            border-radius: 0.5rem;
            padding: 1rem;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s;
            position: relative;
        }
        .file-upload:hover {
            border-color: #379b83;
            background: rgba(55, 155, 131, 0.1);
        }
        .file-upload input[type="file"] {
            position: absolute;
            inset: 0;
            opacity: 0;
            cursor: pointer;
        }
        .file-upload-text {
            font-size: 0.8125rem;
            color: rgba(255,255,255,0.50);
        }
        .file-upload-text strong {
            color: #379b83;
        }
        .current-logo {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            margin-bottom: 0.5rem;
            padding: 0.5rem;
            background: rgba(255,255,255,0.08);
            border-radius: 0.5rem;
        }
        .current-logo img {
            height: 32px;
            width: auto;
        }
        .current-logo span {
            font-size: 0.75rem;
            color: rgba(255,255,255,0.50);
        }
        .hint {
            font-size: 0.75rem;
            color: rgba(255,255,255,0.50);
            margin-top: 0.25rem;
        }
        .system-info-grid {
            display: flex;
            flex-direction: column;
            gap: 0.75rem;
        }
        .system-info-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0.5rem 0;
            border-bottom: 1px solid rgba(255,255,255,0.10);
        }
        .system-info-item:last-child {
            border-bottom: none;
        }
        .system-info-label {
            font-size: 0.875rem;
            color: rgba(255,255,255,0.50);
        }
        .system-info-value {
            font-size: 0.875rem;
            font-weight: 600;
            color: rgba(255,255,255,1.0);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }
        .status-badge-ok {
            background: #dcfce7;
            color: #166534;
            font-size: 0.625rem;
            padding: 0.125rem 0.5rem;
            border-radius: 9999px;
            font-weight: 600;
        }
        .status-badge-warning {
            background: #fef3c7;
            color: #92400e;
            font-size: 0.625rem;
            padding: 0.125rem 0.5rem;
            border-radius: 9999px;
            font-weight: 600;
        }
        .status-badge-critical {
            background: #fee2e2;
            color: #dc2626;
            font-size: 0.625rem;
            padding: 0.125rem 0.5rem;
            border-radius: 9999px;
            font-weight: 600;
        }
        .system-info-hint {
            font-size: 0.75rem;
            padding: 0.75rem;
            border-radius: 0.5rem;
            margin-top: -0.25rem;
        }
        .hint-warning {
            background: #fef3c7;
            color: #92400e;
        }
        .hint-critical {
            background: #fee2e2;
            color: #dc2626;
        }
        .logo-preview {
            display: none;
            max-height: 60px;
            max-width: 100%;
            margin-top: 0.5rem;
            border-radius: 0.25rem;
            border: 1px solid rgba(255,255,255,0.10);
            padding: 0.25rem;
            background: rgba(255,255,255,0.08);
        }
        .logo-preview.dark-bg {
            background: #333;
        }
        .file-selected {
            border-color: #22c55e !important;
            background: #f0fdf4 !important;
        }
        .file-selected .file-upload-text {
            color: #166534;
        }

        /* Responsive */
        @media (max-width: 640px) {
            .form-row { grid-template-columns: 1fr !important; }
            .color-row { grid-template-columns: 1fr !important; }
        }

        /* Word break for long values */
        .system-info-value { word-break: break-word; overflow-wrap: break-word; }
    </style>
<?php if (function_exists("agency_cms_theme")) { echo agency_cms_theme(); echo agency_cms_fonts(); } ?>
</head>
<body>
    <?php include __DIR__ . '/../includes/admin-bar.php'; ?>
    <div class="page-content">
        <div class="container">
            <a href="/dashboard" class="back-link">&larr; Tillbaka till dashboard</a>

            <h1 class="title">Inställningar</h1>
            <p class="subtitle">Hantera webbplatsens konfiguration</p>


            <?php if ($error): ?>
            <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>

            <!-- Site Info -->
            <div class="card">
                <h2 class="card-title">Företagsinformation</h2>
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="section" value="site_info">

                    <div class="form-group">
                        <label class="form-label" for="site_name">Företagsnamn</label>
                        <input type="text" id="site_name" name="site_name" class="form-input"
                               value="<?php echo htmlspecialchars($currentConfig['site_name']); ?>" required>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="site_description">Beskrivning</label>
                        <textarea id="site_description" name="site_description" class="form-textarea"><?php echo htmlspecialchars($currentConfig['site_description']); ?></textarea>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="contact_email">E-post</label>
                            <input type="email" id="contact_email" name="contact_email" class="form-input"
                                   value="<?php echo htmlspecialchars($currentConfig['contact_email']); ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="contact_phone">Telefon</label>
                            <input type="tel" id="contact_phone" name="contact_phone" class="form-input"
                                   value="<?php echo htmlspecialchars($currentConfig['contact_phone']); ?>">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">Spara</button>
                </form>
            </div>

            <!-- Colors -->
            <div class="card">
                <h2 class="card-title">Färger</h2>
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="section" value="colors">

                    <div class="form-row color-row" style="grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));">
                        <div class="form-group">
                            <label class="form-label">Primärfärg</label>
                            <div class="color-group">
                                <input type="color" id="primary_color" name="primary_color"
                                       value="<?php echo htmlspecialchars($primaryColor); ?>"
                                       data-sync="primary_text">
                                <input type="text" id="primary_text" class="form-input"
                                       value="<?php echo htmlspecialchars($primaryColor); ?>"
                                       data-sync="primary_color"
                                       pattern="#[0-9a-fA-F]{6}" maxlength="7">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Sekundärfärg</label>
                            <div class="color-group">
                                <input type="color" id="secondary_color" name="secondary_color"
                                       value="<?php echo htmlspecialchars($secondaryColor); ?>"
                                       data-sync="secondary_text">
                                <input type="text" id="secondary_text" class="form-input"
                                       value="<?php echo htmlspecialchars($secondaryColor); ?>"
                                       data-sync="secondary_color"
                                       pattern="#[0-9a-fA-F]{6}" maxlength="7">
                            </div>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Accentfärg</label>
                            <div class="color-group">
                                <input type="color" id="accent_color" name="accent_color"
                                       value="<?php echo htmlspecialchars($accentColor); ?>"
                                       data-sync="accent_text">
                                <input type="text" id="accent_text" class="form-input"
                                       value="<?php echo htmlspecialchars($accentColor); ?>"
                                       data-sync="accent_color"
                                       pattern="#[0-9a-fA-F]{6}" maxlength="7">
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">Spara</button>
                </form>
            </div>

            <!-- Logos -->
            <div class="card">
                <h2 class="card-title">Logotyper</h2>
                <form method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="section" value="logos">

                    <?php
                    // Hitta logotypfiler oavsett filändelse
                    $imgBase = __DIR__ . '/../assets/images';
                    function findLogoFile($baseName, $imgBase) {
                        $extensions = ['png', 'jpg', 'jpeg', 'svg', 'webp'];
                        foreach ($extensions as $ext) {
                            $path = $imgBase . '/' . $baseName . '.' . $ext;
                            if (file_exists($path)) {
                                return '/assets/images/' . $baseName . '.' . $ext;
                            }
                        }
                        return null;
                    }
                    $logoDarkPath = findLogoFile('logo-dark', $imgBase);
                    $logoLightPath = findLogoFile('logo-light', $imgBase);
                    ?>
                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label">Mörk logotyp</label>
                            <p class="hint">För ljusa bakgrunder</p>
                            <?php if ($logoDarkPath): ?>
                            <div class="current-logo">
                                <img src="<?php echo $logoDarkPath; ?>?v=<?php echo time(); ?>" alt="Nuvarande">
                                <span>Nuvarande</span>
                            </div>
                            <?php endif; ?>
                            <div class="file-upload" id="upload-dark">
                                <input type="file" name="logo_dark" accept=".png,.jpg,.jpeg,.svg,.webp" data-preview-logo="preview-dark" data-upload-box="upload-dark">
                                <div class="file-upload-text">
                                    <strong>Välj fil</strong> eller dra hit<br>
                                    <small>PNG, JPG, SVG, WebP</small>
                                </div>
                            </div>
                            <img class="logo-preview" id="preview-dark" alt="Förhandsgranskning">
                        </div>
                        <div class="form-group">
                            <label class="form-label">Ljus logotyp</label>
                            <p class="hint">För mörka bakgrunder</p>
                            <?php if ($logoLightPath): ?>
                            <div class="current-logo">
                                <img src="<?php echo $logoLightPath; ?>?v=<?php echo time(); ?>" alt="Nuvarande" style="background: #333; padding: 4px; border-radius: 4px;">
                                <span>Nuvarande</span>
                            </div>
                            <?php endif; ?>
                            <div class="file-upload" id="upload-light">
                                <input type="file" name="logo_light" accept=".png,.jpg,.jpeg,.svg,.webp" data-preview-logo="preview-light" data-upload-box="upload-light">
                                <div class="file-upload-text">
                                    <strong>Välj fil</strong> eller dra hit<br>
                                    <small>PNG, JPG, SVG, WebP</small>
                                </div>
                            </div>
                            <img class="logo-preview dark-bg" id="preview-light" alt="Förhandsgranskning">
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">Ladda upp</button>
                </form>

                <?php if ($logoDarkPath || $logoLightPath): ?>
                <div style="display: flex; gap: 1rem; margin-top: 1rem; padding-top: 1rem; border-top: 1px solid rgba(255,255,255,0.10);">
                    <?php if ($logoDarkPath): ?>
                    <form method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="section" value="delete_logo">
                        <input type="hidden" name="logo_type" value="logo-dark">
                        <button type="submit" class="btn btn-danger btn-sm" data-confirm="Ta bort mörk logotyp?">Ta bort mörk</button>
                    </form>
                    <?php endif; ?>
                    <?php if ($logoLightPath): ?>
                    <form method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="section" value="delete_logo">
                        <input type="hidden" name="logo_type" value="logo-light">
                        <button type="submit" class="btn btn-danger btn-sm" data-confirm="Ta bort ljus logotyp?">Ta bort ljus</button>
                    </form>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </div>

            <!-- Favicon -->
            <div class="card">
                <h2 class="card-title">Favicon</h2>
                <form method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="section" value="favicon">

                    <div class="form-group">
                        <label class="form-label">Favicon</label>
                        <p class="hint">Liten ikon som visas i webbläsarfliken</p>
                        <?php
                        $imgDirCheck = __DIR__ . '/../assets/images';
                        $hasFavicon = file_exists($imgDirCheck . '/favicon.png') || file_exists($imgDirCheck . '/favicon.ico') || file_exists($imgDirCheck . '/favicon.svg');
                        $faviconPath = file_exists($imgDirCheck . '/favicon.ico') ? '/assets/images/favicon.ico' : (file_exists($imgDirCheck . '/favicon.svg') ? '/assets/images/favicon.svg' : '/assets/images/favicon.png');
                        ?>
                        <?php if ($hasFavicon): ?>
                        <div class="current-logo">
                            <img src="<?php echo $faviconPath; ?>?v=<?php echo time(); ?>" alt="Nuvarande favicon" style="width: 32px; height: 32px;">
                            <span>Nuvarande favicon</span>
                        </div>
                        <?php endif; ?>
                        <div class="file-upload" id="upload-favicon">
                            <input type="file" name="favicon" accept=".png,.ico,.svg" data-preview-favicon="true">
                            <div class="file-upload-text">
                                <strong>Välj fil</strong> eller dra hit<br>
                                <small>PNG, ICO, SVG (max 1MB, rekommenderat 32x32px)</small>
                            </div>
                        </div>
                        <img class="logo-preview" id="preview-favicon" alt="Förhandsgranskning" style="max-height: 32px;">
                    </div>

                    <button type="submit" class="btn btn-primary">Ladda upp</button>
                </form>

                <?php if ($hasFavicon): ?>
                <form method="POST" style="margin-top: 1rem; padding-top: 1rem; border-top: 1px solid rgba(255,255,255,0.10);">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="section" value="delete_favicon">
                    <button type="submit" class="btn btn-danger btn-sm" data-confirm="Ta bort favicon?">Ta bort favicon</button>
                </form>
                <?php endif; ?>
            </div>

            <!-- SMTP -->
            <div class="card">
                <h2 class="card-title">E-post (SMTP)</h2>
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="section" value="smtp">

                    <div class="form-group">
                        <label class="form-label" for="smtp_host">SMTP-server</label>
                        <input type="text" id="smtp_host" name="smtp_host" class="form-input"
                               value="<?php echo htmlspecialchars($currentConfig['smtp_host']); ?>"
                               placeholder="t.ex. smtp.gmail.com">
                        <p class="hint">Lämna tomt för att inaktivera SMTP</p>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="smtp_port">Port</label>
                            <input type="number" id="smtp_port" name="smtp_port" class="form-input"
                                   value="<?php echo (int)$currentConfig['smtp_port']; ?>"
                                   min="1" max="65535">
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="smtp_encryption">Kryptering</label>
                            <select id="smtp_encryption" name="smtp_encryption" class="form-input">
                                <option value="ssl" <?php echo $currentConfig['smtp_encryption'] === 'ssl' ? 'selected' : ''; ?>>SSL</option>
                                <option value="tls" <?php echo $currentConfig['smtp_encryption'] === 'tls' ? 'selected' : ''; ?>>TLS</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="smtp_username">Användarnamn</label>
                        <input type="text" id="smtp_username" name="smtp_username" class="form-input"
                               value="<?php echo htmlspecialchars($currentConfig['smtp_username']); ?>"
                               placeholder="din@email.com">
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="smtp_password">Lösenord</label>
                        <input type="password" id="smtp_password" name="smtp_password" class="form-input"
                               placeholder="<?php echo defined('SMTP_PASSWORD') ? '••••••••' : ''; ?>">
                        <p class="hint"><?php echo defined('SMTP_PASSWORD') ? 'Lämna tomt för att behålla nuvarande lösenord' : 'Ange SMTP-lösenord'; ?></p>
                    </div>

                    <button type="submit" class="btn btn-primary">Spara</button>
                </form>
            </div>

            <!-- Password -->
            <div class="card">
                <h2 class="card-title">Byt lösenord</h2>
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="section" value="password">

                    <div class="form-group">
                        <label class="form-label" for="current_password">Nuvarande lösenord</label>
                        <input type="password" id="current_password" name="current_password" class="form-input"
                               autocomplete="current-password" required>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="form-label" for="new_password">Nytt lösenord</label>
                            <input type="password" id="new_password" name="new_password" class="form-input"
                                   autocomplete="new-password" minlength="8" required>
                            <p class="hint">Minst 8 tecken</p>
                        </div>
                        <div class="form-group">
                            <label class="form-label" for="confirm_password">Bekräfta lösenord</label>
                            <input type="password" id="confirm_password" name="confirm_password" class="form-input"
                                   autocomplete="new-password" minlength="8" required>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary">Byt lösenord</button>
                </form>
            </div>

            <!-- Social Media -->
            <div class="card">
                <h2 class="card-title">Sociala medier</h2>
                <form method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="section" value="social">

                    <div class="form-group">
                        <label class="form-label" for="social_facebook">Facebook</label>
                        <input type="url" id="social_facebook" name="social_facebook" class="form-input"
                               value="<?php echo htmlspecialchars($currentConfig['social_facebook']); ?>"
                               placeholder="https://facebook.com/...">
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="social_instagram">Instagram</label>
                        <input type="url" id="social_instagram" name="social_instagram" class="form-input"
                               value="<?php echo htmlspecialchars($currentConfig['social_instagram']); ?>"
                               placeholder="https://instagram.com/...">
                    </div>

                    <div class="form-group">
                        <label class="form-label" for="social_linkedin">LinkedIn</label>
                        <input type="url" id="social_linkedin" name="social_linkedin" class="form-input"
                               value="<?php echo htmlspecialchars($currentConfig['social_linkedin']); ?>"
                               placeholder="https://linkedin.com/...">
                    </div>

                    <button type="submit" class="btn btn-primary">Spara</button>
                </form>
            </div>

            <!-- Navigation / Meny-redigerare -->
            <div class="card" style="margin-bottom: 2rem;">
                <h2 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 1rem;">Navigation</h2>
                <p style="font-size: 0.875rem; color: rgba(255,255,255,0.5); margin-bottom: 1.5rem;">Redigera menyval som visas i headern. Ändringarna syns direkt på sajten.</p>

                <div id="nav-editor">
                    <?php
                    $navFile = DATA_PATH . '/navigation.json';
                    $navItems = [];
                    if (file_exists($navFile)) {
                        $nd = json_decode(file_get_contents($navFile), true);
                        if (!empty($nd['items'])) $navItems = $nd['items'];
                    }
                    if (empty($navItems)) {
                        $navItems = [['label' => 'Hem', 'url' => '/'], ['label' => 'Inlägg', 'url' => '/inlagg']];
                    }
                    ?>
                    <div id="nav-items" style="display: flex; flex-direction: column; gap: 0.75rem; margin-bottom: 1rem;">
                        <?php foreach ($navItems as $i => $item): ?>
                        <div class="nav-item" style="display: flex; gap: 0.5rem; align-items: center;">
                            <input type="text" class="nav-label" value="<?php echo htmlspecialchars($item['label'] ?? ''); ?>" placeholder="Text" style="flex: 1; padding: 0.625rem 0.75rem; border: 1px solid rgba(255,255,255,0.15); border-radius: 0.375rem; background: rgba(255,255,255,0.05); color: white; font-size: 0.875rem;">
                            <input type="text" class="nav-url" value="<?php echo htmlspecialchars($item['url'] ?? ''); ?>" placeholder="/sida" style="flex: 1; padding: 0.625rem 0.75rem; border: 1px solid rgba(255,255,255,0.15); border-radius: 0.375rem; background: rgba(255,255,255,0.05); color: white; font-size: 0.875rem;">
                            <button type="button" class="nav-remove" style="background: none; border: none; color: rgba(255,255,255,0.4); cursor: pointer; padding: 0.5rem; font-size: 1.25rem; line-height: 1;" title="Ta bort">&times;</button>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div style="display: flex; gap: 0.75rem;">
                        <button type="button" id="nav-add" class="btn" style="font-size: 0.8125rem;">+ Lägg till menyval</button>
                        <button type="button" id="nav-save" class="btn btn-primary" style="font-size: 0.8125rem;">Spara meny</button>
                        <span id="nav-result" style="font-size: 0.8125rem; align-self: center;"></span>
                    </div>
                </div>
            </div>

            <!-- Redirects -->
            <div class="card" style="margin-bottom: 2rem;">
                <h2 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 1rem;">Redirects (301/302)</h2>
                <p style="font-size: 0.875rem; color: rgba(255,255,255,0.5); margin-bottom: 1.5rem;">Omdirigera gamla URL:er till nya. Viktigt för SEO vid URL-byten.</p>

                <div id="redirects-editor">
                    <?php
                    $rFile = DATA_PATH . '/redirects.json';
                    $redirects = file_exists($rFile) ? (json_decode(file_get_contents($rFile), true) ?? []) : [];
                    ?>
                    <div id="redirect-items" style="display: flex; flex-direction: column; gap: 0.75rem; margin-bottom: 1rem;">
                        <?php foreach ($redirects as $r): ?>
                        <div class="redirect-item" style="display: flex; gap: 0.5rem; align-items: center;">
                            <input type="text" class="redir-from" value="<?php echo htmlspecialchars($r['from'] ?? ''); ?>" placeholder="/gammal-url" style="flex: 1; padding: 0.625rem 0.75rem; border: 1px solid rgba(255,255,255,0.15); border-radius: 0.375rem; background: rgba(255,255,255,0.05); color: white; font-size: 0.875rem;">
                            <span style="color: rgba(255,255,255,0.3);">&rarr;</span>
                            <input type="text" class="redir-to" value="<?php echo htmlspecialchars($r['to'] ?? ''); ?>" placeholder="/ny-url" style="flex: 1; padding: 0.625rem 0.75rem; border: 1px solid rgba(255,255,255,0.15); border-radius: 0.375rem; background: rgba(255,255,255,0.05); color: white; font-size: 0.875rem;">
                            <select class="redir-code" style="padding: 0.625rem 0.5rem; border: 1px solid rgba(255,255,255,0.15); border-radius: 0.375rem; background: rgba(255,255,255,0.05); color: white; font-size: 0.8125rem;">
                                <option value="301" <?php echo ($r['code'] ?? 301) == 301 ? 'selected' : ''; ?>>301</option>
                                <option value="302" <?php echo ($r['code'] ?? 301) == 302 ? 'selected' : ''; ?>>302</option>
                            </select>
                            <button type="button" class="redir-remove" style="background: none; border: none; color: rgba(255,255,255,0.4); cursor: pointer; padding: 0.5rem; font-size: 1.25rem; line-height: 1;" title="Ta bort">&times;</button>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <div style="display: flex; gap: 0.75rem;">
                        <button type="button" id="redir-add" class="btn" style="font-size: 0.8125rem;">+ Lägg till redirect</button>
                        <button type="button" id="redir-save" class="btn btn-primary" style="font-size: 0.8125rem;">Spara redirects</button>
                        <span id="redir-result" style="font-size: 0.8125rem; align-self: center;"></span>
                    </div>
                </div>
            </div>

            <!-- Systeminformation -->
            <?php
            $phpVersion = PHP_VERSION;
            $phpMajorMinor = (int) PHP_MAJOR_VERSION . '.' . (int) PHP_MINOR_VERSION;
            $phpStatus = 'ok';
            $phpMessage = 'Uppdaterad';
            if (version_compare($phpVersion, '8.1', '<')) {
                $phpStatus = version_compare($phpVersion, '8.0', '<') ? 'critical' : 'warning';
                $phpMessage = $phpStatus === 'critical' ? 'Kritiskt föråldrad' : 'Bör uppgraderas';
            }

            // Diskutrymme
            $diskFree = @disk_free_space(ROOT_PATH);
            $diskTotal = @disk_total_space(ROOT_PATH);
            $diskUsed = $diskTotal - $diskFree;
            $diskUsedMB = $diskUsed !== false ? round($diskUsed / 1024 / 1024) : 0;
            $diskTotalGB = $diskTotal !== false ? round($diskTotal / 1024 / 1024 / 1024, 1) : 0;

            // Senaste uppdatering
            $updateLogFile = DATA_PATH . '/update-log.json';
            $lastUpdate = null;
            if (file_exists($updateLogFile)) {
                $updateLog = json_decode(file_get_contents($updateLogFile), true);
                if (is_array($updateLog) && !empty($updateLog)) {
                    $lastUpdate = end($updateLog);
                }
            }
            ?>
            <div class="card">
                <h2 class="card-title">Systeminformation</h2>
                <div class="system-info-grid">
                    <div class="system-info-item">
                        <span class="system-info-label">PHP-version</span>
                        <span class="system-info-value">
                            <?php echo htmlspecialchars($phpVersion); ?>
                            <?php if ($phpStatus === 'ok'): ?>
                                <span class="status-badge-ok">OK</span>
                            <?php elseif ($phpStatus === 'warning'): ?>
                                <span class="status-badge-warning">Uppgradera</span>
                            <?php else: ?>
                                <span class="status-badge-critical">Kritiskt</span>
                            <?php endif; ?>
                        </span>
                    </div>
                    <?php if ($phpStatus !== 'ok'): ?>
                    <div class="system-info-hint <?php echo $phpStatus === 'critical' ? 'hint-critical' : 'hint-warning'; ?>">
                        PHP <?php echo $phpMajorMinor; ?> <?php echo $phpStatus === 'critical' ? 'stöds inte längre' : 'bör uppgraderas'; ?>.
                        Rekommenderat: PHP 8.1 eller senare.
                    </div>
                    <?php endif; ?>
                    <div class="system-info-item">
                        <span class="system-info-label">Bosse-version</span>
                        <span class="system-info-value"><?php echo htmlspecialchars(BOSSE_VERSION); ?></span>
                    </div>
                    <div class="system-info-item">
                        <span class="system-info-label">Senast uppdaterad</span>
                        <span class="system-info-value"><?php echo htmlspecialchars(BOSSE_VERSION_DATE); ?></span>
                    </div>
                    <?php if ($diskTotal !== false): ?>
                    <div class="system-info-item">
                        <span class="system-info-label">Diskutrymme</span>
                        <span class="system-info-value"><?php echo $diskUsedMB; ?> MB / <?php echo $diskTotalGB; ?> GB</span>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Backup -->
            <div class="card">
                <h2 class="card-title">Backup</h2>
                <p class="hint" style="margin-bottom: 1rem;">Ladda ner en säkerhetskopia av ditt innehåll och uppladdade filer.</p>
                <a href="/cms/api.php?action=backup" class="btn btn-primary" style="text-decoration: none;">
                    Ladda ner backup
                </a>
            </div>

        </div>
    </div>

    <script <?php echo csp_nonce_attr(); ?>>
    // Förhandsvisning av logotyp
    function previewLogo(input, previewId, uploadId) {
        const preview = document.getElementById(previewId);
        const uploadBox = document.getElementById(uploadId);

        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.style.display = 'block';
                uploadBox.classList.add('file-selected');
            };
            reader.readAsDataURL(input.files[0]);
        } else {
            preview.style.display = 'none';
            uploadBox.classList.remove('file-selected');
        }
    }

    // Förhandsvisning av favicon
    function previewFavicon(input) {
        const preview = document.getElementById('preview-favicon');
        const uploadBox = document.getElementById('upload-favicon');

        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.style.display = 'block';
                uploadBox.classList.add('file-selected');
            };
            reader.readAsDataURL(input.files[0]);
        } else {
            preview.style.display = 'none';
            uploadBox.classList.remove('file-selected');
        }
    }

    // Event bindings (CSP-compliant)
    document.querySelectorAll('[data-sync]').forEach(function(el) {
        el.addEventListener('change', function() {
            var target = document.getElementById(this.dataset.sync);
            if (target) target.value = this.value;
        });
    });
    document.querySelectorAll('[data-preview-logo]').forEach(function(el) {
        el.addEventListener('change', function() {
            previewLogo(this, this.dataset.previewLogo, this.dataset.uploadBox);
        });
    });
    document.querySelectorAll('[data-preview-favicon]').forEach(function(el) {
        el.addEventListener('change', function() { previewFavicon(this); });
    });
    document.querySelectorAll('[data-confirm]').forEach(function(el) {
        el.addEventListener('click', function(e) {
            if (!confirm(this.dataset.confirm)) e.preventDefault();
        });
    });

    // Navigation editor
    (function() {
        var container = document.getElementById('nav-items');
        if (!container) return;

        function createRow(label, url) {
            var div = document.createElement('div');
            div.className = 'nav-item';
            div.style.cssText = 'display:flex;gap:0.5rem;align-items:center;';
            div.innerHTML = '<input type="text" class="nav-label" value="' + (label||'') + '" placeholder="Text" style="flex:1;padding:0.625rem 0.75rem;border:1px solid rgba(255,255,255,0.15);border-radius:0.375rem;background:rgba(255,255,255,0.05);color:white;font-size:0.875rem;">'
                + '<input type="text" class="nav-url" value="' + (url||'') + '" placeholder="/sida" style="flex:1;padding:0.625rem 0.75rem;border:1px solid rgba(255,255,255,0.15);border-radius:0.375rem;background:rgba(255,255,255,0.05);color:white;font-size:0.875rem;">'
                + '<button type="button" class="nav-remove" style="background:none;border:none;color:rgba(255,255,255,0.4);cursor:pointer;padding:0.5rem;font-size:1.25rem;line-height:1;" title="Ta bort">&times;</button>';
            return div;
        }

        container.addEventListener('click', function(e) {
            if (e.target.classList.contains('nav-remove')) {
                e.target.closest('.nav-item').remove();
            }
        });

        document.getElementById('nav-add').addEventListener('click', function() {
            container.appendChild(createRow('', ''));
        });

        document.getElementById('nav-save').addEventListener('click', function() {
            var items = [];
            container.querySelectorAll('.nav-item').forEach(function(row) {
                var label = row.querySelector('.nav-label').value.trim();
                var url = row.querySelector('.nav-url').value.trim();
                if (label && url) items.push({ label: label, url: url });
            });

            var csrf = document.querySelector('input[name="csrf_token"]');
            fetch('/cms/api.php?action=save-navigation', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': csrf ? csrf.value : ''
                },
                body: JSON.stringify({ items: items })
            })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                var el = document.getElementById('nav-result');
                if (data.success) {
                    el.innerHTML = '<span style="color:#15803d;">Sparat! (' + data.count + ' menyval)</span>';
                    setTimeout(function() { el.innerHTML = ''; }, 3000);
                } else {
                    el.innerHTML = '<span style="color:#b91c1c;">Fel: ' + (data.error||'Okänt') + '</span>';
                }
            })
            .catch(function() {
                document.getElementById('nav-result').innerHTML = '<span style="color:#b91c1c;">Nätverksfel</span>';
            });
        });
    })();

    // Redirects editor
    (function() {
        var container = document.getElementById('redirect-items');
        if (!container) return;

        function createRow(from, to, code) {
            var div = document.createElement('div');
            div.className = 'redirect-item';
            div.style.cssText = 'display:flex;gap:0.5rem;align-items:center;';
            div.innerHTML = '<input type="text" class="redir-from" value="' + (from||'') + '" placeholder="/gammal-url" style="flex:1;padding:0.625rem 0.75rem;border:1px solid rgba(255,255,255,0.15);border-radius:0.375rem;background:rgba(255,255,255,0.05);color:white;font-size:0.875rem;">'
                + '<span style="color:rgba(255,255,255,0.3);">&rarr;</span>'
                + '<input type="text" class="redir-to" value="' + (to||'') + '" placeholder="/ny-url" style="flex:1;padding:0.625rem 0.75rem;border:1px solid rgba(255,255,255,0.15);border-radius:0.375rem;background:rgba(255,255,255,0.05);color:white;font-size:0.875rem;">'
                + '<select class="redir-code" style="padding:0.625rem 0.5rem;border:1px solid rgba(255,255,255,0.15);border-radius:0.375rem;background:rgba(255,255,255,0.05);color:white;font-size:0.8125rem;"><option value="301"' + (code==301?' selected':'') + '>301</option><option value="302"' + (code==302?' selected':'') + '>302</option></select>'
                + '<button type="button" class="redir-remove" style="background:none;border:none;color:rgba(255,255,255,0.4);cursor:pointer;padding:0.5rem;font-size:1.25rem;line-height:1;" title="Ta bort">&times;</button>';
            return div;
        }

        container.addEventListener('click', function(e) {
            if (e.target.classList.contains('redir-remove')) e.target.closest('.redirect-item').remove();
        });

        document.getElementById('redir-add').addEventListener('click', function() {
            container.appendChild(createRow('', '', 301));
        });

        document.getElementById('redir-save').addEventListener('click', function() {
            var items = [];
            container.querySelectorAll('.redirect-item').forEach(function(row) {
                var from = row.querySelector('.redir-from').value.trim();
                var to = row.querySelector('.redir-to').value.trim();
                var code = parseInt(row.querySelector('.redir-code').value);
                if (from && to) items.push({ from: from, to: to, code: code });
            });

            var csrf = document.querySelector('input[name="csrf_token"]');
            fetch('/cms/api.php?action=save-redirects', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrf ? csrf.value : '' },
                body: JSON.stringify({ redirects: items })
            })
            .then(function(r) { return r.json(); })
            .then(function(data) {
                var el = document.getElementById('redir-result');
                if (data.success) {
                    el.innerHTML = '<span style="color:#15803d;">Sparat! (' + data.count + ' redirects)</span>';
                    setTimeout(function() { el.innerHTML = ''; }, 3000);
                } else {
                    el.innerHTML = '<span style="color:#b91c1c;">Fel: ' + (data.error||'') + '</span>';
                }
            })
            .catch(function() {
                document.getElementById('redir-result').innerHTML = '<span style="color:#b91c1c;">Nätverksfel</span>';
            });
        });
    })();
    </script>
    <script src="/assets/js/cms.js?v=<?php echo BOSSE_VERSION; ?>"></script>
</body>
</html>
