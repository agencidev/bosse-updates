<?php
/**
 * Sitemap Generator
 * Genererar XML sitemap för SEO
 */

require_once __DIR__ . '/../bootstrap.php';

/**
 * Ping Google with updated sitemap URL.
 * Call after publishing/unpublishing posts.
 */
function ping_sitemap() {
    $siteUrl = defined('SITE_URL') ? SITE_URL : '';
    if (!$siteUrl) return;
    $pingUrl = 'https://www.google.com/ping?sitemap=' . urlencode($siteUrl . '/sitemap.xml');
    @file_get_contents($pingUrl, false, stream_context_create([
        'http' => ['timeout' => 5, 'method' => 'GET']
    ]));
}

// Bara generera XML om filen anropas direkt (inte via require från edit.php etc.)
if (basename($_SERVER['SCRIPT_FILENAME'] ?? '') === 'sitemap.php'
    || str_contains($_SERVER['REQUEST_URI'] ?? '', 'sitemap.xml')) {
    header('Content-Type: application/xml; charset=utf-8');
} else {
    return; // Laddad via require enbart för ping_sitemap() — generera inte XML
}

// Statiska sidor
$pages = [
    ['url' => '/', 'priority' => '1.0', 'changefreq' => 'daily'],
    ['url' => '/inlagg', 'priority' => '0.9', 'changefreq' => 'weekly'],
    ['url' => '/cookies', 'priority' => '0.3', 'changefreq' => 'yearly'],
    ['url' => '/integritetspolicy', 'priority' => '0.3', 'changefreq' => 'yearly'],
];

// Auto-discover custom pages in pages/*.php
$exclude = ['inlagg.php', 'inlagg-single.php', 'cookies.php', 'integritetspolicy.php'];
$pagesDir = __DIR__ . '/../pages';
$knownUrls = array_column($pages, 'url');
if (is_dir($pagesDir)) {
    foreach (glob($pagesDir . '/*.php') as $file) {
        $basename = basename($file);
        if (in_array($basename, $exclude, true)) continue;
        if (strpos($basename, 'errors') !== false) continue;
        $slug = pathinfo($basename, PATHINFO_FILENAME);
        $url = '/' . $slug;
        if (in_array($url, $knownUrls, true)) continue;
        $pages[] = ['url' => $url, 'priority' => '0.7', 'changefreq' => 'monthly'];
    }
}

// Category pages from categories.php (e.g. /blogg, /happenings)
$categoriesFile = __DIR__ . '/../cms/extensions/categories.php';
$categories = file_exists($categoriesFile) ? (include $categoriesFile) : [];
$categoryMap = []; // category name => base_url
foreach ($categories as $url => $cat) {
    $categoryMap[$cat['category']] = $cat['base_url'];
    // Add category list page to sitemap (skip /inlagg — already in static list)
    if ($url !== '/inlagg') {
        $pages[] = ['url' => $url, 'priority' => '0.9', 'changefreq' => 'weekly'];
    }
}

// Dynamiska sidor från projects.json
$projectsFile = __DIR__ . '/../data/projects.json';
if (file_exists($projectsFile)) {
    $projects = json_decode(file_get_contents($projectsFile), true) ?? [];
    foreach ($projects as $project) {
        if (($project['status'] ?? 'draft') === 'published' && !empty($project['slug'])) {
            // Use correct URL prefix based on category
            $prefix = $categoryMap[$project['category'] ?? 'Inlägg'] ?? '/inlagg';
            $entry = [
                'url' => $prefix . '/' . $project['slug'],
                'priority' => '0.7',
                'changefreq' => 'weekly',
                'lastmod' => $project['updatedAt'] ?? $project['createdAt'] ?? null,
            ];
            // Image sitemap support
            if (!empty($project['coverImage'])) {
                $entry['image'] = SITE_URL . $project['coverImage'];
                $entry['image_title'] = $project['title'] ?? '';
            }
            $pages[] = $entry;
        }
    }
}

// Generera XML
echo '<?xml version="1.0" encoding="UTF-8"?>';
echo "\n";
echo '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:image="http://www.google.com/schemas/sitemap-image/1.1">';
echo "\n";

foreach ($pages as $page) {
    $url = SITE_URL . $page['url'];
    $lastmod = isset($page['lastmod']) ? substr($page['lastmod'], 0, 10) : date('Y-m-d');

    echo '  <url>';
    echo "\n";
    echo '    <loc>' . htmlspecialchars($url, ENT_XML1, 'UTF-8') . '</loc>';
    echo "\n";
    echo '    <lastmod>' . $lastmod . '</lastmod>';
    echo "\n";
    echo '    <changefreq>' . $page['changefreq'] . '</changefreq>';
    echo "\n";
    echo '    <priority>' . $page['priority'] . '</priority>';
    echo "\n";
    if (!empty($page['image'])) {
        echo '    <image:image>';
        echo "\n";
        echo '      <image:loc>' . htmlspecialchars($page['image'], ENT_XML1, 'UTF-8') . '</image:loc>';
        echo "\n";
        if (!empty($page['image_title'])) {
            echo '      <image:title>' . htmlspecialchars($page['image_title'], ENT_XML1, 'UTF-8') . '</image:title>';
            echo "\n";
        }
        echo '    </image:image>';
        echo "\n";
    }
    echo '  </url>';
    echo "\n";
}

echo '</urlset>';
