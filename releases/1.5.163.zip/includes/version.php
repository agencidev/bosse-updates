<?php
/**
 * Bosse Template Version
 * CORE-fil - skrivs över vid uppdatering
 */

define('BOSSE_VERSION', '1.5.163');
define('BOSSE_VERSION_DATE', '2026-04-01');
