/**
 * CMS JavaScript - EXAKT som Next.js-versionen i Bosse Portal
 * Inline-redigering med samma UX som React-komponenterna
 */

'use strict';

// Read CMS brand colors from CSS custom properties (set by admin-bar.php)
function cmsColor(name) {
  return getComputedStyle(document.documentElement).getPropertyValue('--cms-' + name).trim();
}
function cmsBg() { return cmsColor('bg') || '#033234'; }
function cmsAccent() { return cmsColor('accent') || '#379b83'; }
function cmsFont() { return cmsColor('font') || "'DM Sans', sans-serif"; }

// Pending image changes queue: key = "contentKey|field", value = { file?, url, contentKey, field, originalSrc }
var pendingImageChanges = new Map();

// Initialize CMS when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
  initEditableElements();
  initImageUpload();
  initFormLoadingStates();
  initUrlMessageToast();
});

// Listen for edit mode changes
window.addEventListener('cms-edit-mode-changed', function(e) {
  updateEditableElements(e.detail.isEditMode);
  if (!e.detail.isEditMode && pendingImageChanges.size > 0) {
    handleEditModeExitWithPending();
  }
});

// Warn before page leave with unsaved changes
window.addEventListener('beforeunload', function(e) {
  if (pendingImageChanges.size > 0) {
    e.preventDefault();
    e.returnValue = '';
  }
});

/**
 * Initialize all editable elements
 */
function initEditableElements() {
  const editableTexts = document.querySelectorAll('[data-editable-text]');
  const editableImages = document.querySelectorAll('[data-editable-image]');
  
  editableTexts.forEach(element => {
    setupEditableText(element);
  });
  
  editableImages.forEach(element => {
    setupEditableImage(element);
  });
}

/**
 * Update editable elements when edit mode changes
 */
function updateEditableElements(isEditMode) {
  const editableTexts = document.querySelectorAll('[data-editable-text]');
  
  editableTexts.forEach(element => {
    if (isEditMode) {
      element.classList.add('cms-editable-active');
    } else {
      element.classList.remove('cms-editable-active');
    }
  });
}

/**
 * Setup editable text element - EXAKT som EditableText.jsx
 */
function setupEditableText(element) {
  const contentKey = element.dataset.contentKey;
  const field = element.dataset.field;
  const defaultValue = element.dataset.defaultValue || '';
  const tag = element.tagName.toLowerCase();
  
  let originalValue = element.textContent;
  let isEditing = false;
  
  // Click handler - only works when edit mode is active
  element.addEventListener('click', function(e) {
    if (!window.CMS || !window.CMS.isEditMode) return;
    if (isEditing) return;
    
    e.stopPropagation();
    startEditing();
  });
  
  function startEditing() {
    isEditing = true;
    originalValue = element.textContent.trim();

    const isMultiline = tag === 'p' || tag === 'div' || tag === 'textarea';

    // Save element width before hiding
    const savedWidth = Math.max(element.offsetWidth, 280);

    // Create wrapper — all inline styles (no Tailwind dependency)
    const wrapper = document.createElement('div');
    Object.assign(wrapper.style, {
      position: 'relative',
      width: savedWidth + 'px',
      maxWidth: '100%',
      borderRadius: '1rem',
      overflow: 'hidden',
      border: '1px solid #e5e7eb',
      zIndex: '1000'
    });

    // Buttons container (top bar)
    const buttonsDiv = document.createElement('div');
    Object.assign(buttonsDiv.style, {
      display: 'flex',
      gap: '0.5rem',
      alignItems: 'center',
      justifyContent: 'flex-end',
      padding: '0.5rem 0.75rem',
      background: cmsBg(),
      borderBottom: '1px solid rgba(255,255,255,0.08)'
    });

    // Save button — brand accent pill
    const saveBtn = document.createElement('button');
    saveBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-2px;margin-right:4px"><polyline points="20 6 9 17 4 12"/></svg>Spara';
    Object.assign(saveBtn.style, {
      display: 'inline-flex',
      alignItems: 'center',
      padding: '0.375rem 1rem',
      background: cmsAccent(),
      color: 'white',
      fontSize: '0.8125rem',
      fontWeight: '600',
      fontFamily: cmsFont(),
      borderRadius: '9999px',
      border: 'none',
      cursor: 'pointer',
      transition: 'background 0.15s'
    });
    saveBtn.onmouseenter = () => { saveBtn.style.opacity = '0.85'; };
    saveBtn.onmouseleave = () => { saveBtn.style.opacity = '1'; };
    saveBtn.onclick = async function() {
      saveBtn.disabled = true;
      saveBtn.style.opacity = '0.6';
      saveBtn.innerHTML = '<span class="cms-spinner"></span> Sparar...';
      await handleSave(inputElement.value);
    };

    // Cancel button — subtle X
    const cancelBtn = document.createElement('button');
    cancelBtn.textContent = '✕';
    Object.assign(cancelBtn.style, {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: '1.75rem',
      height: '1.75rem',
      background: 'transparent',
      color: 'rgba(255,255,255,0.5)',
      fontSize: '1rem',
      lineHeight: '1',
      border: 'none',
      borderRadius: '9999px',
      cursor: 'pointer',
      transition: 'all 0.15s'
    });
    cancelBtn.title = 'Avbryt';
    cancelBtn.onmouseenter = () => { cancelBtn.style.background = 'rgba(255,255,255,0.1)'; cancelBtn.style.color = 'white'; };
    cancelBtn.onmouseleave = () => { cancelBtn.style.background = 'transparent'; cancelBtn.style.color = 'rgba(255,255,255,0.5)'; };
    cancelBtn.onclick = function() { handleCancel(); };

    buttonsDiv.appendChild(cancelBtn);
    buttonsDiv.appendChild(saveBtn);

    // Input element
    const inputElement = isMultiline
      ? document.createElement('textarea')
      : document.createElement('input');

    if (!isMultiline) {
      inputElement.type = 'text';
    }

    inputElement.value = element.textContent.trim();
    Object.assign(inputElement.style, {
      display: 'block',
      width: '100%',
      padding: '0.875rem 1rem',
      background: 'white',
      color: '#1a1a1a',
      border: 'none',
      borderTop: '1px solid #e5e7eb',
      outline: 'none',
      boxShadow: 'none',
      fontSize: 'inherit',
      lineHeight: 'inherit',
      fontWeight: 'inherit',
      fontFamily: cmsFont(),
      boxSizing: 'border-box',
      resize: 'none'
    });

    if (isMultiline) {
      inputElement.rows = 1;
      inputElement.style.minHeight = '80px';
      inputElement.style.overflow = 'hidden';
      const autoResize = () => {
        inputElement.style.height = 'auto';
        inputElement.style.height = inputElement.scrollHeight + 'px';
      };
      setTimeout(autoResize, 0);
      inputElement.addEventListener('input', autoResize);
    } else {
      inputElement.style.height = '48px';
    }

    wrapper.appendChild(buttonsDiv);
    wrapper.appendChild(inputElement);

    // Replace element with editor
    element.style.display = 'none';
    element.parentNode.insertBefore(wrapper, element.nextSibling);

    inputElement.focus();
    if (!isMultiline) {
      inputElement.select();
    }

    // Keyboard shortcuts
    inputElement.addEventListener('keydown', function(e) {
      if (e.key === 'Enter' && !isMultiline) {
        e.preventDefault();
        saveBtn.click();
      }
      if (e.key === 'Escape') {
        handleCancel();
      }
    });
    
    async function handleSave(newValue) {
      try {
        // Trim whitespace to avoid spacing issues
        const trimmedValue = newValue.trim();

        // Fetch current content (includes CSRF token)
        const res = await fetch(`/cms/api.php?action=get&_t=${Date.now()}`);
        const currentData = await res.json();
        const csrfToken = currentData._csrf || '';

        // Update section
        const updatedSection = {
          ...(currentData[contentKey] || {}),
          [field]: trimmedValue
        };

        // Save to server with CSRF token
        const saveRes = await fetch('/cms/api.php?action=update', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': csrfToken
          },
          body: JSON.stringify({
            key: contentKey,
            value: updatedSection
          })
        });
        
        if (saveRes.ok) {
          // Update the text node directly without changing DOM structure
          const textNode = Array.from(element.childNodes).find(node => node.nodeType === Node.TEXT_NODE);
          if (textNode) {
            textNode.nodeValue = trimmedValue;
          } else {
            element.textContent = trimmedValue;
          }
          showNotification('Sparat!', 'success');
        } else {
          showNotification('Kunde inte spara', 'error');
        }
      } catch (err) {
        console.error('Save error:', err);
        showNotification('Kunde inte spara', 'error');
      } finally {
        cleanup();
      }
    }
    
    function handleCancel() {
      // Update the text node directly without changing DOM structure
      const textNode = Array.from(element.childNodes).find(node => node.nodeType === Node.TEXT_NODE);
      if (textNode) {
        textNode.nodeValue = originalValue;
      } else {
        element.textContent = originalValue;
      }
      cleanup();
    }
    
    function cleanup() {
      wrapper.remove();
      element.style.display = '';
      isEditing = false;
    }
  }
}

/**
 * Setup editable image element
 */
function setupEditableImage(element) {
  const contentKey = element.dataset.contentKey;
  const field = element.dataset.field;
  
  // Add overlay on hover when edit mode is active
  const wrapper = element.parentElement;
  if (!wrapper.classList.contains('cms-image-wrapper')) {
    const newWrapper = document.createElement('div');
    newWrapper.className = 'cms-image-wrapper';
    newWrapper.dataset.contentKey = contentKey;
    newWrapper.dataset.field = field;
    element.parentNode.insertBefore(newWrapper, element);
    newWrapper.appendChild(element);
    
    const overlay = document.createElement('div');
    overlay.className = 'cms-image-overlay';
    const imgBtn = document.createElement('button');
    imgBtn.className = 'cms-image-btn';
    imgBtn.innerHTML = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align: -2px; margin-right: 4px;"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>Ändra bild';
    imgBtn.addEventListener('click', function() { uploadImage(contentKey, field); });
    overlay.appendChild(imgBtn);
    newWrapper.appendChild(overlay);
  }
}

/**
 * Image upload handler
 */
function initImageUpload() {
  // Create hidden file input
  if (!document.getElementById('cms-image-upload')) {
    const input = document.createElement('input');
    input.type = 'file';
    input.id = 'cms-image-upload';
    input.accept = 'image/*';
    input.style.display = 'none';
    document.body.appendChild(input);
    
    input.addEventListener('change', function(e) {
      if (!e.target.files || !e.target.files[0]) return;

      const file = e.target.files[0];
      const contentKey = input.dataset.contentKey;
      const field = input.dataset.field;

      const img = document.querySelector('img[data-content-key="' + contentKey + '"][data-field="' + field + '"]');
      if (img) {
        const key = contentKey + '|' + field;
        if (!pendingImageChanges.has(key)) {
          pendingImageChanges.set(key, { file: file, contentKey: contentKey, field: field, originalSrc: img.src });
        } else {
          var existing = pendingImageChanges.get(key);
          existing.file = file;
          delete existing.url;
        }
        img.src = URL.createObjectURL(file);
        markImageAsPending(img);
        updatePendingSaveBar();
        showNotification('Bild vald — klicka "Spara ändringar" för att tillämpa', 'info');
      }

      input.value = '';
    });
  }
}

/**
 * Trigger image upload — opens media library modal
 */
function uploadImage(contentKey, field) {
  if (!window.CMS || !window.CMS.isEditMode) return;
  openMediaLibraryModal(contentKey, field);
}

/**
 * Open media library modal for selecting or uploading images
 */
async function openMediaLibraryModal(contentKey, field) {
  // Fetch images and CSRF token
  let images = [];
  let csrfToken = '';
  try {
    const res = await fetch('/cms/api.php?action=media-list&_t=' + Date.now());
    const data = await res.json();
    if (data.success) {
      images = data.images || [];
      csrfToken = data._csrf || '';
    }
  } catch (e) {
    console.error('Failed to load media library:', e);
  }

  // Create overlay
  const overlay = document.createElement('div');
  Object.assign(overlay.style, {
    position: 'fixed',
    inset: '0',
    background: 'rgba(0,0,0,0.6)',
    backdropFilter: 'blur(4px)',
    zIndex: '10002',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '1.5rem'
  });

  // Create panel
  const panel = document.createElement('div');
  Object.assign(panel.style, {
    background: cmsBg(),
    borderRadius: '1rem',
    border: '1px solid rgba(255,255,255,0.12)',
    maxWidth: '56rem',
    width: '100%',
    maxHeight: '85vh',
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
    boxShadow: '0 25px 50px rgba(0,0,0,0.4)'
  });

  // Header
  const header = document.createElement('div');
  Object.assign(header.style, {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '1rem 1.25rem',
    borderBottom: '1px solid rgba(255,255,255,0.10)'
  });
  header.innerHTML = '<span style="font-size:1.125rem;font-weight:600;color:white;font-family:var(--cms-font, DM Sans, sans-serif)">Välj bild</span>';
  const closeBtn = document.createElement('button');
  Object.assign(closeBtn.style, {
    background: 'none', border: 'none', color: 'rgba(255,255,255,0.5)',
    fontSize: '1.5rem', cursor: 'pointer', lineHeight: '1', padding: '0.25rem'
  });
  closeBtn.innerHTML = '&times;';
  closeBtn.onclick = closeModal;
  header.appendChild(closeBtn);

  // Upload zone
  const uploadZone = document.createElement('div');
  Object.assign(uploadZone.style, {
    margin: '1rem 1.25rem 0.75rem',
    padding: '1.25rem',
    border: '2px dashed rgba(255,255,255,0.15)',
    borderRadius: '0.75rem',
    textAlign: 'center',
    cursor: 'pointer',
    transition: 'border-color 0.2s',
    flexShrink: '0'
  });
  uploadZone.innerHTML = '<span style="display:inline-flex;align-items:center;gap:6px;color:rgba(255,255,255,0.5);font-size:0.875rem;font-family:var(--cms-font, DM Sans, sans-serif)"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>Ladda upp ny bild</span>';
  uploadZone.onmouseenter = function() { this.style.borderColor = 'rgba(55,155,131,0.5)'; };
  uploadZone.onmouseleave = function() { this.style.borderColor = 'rgba(255,255,255,0.15)'; };

  // Hidden file input for upload within modal
  const fileInput = document.createElement('input');
  fileInput.type = 'file';
  fileInput.accept = 'image/*';
  fileInput.style.display = 'none';
  uploadZone.onclick = function() { fileInput.click(); };

  const uploadDefaultHTML = uploadZone.innerHTML;

  // Shared upload handler — deferred save (stages change locally)
  function handleUpload(file) {
    var img = document.querySelector('img[data-content-key="' + contentKey + '"][data-field="' + field + '"]');
    if (img) {
      var key = contentKey + '|' + field;
      if (!pendingImageChanges.has(key)) {
        pendingImageChanges.set(key, { file: file, contentKey: contentKey, field: field, originalSrc: img.src });
      } else {
        var existing = pendingImageChanges.get(key);
        existing.file = file;
        delete existing.url;
      }
      img.src = URL.createObjectURL(file);
      markImageAsPending(img);
      updatePendingSaveBar();
      showNotification('Bild vald — klicka "Spara ändringar" för att tillämpa', 'info');
    }
    closeModal();
    fileInput.value = '';
  }

  fileInput.addEventListener('change', function(e) {
    if (!e.target.files || !e.target.files[0]) return;
    handleUpload(e.target.files[0]);
  });

  // Drag & drop support
  uploadZone.addEventListener('dragover', function(e) {
    e.preventDefault();
    this.style.borderColor = 'rgba(55,155,131,0.6)';
  });
  uploadZone.addEventListener('dragleave', function() {
    this.style.borderColor = 'rgba(255,255,255,0.15)';
  });
  uploadZone.addEventListener('drop', function(e) {
    e.preventDefault();
    this.style.borderColor = 'rgba(255,255,255,0.15)';
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleUpload(e.dataTransfer.files[0]);
    }
  });

  // Image grid
  const gridWrap = document.createElement('div');
  Object.assign(gridWrap.style, {
    flex: '1',
    overflowY: 'auto',
    padding: '0 1.25rem 1.25rem'
  });

  const grid = document.createElement('div');
  Object.assign(grid.style, {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(120px, 1fr))',
    gap: '0.75rem'
  });

  images.forEach(function(img) {
    const thumb = document.createElement('div');
    Object.assign(thumb.style, {
      cursor: 'pointer',
      borderRadius: '0.5rem',
      overflow: 'hidden',
      border: '2px solid transparent',
      transition: 'border-color 0.2s',
      background: 'rgba(255,255,255,0.05)'
    });
    thumb.onmouseenter = function() { this.style.borderColor = cmsAccent(); };
    thumb.onmouseleave = function() { this.style.borderColor = 'transparent'; };
    thumb.innerHTML = '<img src="' + escapeHtml(img.url) + '" alt="' + escapeHtml(img.filename) + '" style="width:100%;aspect-ratio:1/1;object-fit:cover;display:block" loading="lazy">'
      + '<div style="padding:0.375rem 0.5rem;font-size:0.6875rem;color:rgba(255,255,255,0.5);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-family:var(--cms-font, DM Sans, sans-serif)">' + escapeHtml(img.filename) + '</div>';
    thumb.onclick = function() {
      selectExistingImage(img.url, contentKey, field, csrfToken);
      closeModal();
    };
    grid.appendChild(thumb);
  });

  if (images.length === 0) {
    grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:2rem;color:rgba(255,255,255,0.35);font-size:0.875rem;font-family:var(--cms-font, DM Sans, sans-serif)">Inga bilder i biblioteket</div>';
  }

  gridWrap.appendChild(grid);

  // Assemble
  panel.appendChild(header);
  panel.appendChild(uploadZone);
  panel.appendChild(fileInput);
  panel.appendChild(gridWrap);
  overlay.appendChild(panel);
  document.body.appendChild(overlay);

  // Close handlers
  overlay.addEventListener('click', function(e) {
    if (e.target === overlay) closeModal();
  });
  document.addEventListener('keydown', handleEsc);

  function handleEsc(e) {
    if (e.key === 'Escape') closeModal();
  }

  function closeModal() {
    document.removeEventListener('keydown', handleEsc);
    overlay.remove();
  }
}

/**
 * Select an existing image from the media library — deferred save
 */
function selectExistingImage(url, contentKey, field, csrfToken) {
  var img = document.querySelector('img[data-content-key="' + contentKey + '"][data-field="' + field + '"]');
  if (img) {
    var key = contentKey + '|' + field;
    if (!pendingImageChanges.has(key)) {
      pendingImageChanges.set(key, { url: url, contentKey: contentKey, field: field, originalSrc: img.src });
    } else {
      var existing = pendingImageChanges.get(key);
      existing.url = url;
      delete existing.file;
    }
    img.src = url;
    markImageAsPending(img);
    updatePendingSaveBar();
    showNotification('Bild vald — klicka "Spara ändringar" för att tillämpa', 'info');
  }
}

/**
 * Mark an image as having a pending (unsaved) change
 */
function markImageAsPending(img) {
  var wrapper = img.closest('.cms-image-wrapper');
  if (wrapper) {
    wrapper.style.outline = '3px solid ' + cmsAccent();
    wrapper.style.outlineOffset = '2px';
    wrapper.style.borderRadius = 'inherit';
  }
}

/**
 * Remove pending mark from an image
 */
function unmarkImageAsPending(img) {
  var wrapper = img.closest('.cms-image-wrapper');
  if (wrapper) {
    wrapper.style.outline = '';
    wrapper.style.outlineOffset = '';
  }
}

/**
 * Show/hide/update the floating "Spara ändringar" bar
 */
function updatePendingSaveBar() {
  var bar = document.getElementById('cms-pending-save-bar');

  if (pendingImageChanges.size === 0) {
    if (bar) {
      bar.style.animation = 'cmsToastOut 0.3s ease-out forwards';
      setTimeout(function() { bar.remove(); }, 300);
    }
    return;
  }

  if (!bar) {
    bar = document.createElement('div');
    bar.id = 'cms-pending-save-bar';
    Object.assign(bar.style, {
      position: 'fixed',
      bottom: '1.5rem',
      left: '50%',
      transform: 'translateX(-50%)',
      display: 'flex',
      alignItems: 'center',
      gap: '1rem',
      padding: '0.75rem 1.25rem',
      background: cmsBg(),
      border: '1px solid ' + cmsAccent() + '66',
      borderRadius: '9999px',
      boxShadow: '0 10px 40px rgba(0,0,0,0.35)',
      zIndex: '10003',
      fontFamily: cmsFont(),
      animation: 'cmsToastIn 0.3s ease-out'
    });

    var label = document.createElement('span');
    label.id = 'cms-pending-label';
    Object.assign(label.style, {
      color: 'rgba(255,255,255,0.8)',
      fontSize: '0.875rem',
      fontWeight: '500',
      whiteSpace: 'nowrap'
    });
    bar.appendChild(label);

    var saveBtn = document.createElement('button');
    saveBtn.id = 'cms-pending-save-btn';
    saveBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:-2px;margin-right:4px"><polyline points="20 6 9 17 4 12"/></svg>Spara ändringar';
    Object.assign(saveBtn.style, {
      display: 'inline-flex',
      alignItems: 'center',
      padding: '0.5rem 1.25rem',
      background: cmsAccent(),
      color: 'white',
      fontSize: '0.875rem',
      fontWeight: '600',
      borderRadius: '9999px',
      border: 'none',
      cursor: 'pointer',
      transition: 'opacity 0.15s',
      whiteSpace: 'nowrap'
    });
    saveBtn.onmouseenter = function() { this.style.opacity = '0.85'; };
    saveBtn.onmouseleave = function() { this.style.opacity = '1'; };
    saveBtn.onclick = function() { savePendingImageChanges(); };
    bar.appendChild(saveBtn);

    var discardBtn = document.createElement('button');
    discardBtn.textContent = '✕';
    discardBtn.title = 'Ångra alla bildändringar';
    Object.assign(discardBtn.style, {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: '2rem',
      height: '2rem',
      background: 'transparent',
      color: 'rgba(255,255,255,0.5)',
      fontSize: '1.125rem',
      border: 'none',
      borderRadius: '9999px',
      cursor: 'pointer',
      transition: 'all 0.15s'
    });
    discardBtn.onmouseenter = function() { this.style.background = 'rgba(239,68,68,0.2)'; this.style.color = '#ef4444'; };
    discardBtn.onmouseleave = function() { this.style.background = 'transparent'; this.style.color = 'rgba(255,255,255,0.5)'; };
    discardBtn.onclick = function() { discardPendingImageChanges(); };
    bar.appendChild(discardBtn);

    document.body.appendChild(bar);
  }

  var count = pendingImageChanges.size;
  var label = document.getElementById('cms-pending-label');
  if (label) {
    label.textContent = count === 1 ? '1 osparad ändring' : count + ' osparade ändringar';
  }
}

/**
 * Save all pending image changes to the server
 */
async function savePendingImageChanges() {
  var btn = document.getElementById('cms-pending-save-btn');
  if (btn) {
    btn.disabled = true;
    btn.style.opacity = '0.6';
    btn.innerHTML = '<span class="cms-spinner"></span> Sparar...';
  }

  var entries = Array.from(pendingImageChanges.entries());
  var total = entries.length;
  var saved = 0;
  var errors = 0;

  for (var i = 0; i < entries.length; i++) {
    var entry = entries[i];
    var key = entry[0];
    var change = entry[1];

    try {
      // Get fresh CSRF token
      var tokenRes = await fetch('/cms/api.php?action=get&_t=' + Date.now());
      var tokenData = await tokenRes.json();
      var csrfToken = tokenData._csrf || '';

      if (change.file) {
        // Upload new file
        var formData = new FormData();
        formData.append('image', change.file);
        formData.append('key', change.contentKey);
        formData.append('field', change.field);
        formData.append('csrf_token', csrfToken);

        var res = await fetch('/cms/api.php?action=upload', { method: 'POST', body: formData });
        var data = await res.json();
        if (data.success) {
          // Update img src to server URL (replace blob)
          var img = document.querySelector('img[data-content-key="' + change.contentKey + '"][data-field="' + change.field + '"]');
          if (img) {
            img.src = data.url;
            unmarkImageAsPending(img);
          }
          saved++;
        } else {
          errors++;
        }
      } else if (change.url) {
        // Select existing image
        var res2 = await fetch('/cms/api.php?action=media-select', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-CSRF-Token': csrfToken },
          body: JSON.stringify({ key: change.contentKey, field: change.field, url: change.url })
        });
        var data2 = await res2.json();
        if (data2.success) {
          var img2 = document.querySelector('img[data-content-key="' + change.contentKey + '"][data-field="' + change.field + '"]');
          if (img2) unmarkImageAsPending(img2);
          saved++;
        } else {
          errors++;
        }
      }

      pendingImageChanges.delete(key);
    } catch (err) {
      console.error('Save pending image error:', err);
      errors++;
    }
  }

  if (errors === 0) {
    showNotification('Alla ändringar sparade!', 'success');
  } else {
    showNotification(errors + ' av ' + total + ' kunde inte sparas', 'error');
  }

  updatePendingSaveBar();
}

/**
 * Discard all pending image changes — revert to original
 */
function discardPendingImageChanges() {
  pendingImageChanges.forEach(function(change) {
    var img = document.querySelector('img[data-content-key="' + change.contentKey + '"][data-field="' + change.field + '"]');
    if (img) {
      img.src = change.originalSrc;
      unmarkImageAsPending(img);
    }
  });
  pendingImageChanges.clear();
  updatePendingSaveBar();
  showNotification('Ändringar ångrade', 'info');
}

/**
 * Handle exiting edit mode with unsaved image changes
 */
function handleEditModeExitWithPending() {
  var count = pendingImageChanges.size;
  var msg = count === 1
    ? 'Du har 1 osparad bildändring. Vill du spara innan du lämnar redigeringsläget?'
    : 'Du har ' + count + ' osparade bildändringar. Vill du spara innan du lämnar redigeringsläget?';

  if (confirm(msg)) {
    savePendingImageChanges();
  } else {
    discardPendingImageChanges();
  }
}

/**
 * Show notification (toast)
 * @param {string} message - Message to display
 * @param {string} type - 'success', 'error', or 'info'
 * @param {object} options - Optional settings: { duration: 5000, details: '' }
 */
function showNotification(message, type = 'info', options = {}) {
  const duration = options.duration || 5000;
  const details = options.details || '';

  // Inject CSS once
  if (!document.getElementById('cms-notification-styles')) {
    const style = document.createElement('style');
    style.id = 'cms-notification-styles';
    style.textContent = `
      .cms-toast-container {
        position: fixed;
        bottom: 1.5rem;
        right: 1.5rem;
        display: flex;
        flex-direction: column;
        gap: 0.75rem;
        z-index: 10001;
        pointer-events: none;
      }
      .cms-toast {
        display: flex;
        align-items: flex-start;
        gap: 0.75rem;
        padding: 1rem 1.25rem;
        border-radius: 0.75rem;
        font-size: 0.875rem;
        font-weight: 500;
        font-family: var(--cms-font, 'DM Sans', sans-serif);
        animation: cmsToastIn 0.3s ease-out;
        box-shadow: 0 10px 25px rgba(0,0,0,0.15), 0 4px 6px rgba(0,0,0,0.1);
        max-width: 360px;
        pointer-events: auto;
      }
      .cms-toast--success {
        background: #10b981;
        color: white;
      }
      .cms-toast--error {
        background: #ef4444;
        color: white;
      }
      .cms-toast--info {
        background: #3b82f6;
        color: white;
      }
      .cms-toast-icon {
        flex-shrink: 0;
        width: 1.25rem;
        height: 1.25rem;
      }
      .cms-toast-content {
        flex: 1;
      }
      .cms-toast-message {
        font-weight: 600;
      }
      .cms-toast-details {
        font-size: 0.8125rem;
        opacity: 0.9;
        margin-top: 0.25rem;
      }
      .cms-toast-close {
        flex-shrink: 0;
        background: none;
        border: none;
        color: inherit;
        opacity: 0.7;
        cursor: pointer;
        padding: 0;
        font-size: 1.25rem;
        line-height: 1;
      }
      .cms-toast-close:hover {
        opacity: 1;
      }
      .cms-toast-progress {
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 3px;
        background: rgba(255,255,255,0.3);
        border-radius: 0 0 0.75rem 0.75rem;
        overflow: hidden;
      }
      .cms-toast-progress-bar {
        height: 100%;
        background: rgba(255,255,255,0.7);
        animation: cmsToastProgress linear forwards;
      }
      @keyframes cmsToastIn {
        from { transform: translateX(100%); opacity: 0; }
        to { transform: translateX(0); opacity: 1; }
      }
      @keyframes cmsToastOut {
        from { transform: translateX(0); opacity: 1; }
        to { transform: translateX(100%); opacity: 0; }
      }
      @keyframes cmsToastProgress {
        from { width: 100%; }
        to { width: 0%; }
      }
      .cms-editable-active {
        outline: 2px dashed color-mix(in srgb, var(--cms-accent, #379b83) 30%, transparent);
        outline-offset: 4px;
        cursor: pointer;
        transition: outline-color 0.2s;
      }
      .cms-editable-active:hover {
        outline-color: color-mix(in srgb, var(--cms-accent, #379b83) 70%, transparent);
      }
      .cms-image-wrapper {
        position: relative;
        display: inline-block;
      }
      .cms-image-overlay {
        position: absolute;
        inset: 0;
        background: rgba(0,0,0,0.5);
        display: none;
        align-items: center;
        justify-content: center;
        border-radius: inherit;
      }
      .cms-edit-mode .cms-image-wrapper:hover .cms-image-overlay {
        display: flex;
      }
      .cms-image-btn {
        padding: 0.5rem 1rem;
        background: var(--cms-accent, #379b83);
        color: white;
        border: none;
        border-radius: 9999px;
        font-size: 0.875rem;
        font-weight: 600;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 0.25rem;
        transition: opacity 0.2s;
        font-family: var(--cms-font, 'DM Sans', sans-serif);
      }
      .cms-image-btn:hover {
        opacity: 0.85;
      }
    `;
    document.head.appendChild(style);
  }

  // Get or create container
  let container = document.getElementById('cms-toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'cms-toast-container';
    container.className = 'cms-toast-container';
    document.body.appendChild(container);
  }

  // Icon based on type
  const icons = {
    success: '<svg class="cms-toast-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"/></svg>',
    error: '<svg class="cms-toast-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"/></svg>',
    info: '<svg class="cms-toast-icon" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>'
  };

  const toast = document.createElement('div');
  toast.className = `cms-toast cms-toast--${type}`;
  toast.style.position = 'relative';
  toast.innerHTML = `
    ${icons[type] || icons.info}
    <div class="cms-toast-content">
      <div class="cms-toast-message">${escapeHtml(message)}</div>
      ${details ? `<div class="cms-toast-details">${escapeHtml(details)}</div>` : ''}
    </div>
    <button class="cms-toast-close" aria-label="Stäng">&times;</button>
    <div class="cms-toast-progress">
      <div class="cms-toast-progress-bar" style="animation-duration: ${duration}ms"></div>
    </div>
  `;

  // Close button
  toast.querySelector('.cms-toast-close').addEventListener('click', () => {
    dismissToast(toast);
  });

  container.appendChild(toast);

  // Auto-dismiss
  const timeoutId = setTimeout(() => {
    dismissToast(toast);
  }, duration);

  // Pause on hover
  toast.addEventListener('mouseenter', () => {
    const progressBar = toast.querySelector('.cms-toast-progress-bar');
    if (progressBar) progressBar.style.animationPlayState = 'paused';
  });

  toast.addEventListener('mouseleave', () => {
    const progressBar = toast.querySelector('.cms-toast-progress-bar');
    if (progressBar) progressBar.style.animationPlayState = 'running';
  });

  function dismissToast(el) {
    clearTimeout(timeoutId);
    el.style.animation = 'cmsToastOut 0.3s ease-out forwards';
    setTimeout(() => el.remove(), 300);
  }
}

/**
 * Escape HTML for safe insertion
 */
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text;
  return div.innerHTML;
}

/**
 * Format file size for display
 */
function formatFileSize(bytes) {
  if (bytes < 1024) return bytes + ' B';
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
  return (bytes / 1024 / 1024).toFixed(1) + ' MB';
}

/**
 * Add loading states to all CMS form submit buttons.
 * Shows spinner + "Sparar..." on submit, prevents double-clicks.
 * Only activates on CMS admin pages (detects admin-bar or .page-content).
 */
function initFormLoadingStates() {
  // Only run on CMS admin pages
  if (!document.querySelector('.admin-bar, .page-content, [data-cms-admin]')) return;

  // Inject spinner CSS once
  if (!document.getElementById('cms-spinner-styles')) {
    const style = document.createElement('style');
    style.id = 'cms-spinner-styles';
    style.textContent = `
      .cms-spinner {
        display: inline-block;
        width: 14px;
        height: 14px;
        border: 2px solid rgba(255,255,255,0.3);
        border-top-color: white;
        border-radius: 50%;
        animation: cmsSpinnerRotate 0.6s linear infinite;
        vertical-align: -2px;
      }
      .cms-spinner--dark {
        border-color: rgba(0,0,0,0.15);
        border-top-color: #18181b;
      }
      @keyframes cmsSpinnerRotate {
        to { transform: rotate(360deg); }
      }
    `;
    document.head.appendChild(style);
  }

  document.querySelectorAll('form').forEach(function(form) {
    if (form.method && form.method.toLowerCase() !== 'post') return;
    form.addEventListener('submit', function() {
      const btn = form.querySelector('button[type="submit"], input[type="submit"]');
      if (!btn || btn.dataset.cmsLoading === 'active') return;

      btn.dataset.cmsLoading = 'active';
      btn.disabled = true;

      const originalWidth = btn.offsetWidth;
      btn.style.minWidth = originalWidth + 'px';
      btn.style.opacity = '0.8';
      btn.style.pointerEvents = 'none';

      if (btn.tagName === 'BUTTON') {
        btn.innerHTML = '<span class="cms-spinner"></span> Sparar...';
      } else {
        btn.value = 'Sparar...';
      }
    });
  });
}

/**
 * Show toast notification based on ?msg= URL parameter.
 * Cleans up the URL afterwards so refresh doesn't re-trigger.
 */
function initUrlMessageToast() {
  var params = new URLSearchParams(window.location.search);
  var msg = params.get('msg');
  if (!msg) return;

  var messages = {
    'saved': ['Sparat!', 'success'],
    'created': ['Inlägg skapat!', 'success'],
    'updated': ['Ändringar sparade!', 'success'],
    'deleted': ['Borttaget!', 'success'],
    'added': ['Tillagt!', 'success'],
    'published': ['Publicerat!', 'success'],
    'bulk_delete': ['Inlägg raderade!', 'success'],
    'bulk_publish': ['Inlägg publicerade!', 'success'],
    'bulk_unpublish': ['Inlägg avpublicerade!', 'success'],
    'error': ['Något gick fel', 'error']
  };

  var entry = messages[msg] || [msg, 'success'];
  showNotification(entry[0], entry[1]);

  var url = new URL(window.location);
  url.searchParams.delete('msg');
  history.replaceState(null, '', url);
}
