<?php
/**
 * Peys Badge — Footer banner
 * CORE-fil — skrivs över vid uppdatering
 * Helt isolerad — inga delade klassnamn, alla regler !important
 */
?>
<div class="peys-badge">
    <div class="peys-badge__inner">
        <a href="https://peys.se" target="_blank" rel="noopener" class="peys-badge__link">
            <span>Sidan drivs och hanteras av</span>
            <img src="/assets/images/cms/peys-logo-light.png" alt="PEYS" class="peys-badge__logo">
        </a>
    </div>
</div>

<style>
.peys-badge,
.peys-badge *,
.peys-badge *::before,
.peys-badge *::after {
    all: revert !important;
}

.peys-badge {
    background: #033234 !important;
    padding: 1rem !important;
    text-align: center !important;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
    margin: 0 !important;
    border: none !important;
    box-shadow: none !important;
    opacity: 1 !important;
    filter: none !important;
}

.peys-badge__inner {
    max-width: 1200px !important;
    margin: 0 auto !important;
    padding: 0 !important;
    background: transparent !important;
}

.peys-badge__link {
    display: inline-flex !important;
    align-items: center !important;
    justify-content: center !important;
    gap: 8px !important;
    text-decoration: none !important;
    color: rgba(255, 255, 255, 0.7) !important;
    font-size: 13px !important;
    line-height: 1 !important;
    transition: color 0.2s !important;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
    font-weight: 400 !important;
    letter-spacing: 0 !important;
    text-transform: none !important;
    background: transparent !important;
    border: none !important;
    padding: 0 !important;
    margin: 0 !important;
}

.peys-badge__link span {
    font-family: inherit !important;
    font-size: inherit !important;
    font-weight: inherit !important;
    color: inherit !important;
    letter-spacing: inherit !important;
    text-transform: inherit !important;
}

.peys-badge__link:hover {
    color: white !important;
    text-decoration: none !important;
}

.peys-badge__logo {
    height: 18px !important;
    width: auto !important;
    opacity: 0.8 !important;
    transition: opacity 0.2s !important;
}

.peys-badge__link:hover .peys-badge__logo {
    opacity: 1 !important;
}
</style>
