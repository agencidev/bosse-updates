<?php
/**
 * Setup Wizard - 3-stegs konfigurationsguide
 * Genererar config.php, variabler, innehåll och AI-filer
 */

// Guard: blockera om redan konfigurerad (config.php committas till git)
if (file_exists(__DIR__ . '/config.php')) {
    header('Location: /');
    exit;
}

$configOnlyMode = file_exists(__DIR__ . '/.installed');
if (!$configOnlyMode && file_exists(__DIR__ . '/data/content.json')) {
    $configOnlyMode = true;
    @file_put_contents(__DIR__ . '/.installed', 'installed');
}

// Ladda hjälpfunktioner (adjustBrightness, etc.) med fallback
$helpersFile = __DIR__ . '/cms/helpers.php';
if (file_exists($helpersFile)) {
    require_once $helpersFile;
}
require_once __DIR__ . '/includes/version.php';

if (!function_exists('adjustBrightness')) {
    function adjustBrightness(string $hex, int $percent): string {
        $hex = ltrim($hex, '#');
        if (strlen($hex) === 3) {
            $hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
        }
        $r = hexdec(substr($hex, 0, 2));
        $g = hexdec(substr($hex, 2, 2));
        $b = hexdec(substr($hex, 4, 2));
        if ($percent > 0) {
            $r = $r + (255 - $r) * $percent / 100;
            $g = $g + (255 - $g) * $percent / 100;
            $b = $b + (255 - $b) * $percent / 100;
        } else {
            $factor = (100 + $percent) / 100;
            $r = $r * $factor;
            $g = $g * $factor;
            $b = $b * $factor;
        }
        $r = max(0, min(255, round($r)));
        $g = max(0, min(255, round($g)));
        $b = max(0, min(255, round($b)));
        return '#' . str_pad(dechex($r), 2, '0', STR_PAD_LEFT)
                   . str_pad(dechex($g), 2, '0', STR_PAD_LEFT)
                   . str_pad(dechex($b), 2, '0', STR_PAD_LEFT);
    }
}

// Session (duplicerar bootstrap.php-inställningar)
ini_set('session.cookie_httponly', 1);
ini_set('session.cookie_secure', 0); // 0 för localhost under setup
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.use_strict_mode', 1);
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// CSRF-token
if (empty($_SESSION['setup_csrf'])) {
    $_SESSION['setup_csrf'] = bin2hex(random_bytes(32));
}

// Felmeddelanden
$errors = [];
$step = isset($_GET['step']) ? (int)$_GET['step'] : 1;
$step = max(1, min(3, $step));


// Pre-flight: kontrollera skrivbehörigheter
$writableCheck = [
    __DIR__ . '/config.php' => __DIR__,
    __DIR__ . '/assets/css/variables.css' => __DIR__ . '/assets/css',
    __DIR__ . '/assets/images/' => __DIR__ . '/assets/images',
    __DIR__ . '/data/' => __DIR__ . '/data',
    __DIR__ . '/.rules/' => __DIR__ . '/.rules',
    __DIR__ . '/includes/' => __DIR__ . '/includes',
];
$writableErrors = [];
foreach ($writableCheck as $label => $path) {
    if (is_dir($path) && !is_writable($path)) {
        $writableErrors[] = $path;
    } elseif (is_file($path) && !is_writable($path)) {
        $writableErrors[] = $path;
    }
}

// Spara stegdata i session
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Verifiera CSRF
    if (!isset($_POST['csrf_token']) || !hash_equals($_SESSION['setup_csrf'], $_POST['csrf_token'])) {
        $errors[] = 'Ogiltig CSRF-token. Ladda om sidan.';
    } else {
        if ($configOnlyMode) {
            // Config-only mode: bara admin + SMTP
            $admin_username = trim($_POST['admin_username'] ?? '');
            $admin_password = $_POST['admin_password'] ?? '';
            $admin_password_confirm = $_POST['admin_password_confirm'] ?? '';
            $admin_email = trim($_POST['admin_email'] ?? '');

            $smtp_host = trim($_POST['smtp_host'] ?? '');
            $smtp_port = (int)($_POST['smtp_port'] ?? 465);
            $smtp_encryption = $_POST['smtp_encryption'] ?? 'ssl';
            $smtp_username = trim($_POST['smtp_username'] ?? '');
            $smtp_password = $_POST['smtp_password'] ?? '';

            // Agency super-admin (valfritt)
            $agency_user = trim($_POST['agency_user'] ?? '');
            $agency_pass = $_POST['agency_pass'] ?? '';

            // GitHub (valfritt)
            $github_repo = trim($_POST['github_repo'] ?? '');
            $github_token = trim($_POST['github_token'] ?? '');

            if (strlen($admin_username) < 3) $errors[] = 'Användarnamn måste vara minst 3 tecken.';
            if (strlen($admin_password) < 8) $errors[] = 'Lösenord måste vara minst 8 tecken.';
            if ($admin_password !== $admin_password_confirm) $errors[] = 'Lösenorden matchar inte.';
            if (!empty($admin_email) && !filter_var($admin_email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Ange en giltig e-postadress.';
            if (!empty($agency_pass) && strlen($agency_pass) < 8) $errors[] = 'Super-admin lösenord måste vara minst 8 tecken.';

            if (!empty($smtp_host)) {
                if ($smtp_port < 1 || $smtp_port > 65535) $errors[] = 'Ange en giltig SMTP-port (1-65535).';
                if (empty($smtp_username)) $errors[] = 'SMTP-användarnamn krävs om SMTP-server anges.';
                if (empty($smtp_password)) $errors[] = 'SMTP-lösenord krävs om SMTP-server anges.';
                if (!in_array($smtp_encryption, ['ssl', 'tls'])) $smtp_encryption = 'ssl';
            }

            if (empty($errors)) {
                $data = [
                    'admin_username' => $admin_username,
                    'admin_password' => $admin_password,
                    'admin_email' => $admin_email,
                    'smtp_host' => $smtp_host,
                    'smtp_port' => $smtp_port,
                    'smtp_encryption' => $smtp_encryption,
                    'smtp_username' => $smtp_username,
                    'smtp_password' => $smtp_password,
                    'github_repo' => $github_repo,
                    'github_token' => $github_token,
                    'api_key' => trim($_POST['api_key'] ?? ''),
                    'agency_user' => $agency_user,
                    'agency_pass' => $agency_pass,
                ];
                $genErrors = generateConfigOnly($data);
                if (!empty($genErrors)) {
                    $errors = $genErrors;
                } else {
                    unset($_SESSION['setup_data']);
                    $step = 4;
                }
            }
        } else {
        $postStep = (int)($_POST['step'] ?? 1);

        if ($postStep === 1) {
            // Validera steg 1
            $site_name = trim($_POST['site_name'] ?? '');
            $contact_email = trim($_POST['contact_email'] ?? '');
            $contact_phone = trim($_POST['contact_phone'] ?? '');
            $site_url = trim($_POST['site_url'] ?? '');
            $site_description = trim($_POST['site_description'] ?? '');

            // SMTP-fält
            $smtp_host = trim($_POST['smtp_host'] ?? '');
            $smtp_port = (int)($_POST['smtp_port'] ?? 465);
            $smtp_encryption = $_POST['smtp_encryption'] ?? 'ssl';
            $smtp_username = trim($_POST['smtp_username'] ?? '');
            $smtp_password = $_POST['smtp_password'] ?? '';

            // GitHub (valfritt)
            $github_repo = trim($_POST['github_repo'] ?? '');
            $github_token = trim($_POST['github_token'] ?? '');

            // Google Analytics
            $has_analytics = $_POST['has_analytics'] ?? 'no';
            $ga_id = ($has_analytics === 'yes') ? trim($_POST['ga_id'] ?? '') : '';

            // Byrå
            $agency_preset = $_POST['agency_preset'] ?? 'peys';

            // Sociala medier
            $social_facebook = trim($_POST['social_facebook'] ?? '');
            $social_instagram = trim($_POST['social_instagram'] ?? '');
            $social_linkedin = trim($_POST['social_linkedin'] ?? '');

            // Öppettider
            $hours_weekdays = trim($_POST['hours_weekdays'] ?? '');
            $hours_weekends = trim($_POST['hours_weekends'] ?? '');

            if (empty($site_name)) $errors[] = 'Företagsnamn krävs.';
            if (empty($contact_email) || !filter_var($contact_email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Giltig e-postadress krävs.';
            if (empty($site_url) || !filter_var($site_url, FILTER_VALIDATE_URL)) $errors[] = 'Giltig webbadress krävs.';
            if (empty($site_description)) $errors[] = 'Beskrivning krävs.';

            // SMTP-validering: om host anges måste port+user+pass också fyllas i
            if (!empty($smtp_host)) {
                if ($smtp_port < 1 || $smtp_port > 65535) $errors[] = 'Ange en giltig SMTP-port (1-65535).';
                if (empty($smtp_username)) $errors[] = 'SMTP-användarnamn krävs om SMTP-server anges.';
                if (empty($smtp_password)) $errors[] = 'SMTP-lösenord krävs om SMTP-server anges.';
                if (!in_array($smtp_encryption, ['ssl', 'tls'])) $smtp_encryption = 'ssl';
            }

            // GA-validering (valfritt, men om angivet måste det börja med G-)
            if (!empty($ga_id) && !preg_match('/^G-[A-Z0-9]+$/', $ga_id)) {
                $errors[] = 'Google Analytics ID måste ha formatet G-XXXXXXXXX.';
            }

            // URL-validering sociala medier (valfria)
            foreach (['social_facebook' => $social_facebook, 'social_instagram' => $social_instagram, 'social_linkedin' => $social_linkedin] as $name => $url) {
                if (!empty($url) && !filter_var($url, FILTER_VALIDATE_URL)) {
                    $labels = ['social_facebook' => 'Facebook', 'social_instagram' => 'Instagram', 'social_linkedin' => 'LinkedIn'];
                    $errors[] = $labels[$name] . '-URL måste vara en giltig webbadress.';
                }
            }

            if (empty($errors)) {
                $_SESSION['setup_data'] = array_merge($_SESSION['setup_data'] ?? [], [
                    'site_name' => $site_name,
                    'contact_email' => $contact_email,
                    'contact_phone' => $contact_phone,
                    'site_url' => rtrim($site_url, '/'),
                    'site_description' => $site_description,
                    'smtp_host' => $smtp_host,
                    'smtp_port' => $smtp_port,
                    'smtp_encryption' => $smtp_encryption,
                    'smtp_username' => $smtp_username,
                    'smtp_password' => $smtp_password,
                    'github_repo' => $github_repo,
                    'github_token' => $github_token,
                    'ga_id' => $ga_id,
                    'social_facebook' => $social_facebook,
                    'social_instagram' => $social_instagram,
                    'social_linkedin' => $social_linkedin,
                    'hours_weekdays' => $hours_weekdays,
                    'hours_weekends' => $hours_weekends,
                    'agency_preset' => $agency_preset,
                ]);
                header('Location: /setup?step=2');
                exit;
            }
            $step = 1;
        } elseif ($postStep === 2) {
            // Validera steg 2
            $primary_color = $_POST['primary_color'] ?? '#8b5cf6';
            $secondary_color = $_POST['secondary_color'] ?? '#379b83';
            $accent_color = $_POST['accent_color'] ?? '#379b83';
            $font_heading = $_POST['font_heading'] ?? 'System UI';
            $font_body = $_POST['font_body'] ?? 'System UI';

            $allowedFonts = [
                'System UI',
                // Sans-serif
                'Inter', 'Roboto', 'Open Sans', 'Lato', 'Montserrat', 'Poppins', 'Nunito', 'Raleway',
                'Ubuntu', 'Rubik', 'Work Sans', 'DM Sans', 'Manrope', 'Plus Jakarta Sans', 'Outfit',
                'Figtree', 'Sora', 'Space Grotesk', 'Albert Sans', 'Be Vietnam Pro', 'Lexend',
                'Barlow', 'Mulish', 'Jost', 'Karla', 'Quicksand', 'Cabin', 'Archivo', 'Heebo',
                'Fira Sans', 'Source Sans 3', 'Noto Sans', 'PT Sans', 'Asap', 'Exo 2', 'Overpass',
                // Serif
                'Playfair Display', 'Lora', 'Merriweather', 'PT Serif', 'Libre Baskerville', 'Crimson Text',
                'EB Garamond', 'Source Serif 4', 'Cormorant Garamond', 'Bitter', 'Spectral', 'Fraunces',
                'DM Serif Display', 'Libre Caslon Text', 'Bodoni Moda', 'Noto Serif', 'Vollkorn',
                'Josefin Slab', 'Cardo', 'Old Standard TT', 'Literata', 'Newsreader',
                // Display
                'Oswald', 'Bebas Neue', 'Anton', 'Righteous', 'Abril Fatface', 'Alfa Slab One',
                'Staatliches', 'Russo One', 'Bungee', 'Fredoka One', 'Pacifico', 'Lobster',
                'Permanent Marker', 'Satisfy', 'Dancing Script', 'Great Vibes', 'Caveat', 'Kalam',
                // Monospace
                'Fira Code', 'JetBrains Mono', 'Source Code Pro', 'IBM Plex Mono', 'Space Mono',
                'Roboto Mono', 'Ubuntu Mono', 'Inconsolata',
                // Swedish/Scandinavian friendly
                'Rethink Sans', 'Instrument Sans', 'Onest', 'Satoshi', 'General Sans',
                'Custom'  // For custom uploaded fonts
            ];
            // Allow custom font names as well
            if (!in_array($font_heading, $allowedFonts) && $font_heading !== 'Custom') $font_heading = 'System UI';
            if (!in_array($font_body, $allowedFonts) && $font_body !== 'Custom') $font_body = 'System UI';

            // Nya brand guide-fält
            $border_radius = $_POST['border_radius'] ?? 'rounded';
            $button_style = $_POST['button_style'] ?? 'filled';
            $tonality = $_POST['tonality'] ?? 'professional';
            $layout_width = $_POST['layout_width'] ?? 'normal';
            $bg_pattern = $_POST['bg_pattern'] ?? 'solid';
            $spacing_feel = $_POST['spacing_feel'] ?? 'normal';

            $allowedRadius = ['sharp', 'rounded', 'soft', 'pill'];
            $allowedButtonStyle = ['filled', 'outline', 'ghost'];
            $allowedTonality = ['professional', 'playful', 'minimal'];
            $allowedLayoutWidth = ['narrow', 'normal', 'wide'];
            $allowedBgPattern = ['solid', 'gradient', 'subtle'];
            $allowedSpacingFeel = ['compact', 'normal', 'airy'];

            if (!in_array($border_radius, $allowedRadius)) $border_radius = 'rounded';
            if (!in_array($button_style, $allowedButtonStyle)) $button_style = 'filled';
            if (!in_array($tonality, $allowedTonality)) $tonality = 'professional';
            if (!in_array($layout_width, $allowedLayoutWidth)) $layout_width = 'normal';
            if (!in_array($bg_pattern, $allowedBgPattern)) $bg_pattern = 'solid';
            if (!in_array($spacing_feel, $allowedSpacingFeel)) $spacing_feel = 'normal';

            // Logo uploads
            $logoErrors = [];
            $allowedMimes = ['image/png', 'image/jpeg', 'image/svg+xml', 'image/webp'];
            $maxSize = 5 * 1024 * 1024; // 5MB

            foreach (['logo_dark', 'logo_light'] as $logoField) {
                if (isset($_FILES[$logoField]) && $_FILES[$logoField]['error'] === UPLOAD_ERR_OK) {
                    $finfo = new finfo(FILEINFO_MIME_TYPE);
                    $mime = $finfo->file($_FILES[$logoField]['tmp_name']);

                    if (!in_array($mime, $allowedMimes)) {
                        $logoErrors[] = ucfirst(str_replace('_', ' ', $logoField)) . ': Ogiltigt filformat. Tillåtna: PNG, JPG, SVG, WebP.';
                    } elseif ($_FILES[$logoField]['size'] > $maxSize) {
                        $logoErrors[] = ucfirst(str_replace('_', ' ', $logoField)) . ': Filen är för stor (max 5MB).';
                    }
                }
            }

            if (!empty($logoErrors)) {
                $errors = array_merge($errors, $logoErrors);
            }

            // Favicon validation
            if (isset($_FILES['favicon']) && $_FILES['favicon']['error'] === UPLOAD_ERR_OK) {
                $faviconMimes = ['image/png', 'image/x-icon', 'image/vnd.microsoft.icon', 'image/svg+xml'];
                $finfo = new finfo(FILEINFO_MIME_TYPE);
                $faviconMime = $finfo->file($_FILES['favicon']['tmp_name']);

                if (!in_array($faviconMime, $faviconMimes)) {
                    $logoErrors[] = 'Favicon: Ogiltigt filformat. Tillåtna: PNG, ICO, SVG.';
                } elseif ($_FILES['favicon']['size'] > 1024 * 1024) { // 1MB max for favicon
                    $logoErrors[] = 'Favicon: Filen är för stor (max 1MB).';
                }
            }

            if (!empty($logoErrors)) {
                $errors = array_merge($errors, $logoErrors);
            }

            if (empty($errors)) {
                // Spara logotyper
                $imgDir = __DIR__ . '/assets/images';
                foreach (['logo_dark', 'logo_light'] as $logoField) {
                    if (isset($_FILES[$logoField]) && $_FILES[$logoField]['error'] === UPLOAD_ERR_OK) {
                        $dest = $imgDir . '/' . str_replace('_', '-', $logoField) . '.png';
                        move_uploaded_file($_FILES[$logoField]['tmp_name'], $dest);
                    }
                }

                // Spara favicon
                if (isset($_FILES['favicon']) && $_FILES['favicon']['error'] === UPLOAD_ERR_OK) {
                    $ext = strtolower(pathinfo($_FILES['favicon']['name'], PATHINFO_EXTENSION));
                    if ($ext === 'ico') {
                        $faviconDest = $imgDir . '/favicon.ico';
                    } else {
                        $faviconDest = $imgDir . '/favicon.png';
                    }
                    move_uploaded_file($_FILES['favicon']['tmp_name'], $faviconDest);
                    $_SESSION['setup_data']['has_custom_favicon'] = true;
                }

                // Spara custom font
                if (isset($_FILES['custom_font']) && $_FILES['custom_font']['error'] === UPLOAD_ERR_OK) {
                    $fontDir = __DIR__ . '/assets/fonts';
                    if (!is_dir($fontDir)) {
                        mkdir($fontDir, 0755, true);
                    }
                    $fontExt = strtolower(pathinfo($_FILES['custom_font']['name'], PATHINFO_EXTENSION));
                    $fontName = pathinfo($_FILES['custom_font']['name'], PATHINFO_FILENAME);
                    $fontName = preg_replace('/[^a-zA-Z0-9-_]/', '', $fontName);
                    $fontDest = $fontDir . '/custom-font.' . $fontExt;
                    if (move_uploaded_file($_FILES['custom_font']['tmp_name'], $fontDest)) {
                        $_SESSION['setup_data']['custom_font_file'] = 'custom-font.' . $fontExt;
                        $_SESSION['setup_data']['custom_font_name'] = $fontName;
                    }
                }

                $_SESSION['setup_data'] = array_merge($_SESSION['setup_data'] ?? [], [
                    'primary_color' => $primary_color,
                    'secondary_color' => $secondary_color,
                    'accent_color' => $accent_color,
                    'font_heading' => $font_heading,
                    'font_body' => $font_body,
                    'border_radius' => $border_radius,
                    'button_style' => $button_style,
                    'tonality' => $tonality,
                    'layout_width' => $layout_width,
                    'bg_pattern' => $bg_pattern,
                    'spacing_feel' => $spacing_feel,
                ]);
                header('Location: /setup?step=3');
                exit;
            }
            $step = 2;
        } elseif ($postStep === 3) {
            // Validera steg 3
            $admin_username = trim($_POST['admin_username'] ?? '');
            $admin_password = $_POST['admin_password'] ?? '';
            $admin_password_confirm = $_POST['admin_password_confirm'] ?? '';
            $admin_email = trim($_POST['admin_email'] ?? '');
            $agency_user = trim($_POST['agency_user'] ?? '');
            $agency_pass = $_POST['agency_pass'] ?? '';

            if (strlen($admin_username) < 3) $errors[] = 'Användarnamn måste vara minst 3 tecken.';
            if (strlen($admin_password) < 8) $errors[] = 'Lösenord måste vara minst 8 tecken.';
            if ($admin_password !== $admin_password_confirm) $errors[] = 'Lösenorden matchar inte.';
            if (!empty($admin_email) && !filter_var($admin_email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Ange en giltig e-postadress.';
            if (!empty($agency_pass) && strlen($agency_pass) < 8) $errors[] = 'Super-admin lösenord måste vara minst 8 tecken.';

            if (empty($errors)) {
                $data = $_SESSION['setup_data'] ?? [];
                $data['admin_username'] = $admin_username;
                $data['admin_password'] = $admin_password;
                $data['admin_email'] = $admin_email;
                $data['agency_user'] = $agency_user;
                $data['agency_pass'] = $agency_pass;

                // === GENERERA ALLA FILER ===
                $genErrors = generateAllFiles($data);
                if (!empty($genErrors)) {
                    $errors = $genErrors;
                    $step = 3;
                } else {
                    // Pusha brand-filer till GitHub om konfigurerat
                    if (!empty($data['github_repo']) && !empty($data['github_token'])) {
                        // Ladda config.php som just skapades så konstanterna finns
                        if (!defined('GITHUB_REPO')) {
                            require_once __DIR__ . '/config.php';
                        }
                        require_once __DIR__ . '/security/updater.php';
                        $brandFiles = [];
                        $imgDir = __DIR__ . '/assets/images';
                        foreach (['logo-dark.png', 'logo-light.png', 'favicon.png', 'favicon.ico', 'apple-touch-icon.png'] as $f) {
                            if (file_exists($imgDir . '/' . $f)) {
                                $brandFiles[] = 'assets/images/' . $f;
                            }
                        }
                        // Inkludera CSS-filer och andra setup-genererade filer
                        foreach (['assets/css/variables.css', 'assets/css/overrides.css', 'assets/css/main.css', 'assets/css/components.css', 'includes/header.php', 'includes/footer.php', 'includes/fonts.php', '.installed', '.site-url'] as $f) {
                            if (file_exists(__DIR__ . '/' . $f)) {
                                $brandFiles[] = $f;
                            }
                        }
                        if (!empty($brandFiles)) {
                            push_to_github($brandFiles, BOSSE_VERSION);
                        }
                    }

                    // Rensa session-data
                    unset($_SESSION['setup_data']);
                    $step = 4; // Färdig-sida
                }
            } else {
                $step = 3;
            }
        }
        }
    }
}

/**
 * Generera alla konfigurationsfiler
 */
function generateAllFiles(array $data): array {
    $errors = [];

    // 1. config.php
    $sessionSecret = bin2hex(random_bytes(32));
    $csrfSalt = bin2hex(random_bytes(32));
    $passwordHash = password_hash($data['admin_password'], PASSWORD_BCRYPT);

    $configContent = "<?php\n";
    $configContent .= "/**\n * Konfiguration - Genererad av Setup Wizard\n * " . date('Y-m-d H:i:s') . "\n */\n\n";
    $configContent .= "// Site\n";
    $configContent .= "define('SITE_URL', " . var_export($data['site_url'], true) . ");\n";
    $configContent .= "define('SITE_NAME', " . var_export($data['site_name'], true) . ");\n";
    $configContent .= "define('SITE_DESCRIPTION', " . var_export($data['site_description'], true) . ");\n";
    $configContent .= "define('CONTACT_EMAIL', " . var_export($data['contact_email'], true) . ");\n";
    $configContent .= "define('CONTACT_PHONE', " . var_export($data['contact_phone'], true) . ");\n\n";
    $configContent .= "// Admin\n";
    $configContent .= "define('ADMIN_USERNAME', " . var_export($data['admin_username'], true) . ");\n";
    $configContent .= "define('ADMIN_PASSWORD_HASH', " . var_export($passwordHash, true) . ");\n";
    if (!empty($data['admin_email'])) {
        $configContent .= "define('ADMIN_EMAIL', " . var_export($data['admin_email'], true) . ");\n";
    }
    $configContent .= "\n";
    // Agency super-admin
    $agencyUser = trim($data['agency_user'] ?? 'admin');
    $agencyPassHash = password_hash($data['agency_pass'] ?? bin2hex(random_bytes(16)), PASSWORD_BCRYPT);
    $configContent .= "// Agency super-admin\n";
    $configContent .= "define('AGENCY_USERNAME', " . var_export($agencyUser, true) . ");\n";
    $configContent .= "define('AGENCY_PASSWORD_HASH', " . var_export($agencyPassHash, true) . ");\n\n";
    $configContent .= "// Security\n";
    $configContent .= "define('SESSION_SECRET', " . var_export($sessionSecret, true) . ");\n";
    $configContent .= "define('CSRF_TOKEN_SALT', " . var_export($csrfSalt, true) . ");\n\n";
    // SMTP (om konfigurerat)
    if (!empty($data['smtp_host'])) {
        $configContent .= "// SMTP\n";
        $configContent .= "define('SMTP_HOST', " . var_export($data['smtp_host'], true) . ");\n";
        $configContent .= "define('SMTP_PORT', " . (int)$data['smtp_port'] . ");\n";
        $configContent .= "define('SMTP_ENCRYPTION', " . var_export($data['smtp_encryption'], true) . ");\n";
        $configContent .= "define('SMTP_USERNAME', " . var_export($data['smtp_username'], true) . ");\n";
        $configContent .= "define('SMTP_PASSWORD', " . var_export($data['smtp_password'], true) . ");\n\n";
    }

    // GitHub (om konfigurerat)
    if (!empty($data['github_repo']) && !empty($data['github_token'])) {
        $configContent .= "// GitHub (för automatisk push vid uppdatering)\n";
        $configContent .= "define('GITHUB_REPO', " . var_export($data['github_repo'], true) . ");\n";
        $configContent .= "define('GITHUB_TOKEN', " . var_export($data['github_token'], true) . ");\n\n";
    }

    // Google Analytics (om konfigurerat)
    if (!empty($data['ga_id'])) {
        $configContent .= "// Google Analytics\n";
        $configContent .= "define('GOOGLE_ANALYTICS_ID', " . var_export($data['ga_id'], true) . ");\n\n";
    }

    // Sociala medier (om konfigurerat)
    $hasSocial = !empty($data['social_facebook']) || !empty($data['social_instagram']) || !empty($data['social_linkedin']);
    if ($hasSocial) {
        $configContent .= "// Sociala medier\n";
        if (!empty($data['social_facebook'])) $configContent .= "define('SOCIAL_FACEBOOK', " . var_export($data['social_facebook'], true) . ");\n";
        if (!empty($data['social_instagram'])) $configContent .= "define('SOCIAL_INSTAGRAM', " . var_export($data['social_instagram'], true) . ");\n";
        if (!empty($data['social_linkedin'])) $configContent .= "define('SOCIAL_LINKEDIN', " . var_export($data['social_linkedin'], true) . ");\n";
        $configContent .= "\n";
    }

    // Öppettider (om konfigurerat)
    if (!empty($data['hours_weekdays'])) {
        $configContent .= "// Öppettider\n";
        $configContent .= "define('HOURS_WEEKDAYS', " . var_export($data['hours_weekdays'], true) . ");\n";
        $configContent .= "define('HOURS_WEEKENDS', " . var_export($data['hours_weekends'] ?? 'Stängt', true) . ");\n\n";
    }

    $configContent .= "// Environment\n";
    $configContent .= "define('ENVIRONMENT', 'development');\n\n";

    // Agency preset → write agency-defaults.json
    $agencyPresets = [
        'peys' => [
            'name' => 'PEYS',
            'url' => 'https://peys.se',
            'logo_light' => '/assets/images/cms/peys-logo-light.png',
            'logo_dark' => '/assets/images/cms/peys-logo-dark.png',
            'badge_text' => 'Sidan drivs och hanteras av',
            'badge_bg' => '#033234',
            'corner_text' => 'Skapad av oss 🥳',
            'login_tab' => 'PEYS',
            'cms_bg' => '#033234',
            'cms_accent' => '#379b83',
            'cms_font' => 'DM Sans',
            'cms_font_heading' => 'Space Grotesk',
        ],
        'grw' => [
            'name' => 'GRW Media AB',
            'url' => 'https://grwmedia.se',
            'logo_light' => '/assets/images/cms/grw-logo-light.png',
            'logo_dark' => '/assets/images/cms/grw-logo-dark.png',
            'badge_text' => 'Sidan drivs och hanteras av',
            'badge_bg' => '#1e1c1c',
            'corner_text' => 'Skapad av GRW Media',
            'login_tab' => 'GRW',
            'cms_bg' => '#1e1c1c',
            'cms_accent' => '#ed7d91',
            'cms_font' => 'Montserrat',
            'cms_font_heading' => 'Montserrat',
        ],
    ];
    $preset = $agencyPresets[$data['agency_preset'] ?? 'peys'] ?? $agencyPresets['peys'];
    file_put_contents(__DIR__ . '/agency-defaults.json', json_encode($preset, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n", LOCK_EX);

    // Agenci Super Admin
    $saToken = bin2hex(random_bytes(32)); // 64 tecken
    $configContent .= "// Agenci\n";
    $configContent .= "define('AGENCI_SUPER_ADMIN_TOKEN', " . var_export($saToken, true) . ");\n";
    $configContent .= "define('AGENCI_UPDATE_URL', 'https://raw.githubusercontent.com/agencidev/bosse-updates/main');\n";
    $configContent .= "define('AGENCI_UPDATE_KEY', '');\n\n";

    // API
    $apiKey = bin2hex(random_bytes(32));
    $configContent .= "// API\n";
    $configContent .= "define('API_KEY', '{$apiKey}');\n";
    $configContent .= "define('API_RATE_LIMIT', 60);\n";
    $configContent .= "define('API_RATE_WINDOW', 60);\n";
    $configContent .= "define('API_CORS_ORIGINS', '*');\n";

    if (file_put_contents(__DIR__ . '/config.php', $configContent) === false) {
        $errors[] = 'Kunde inte skriva config.php';
        return $errors;
    }

    // 2. variables.css
    $cssFile = __DIR__ . '/assets/css/variables.css';
    if (file_exists($cssFile)) {
        $css = file_get_contents($cssFile);

        $primaryDark = adjustBrightness($data['primary_color'], -15);
        $primaryLight = adjustBrightness($data['primary_color'], 20);
        $secondaryDark = adjustBrightness($data['secondary_color'], -15);

        $css = preg_replace('/(--color-primary:\s*)#[0-9a-fA-F]{3,8}/', '${1}' . $data['primary_color'], $css);
        $css = preg_replace('/(--color-primary-dark:\s*)#[0-9a-fA-F]{3,8}/', '${1}' . $primaryDark, $css);
        $css = preg_replace('/(--color-primary-light:\s*)#[0-9a-fA-F]{3,8}/', '${1}' . $primaryLight, $css);
        $css = preg_replace('/(--color-secondary:\s*)#[0-9a-fA-F]{3,8}/', '${1}' . $data['secondary_color'], $css);
        $css = preg_replace('/(--color-secondary-dark:\s*)#[0-9a-fA-F]{3,8}/', '${1}' . $secondaryDark, $css);

        // Font stacks
        $fontPrimary = buildFontStack($data['font_body']);
        $fontHeading = buildFontStack($data['font_heading']);

        $css = preg_replace('/(--font-primary:\s*).+?;/', '${1}' . $fontPrimary . ';', $css);
        $css = preg_replace('/(--font-heading:\s*).+?;/', '${1}' . $fontHeading . ';', $css);

        // Hörnradie
        $radiusMap = ['sharp' => '0.125rem', 'rounded' => '0.5rem', 'soft' => '1rem', 'pill' => '9999px'];
        $radiusLgMap = ['sharp' => '0.25rem', 'rounded' => '1rem', 'soft' => '1.5rem', 'pill' => '9999px'];
        $radiusVal = $radiusMap[$data['border_radius'] ?? 'rounded'] ?? '0.5rem';
        $radiusLgVal = $radiusLgMap[$data['border_radius'] ?? 'rounded'] ?? '1rem';
        $css = preg_replace('/(--radius-md:\s*)[^;]+;/', '${1}' . $radiusVal . ';', $css);
        $css = preg_replace('/(--radius-lg:\s*)[^;]+;/', '${1}' . $radiusLgVal . ';', $css);

        // Knappstil (button-radius)
        $btnRadiusMap = ['sharp' => '0.25rem', 'rounded' => '0.5rem', 'soft' => '1rem', 'pill' => '9999px'];
        $btnRadius = $btnRadiusMap[$data['border_radius'] ?? 'rounded'] ?? '0.5rem';
        $buttonStyle = $data['button_style'] ?? 'filled';
        if (!str_contains($css, '--button-radius')) {
            $css = str_replace('--radius-full: 9999px;', "--radius-full: 9999px;\n  --button-radius: {$btnRadius};\n  --button-style: {$buttonStyle};", $css);
        } else {
            $css = preg_replace('/(--button-radius:\s*)[^;]+;/', '${1}' . $btnRadius . ';', $css);
            $css = preg_replace('/(--button-style:\s*)[^;]+;/', '${1}' . $buttonStyle . ';', $css);
        }

        // Layout-bredd
        $widthMap = ['narrow' => '960px', 'normal' => '1200px', 'wide' => '1440px'];
        $containerWidth = $widthMap[$data['layout_width'] ?? 'normal'] ?? '1200px';
        $css = preg_replace('/(--container-max-width:\s*)[^;]+;/', '${1}' . $containerWidth . ';', $css);

        // Accent color
        if (!empty($data['accent_color'])) {
            if (!str_contains($css, '--color-accent')) {
                $css = str_replace('--color-secondary-dark:', "--color-accent: " . $data['accent_color'] . ";\n\n  /* Secondary Colors */\n  --color-secondary-dark:", $css);
                // Remove the duplicate "Secondary Colors" comment if it exists
                $css = str_replace("/* Secondary Colors */\n  /* Secondary Colors */", "/* Secondary Colors */", $css);
            } else {
                $css = preg_replace('/(--color-accent:\s*)#[0-9a-fA-F]{3,8}/', '${1}' . $data['accent_color'], $css);
            }
        }

        // Section padding (spacing feel)
        $sectionPaddingMap = ['compact' => '3rem', 'normal' => '4rem', 'airy' => '6rem'];
        $sectionPadding = $sectionPaddingMap[$data['spacing_feel'] ?? 'normal'] ?? '4rem';
        if (!str_contains($css, '--section-padding')) {
            $css = str_replace('--container-padding:', "--section-padding: {$sectionPadding};\n  --container-padding:", $css);
        } else {
            $css = preg_replace('/(--section-padding:\s*)[^;]+;/', '${1}' . $sectionPadding . ';', $css);
        }

        if (file_put_contents($cssFile, $css, LOCK_EX) === false) {
            $errors[] = 'Kunde inte skriva till: ' . $cssFile;
        }
    }

    // 3. data/content.json
    // OBS: hero.description ska ALDRIG vara site_description - den är för SEO/Google
    $contentJson = [
        'hero' => [
            'title' => 'Välkommen till ' . $data['site_name'],
            'description' => 'Vi hjälper dig att nå dina mål med moderna lösningar',
            'cta_primary' => 'Kontakta oss',
            'cta_secondary' => 'Läs mer',
        ],
        'home' => [
            'meta_title' => $data['site_name'] . ' - ' . $data['site_description'],
            'meta_description' => $data['site_description'],
        ],
        'footer' => [
            'company_name' => $data['site_name'],
            'email' => $data['contact_email'],
            'phone' => $data['contact_phone'],
        ],
    ];

    $dataDir = __DIR__ . '/data';
    if (!is_dir($dataDir)) {
        mkdir($dataDir, 0755, true);
    }
    if (file_put_contents($dataDir . '/content.json', json_encode($contentJson, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX) === false) {
        $errors[] = 'Kunde inte skriva till: ' . $dataDir . '/content.json';
    }

    // 4. .rules/brand-guide.md
    $rulesDir = __DIR__ . '/.rules';
    if (!is_dir($rulesDir)) {
        mkdir($rulesDir, 0755, true);
    }

    $brandTemplate = file_get_contents(__DIR__ . '/templates/brand-guide-template.md');
    if ($brandTemplate) {
        // Hörnradie-labels
        $radiusLabels = ['sharp' => 'Skarp (2px)', 'rounded' => 'Rundad (8px)', 'soft' => 'Mjuk (16px)', 'pill' => 'Pill (helrund)'];
        $radiusValues = ['sharp' => '0.125rem', 'rounded' => '0.5rem', 'soft' => '1rem', 'pill' => '9999px'];
        $btnRadiusValues = ['sharp' => '0.25rem', 'rounded' => '0.5rem', 'soft' => '1rem', 'pill' => '9999px'];

        // Knappstil-labels
        $btnLabels = ['filled' => 'Fylld', 'outline' => 'Outline', 'ghost' => 'Ghost'];
        $btnDescs = [
            'filled' => 'Bakgrundsfärg med vit text',
            'outline' => 'Transparent med färgad ram',
            'ghost' => 'Transparent utan ram, enbart text',
        ];

        // Tonalitet-labels
        $toneLabels = ['professional' => 'Professionell', 'playful' => 'Lekfull', 'minimal' => 'Minimalistisk'];
        $toneDescs = [
            'professional' => "- **Stil:** Tydlig, koncis, handlingsorienterad\n- Undvik: Jargong, överdriven formalitet, passiv form",
            'playful' => "- **Stil:** Varm, personlig, energisk\n- Undvik: Stelhet, formellt språk, passiv form",
            'minimal' => "- **Stil:** Kort, ren, avskalad\n- Undvik: Överflödiga ord, utsmyckningar, långa meningar",
        ];

        // Layout-labels
        $widthLabels = ['narrow' => 'Smal', 'normal' => 'Normal', 'wide' => 'Bred'];
        $widthValues = ['narrow' => '960px', 'normal' => '1200px', 'wide' => '1440px'];

        $br = $data['border_radius'] ?? 'rounded';
        $bs = $data['button_style'] ?? 'filled';
        $tn = $data['tonality'] ?? 'professional';
        $lw = $data['layout_width'] ?? 'normal';
        $bg = $data['bg_pattern'] ?? 'solid';
        $sp = $data['spacing_feel'] ?? 'normal';

        // Background pattern labels
        $bgLabels = ['solid' => 'Solid (enfärgad)', 'gradient' => 'Gradient (tonad)', 'subtle' => 'Subtil (mönster)'];
        $bgDescs = [
            'solid' => 'Rena, enfärgade bakgrunder. Sektioner alternerar mellan vit och grå.',
            'gradient' => 'Subtila gradienter med primärfärg. Hero och CTA-sektioner kan ha tonade bakgrunder.',
            'subtle' => 'Diskreta mönster eller texturer. Använd CSS-patterns eller SVG-bakgrunder sparsamt.',
        ];

        // Spacing feel labels
        $spacingLabels = ['compact' => 'Kompakt', 'normal' => 'Normal', 'airy' => 'Luftig'];
        $spacingValues = ['compact' => '3rem', 'normal' => '4rem', 'airy' => '6rem'];
        $spacingDescs = [
            'compact' => 'Tätare sektions-padding (3rem). Passar informationstäta sidor.',
            'normal' => 'Standard sektions-padding (4rem). Balanserad känsla.',
            'airy' => 'Generös sektions-padding (6rem). Lyxig, andningsbar känsla.',
        ];

        $brandGuide = str_replace(
            [
                '{{COMPANY_NAME}}', '{{PRIMARY_COLOR}}', '{{SECONDARY_COLOR}}', '{{ACCENT_COLOR}}',
                '{{FONT_HEADING}}', '{{FONT_BODY}}', '{{DATE}}',
                '{{BORDER_RADIUS_LABEL}}', '{{BORDER_RADIUS_VALUE}}',
                '{{BUTTON_STYLE_LABEL}}', '{{BUTTON_RADIUS_VALUE}}', '{{BUTTON_STYLE_DESC}}',
                '{{TONALITY_LABEL}}', '{{TONALITY_DESC}}',
                '{{LAYOUT_WIDTH_LABEL}}', '{{LAYOUT_WIDTH_VALUE}}',
                '{{BG_PATTERN_LABEL}}', '{{BG_PATTERN_DESC}}',
                '{{SPACING_FEEL_LABEL}}', '{{SPACING_FEEL_VALUE}}', '{{SPACING_FEEL_DESC}}',
            ],
            [
                $data['site_name'], $data['primary_color'], $data['secondary_color'], $data['accent_color'],
                $data['font_heading'], $data['font_body'], date('Y-m-d'),
                $radiusLabels[$br] ?? 'Rundad (8px)', $radiusValues[$br] ?? '0.5rem',
                $btnLabels[$bs] ?? 'Fylld', $btnRadiusValues[$br] ?? '0.5rem', $btnDescs[$bs] ?? 'Bakgrundsfärg med vit text',
                $toneLabels[$tn] ?? 'Professionell', $toneDescs[$tn] ?? '',
                $widthLabels[$lw] ?? 'Normal', $widthValues[$lw] ?? '1200px',
                $bgLabels[$bg] ?? 'Solid (enfärgad)', $bgDescs[$bg] ?? '',
                $spacingLabels[$sp] ?? 'Normal', $spacingValues[$sp] ?? '4rem', $spacingDescs[$sp] ?? '',
            ],
            $brandTemplate
        );
        if (file_put_contents($rulesDir . '/brand-guide.md', $brandGuide, LOCK_EX) === false) {
            $errors[] = 'Kunde inte skriva till: brand-guide.md';
        }
    }

    // 5. .rules/ai-rules.md
    $aiTemplate = file_get_contents(__DIR__ . '/templates/ai-rules-template.md');
    if ($aiTemplate) {
        $aiRules = str_replace('{{COMPANY_NAME}}', $data['site_name'], $aiTemplate);
        if (file_put_contents($rulesDir . '/ai-rules.md', $aiRules, LOCK_EX) === false) {
            $errors[] = 'Kunde inte skriva till: ai-rules.md';
        }
    }

    // 6. data/.setup-complete
    if (file_put_contents($dataDir . '/.setup-complete', 'Setup completed: ' . date('Y-m-d H:i:s') . "\n", LOCK_EX) === false) {
        $errors[] = 'Kunde inte skriva till: .setup-complete';
    }

    // 6a. .installed marker (committas till git — triggar config-only mode vid re-klon)
    if (file_put_contents(__DIR__ . '/.installed', 'installed', LOCK_EX) === false) {
        $errors[] = 'Kunde inte skriva till: .installed';
    }

    // 6b. .site-url (committas till git — används av portalen för att visa domän)
    if (file_put_contents(__DIR__ . '/.site-url', rtrim($data['site_url'], '/'), LOCK_EX) === false) {
        $errors[] = 'Kunde inte skriva till: .site-url';
    }

    // 6b. data/projects.json (tom array om den inte finns)
    $projectsFile = $dataDir . '/projects.json';
    if (!file_exists($projectsFile)) {
        if (file_put_contents($projectsFile, json_encode([], JSON_PRETTY_PRINT), LOCK_EX) === false) {
            $errors[] = 'Kunde inte skriva till: projects.json';
        }
    }

    // 6c. CLAUDE.md (referens-fil för Claude Code)
    $claudeMdContent = "# CLAUDE.md\n\n";
    $claudeMdContent .= "Se `.rules/ai-rules.md` för fullständiga AI-regler och kodstandarder.\n";
    $claudeMdContent .= "Se `.rules/brand-guide.md` för varumärkesguide (färger, typsnitt, tonalitet).\n\n";
    $claudeMdContent .= "## Snabbref\n\n";
    $claudeMdContent .= "### CSS-ändringar\n";
    $claudeMdContent .= "- **Skriv alltid i:** `assets/css/overrides.css`\n";
    $claudeMdContent .= "- **Ändra ALDRIG:** `variables.css` eller `components.css`\n\n";
    $claudeMdContent .= "### Innehåll\n";
    $claudeMdContent .= "- **Sidinnehåll:** `data/content.json`\n";
    $claudeMdContent .= "- **Inlägg/projekt:** `data/projects.json` (status: `\"published\"` för att synas)\n\n";
    $claudeMdContent .= "### Nya sektioner\n";
    $claudeMdContent .= "Använd ALLTID `editable_text()` och `editable_image()` för redigerbart innehåll:\n\n";
    $claudeMdContent .= "```php\n";
    $claudeMdContent .= "<?php editable_text('sektion', 'titel', 'Standardrubrik', 'h2', 'css-klass'); ?>\n";
    $claudeMdContent .= "<?php editable_text('sektion', 'text', 'Standardtext', 'p', 'css-klass'); ?>\n";
    $claudeMdContent .= "<?php editable_image('sektion', 'bild', '/assets/images/placeholder.jpg', 'Alt-text', 'css-klass'); ?>\n";
    $claudeMdContent .= "```\n\n";
    $claudeMdContent .= "### Nya sidor (VIKTIGT!)\n";
    $claudeMdContent .= "När du skapar nya sidor (om-oss.php, tjanster.php etc.):\n";
    $claudeMdContent .= "1. **Skapa filen i `pages/`-mappen** (t.ex. `pages/om-oss.php`)\n";
    $claudeMdContent .= "2. **Kopiera** `templates/page-template.php` som bas\n";
    $claudeMdContent .= "3. **MÅSTE inkludera:** `header.php` och `footer.php` med `__DIR__ . '/../'`-prefix\n";
    $claudeMdContent .= "4. **Lägg till rutt** i `router.php`\n\n";
    $claudeMdContent .= "```php\n";
    $claudeMdContent .= "// Minsta struktur för ny sida i pages/:\n";
    $claudeMdContent .= "<?php include __DIR__ . '/../includes/admin-bar.php'; ?>\n";
    $claudeMdContent .= "<?php include __DIR__ . '/../includes/header.php'; ?>\n";
    $claudeMdContent .= "<main>\n";
    $claudeMdContent .= "    <!-- Innehåll -->\n";
    $claudeMdContent .= "</main>\n";
    $claudeMdContent .= "<?php include __DIR__ . '/../includes/footer.php'; ?>\n";
    $claudeMdContent .= "```\n\n";
    $claudeMdContent .= "### Publika sidor\n";
    $claudeMdContent .= "- `/` — Huvudsida (`index.php` i rot)\n";
    $claudeMdContent .= "- `/kontakt` — Kontaktformulär (`pages/kontakt.php`)\n";
    $claudeMdContent .= "- `/projekt` — Projekt-lista (`pages/projekt.php`)\n";
    $claudeMdContent .= "- `/projekt/{slug}` — Enskilt projekt (`pages/projekt-single.php`)\n\n";
    $claudeMdContent .= "### CMS-admin (kräver inloggning)\n";
    $claudeMdContent .= "- `/admin` — Logga in\n";
    $claudeMdContent .= "- `/dashboard` — Översikt\n";
    $claudeMdContent .= "- `/projects` — Hantera inlägg\n";
    if (file_put_contents(__DIR__ . '/CLAUDE.md', $claudeMdContent, LOCK_EX) === false) {
        $errors[] = 'Kunde inte skriva till: CLAUDE.md';
    }

    // 7. includes/fonts.php
    $fontsContent = "<?php\n// Genererad av Setup Wizard\n?>\n";
    $googleFonts = [];
    $hasCustomFont = !empty($data['custom_font_file']);

    foreach ([$data['font_heading'], $data['font_body']] as $font) {
        if ($font !== 'System UI' && $font !== 'Custom' && !in_array($font, $googleFonts)) {
            $googleFonts[] = $font;
        }
    }

    // Custom font @font-face
    if ($hasCustomFont) {
        $fontFile = $data['custom_font_file'];
        $fontName = $data['custom_font_name'] ?? 'Custom Font';
        $fontsContent .= "<style>\n";
        $fontsContent .= "@font-face {\n";
        $fontsContent .= "  font-family: 'Custom Font';\n";
        $fontsContent .= "  src: url('/assets/fonts/" . htmlspecialchars($fontFile) . "');\n";
        $fontsContent .= "  font-weight: 100 900;\n";
        $fontsContent .= "  font-display: swap;\n";
        $fontsContent .= "}\n";
        $fontsContent .= "</style>\n";
    }

    // Google Fonts
    if (!empty($googleFonts)) {
        $families = [];
        foreach ($googleFonts as $font) {
            $families[] = 'family=' . urlencode($font) . ':wght@400;500;600;700';
        }
        $url = 'https://fonts.googleapis.com/css2?' . implode('&', $families) . '&display=swap';
        $fontsContent .= "<link rel=\"preconnect\" href=\"https://fonts.googleapis.com\">\n";
        $fontsContent .= "<link rel=\"preconnect\" href=\"https://fonts.gstatic.com\" crossorigin>\n";
        $fontsContent .= "<link href=\"" . htmlspecialchars($url) . "\" rel=\"stylesheet\">\n";
    }

    if (empty($googleFonts) && !$hasCustomFont) {
        $fontsContent = "<?php\n// System UI - ingen extern font behövs\n";
    }

    if (file_put_contents(__DIR__ . '/includes/fonts.php', $fontsContent, LOCK_EX) === false) {
        $errors[] = 'Kunde inte skriva till: fonts.php';
    }

    // 8. Favicon (kopiera logo-dark som favicon om den finns)
    $logoDark = __DIR__ . '/assets/images/logo-dark.png';
    $faviconDest = __DIR__ . '/assets/images/favicon.png';
    if (file_exists($logoDark) && !file_exists($faviconDest)) {
        // Försök skapa en 32x32 favicon med GD
        if (function_exists('imagecreatefrompng')) {
            $src = @imagecreatefrompng($logoDark);
            if ($src) {
                $w = imagesx($src);
                $h = imagesy($src);
                $size = 32;
                $favicon = imagecreatetruecolor($size, $size);
                imagesavealpha($favicon, true);
                $transparent = imagecolorallocatealpha($favicon, 0, 0, 0, 127);
                imagefill($favicon, 0, 0, $transparent);
                // Fit within 32x32 keeping aspect ratio
                $ratio = min($size / $w, $size / $h);
                $newW = (int)round($w * $ratio);
                $newH = (int)round($h * $ratio);
                $x = (int)round(($size - $newW) / 2);
                $y = (int)round(($size - $newH) / 2);
                imagecopyresampled($favicon, $src, $x, $y, 0, 0, $newW, $newH, $w, $h);
                imagepng($favicon, $faviconDest);

                // Also create apple-touch-icon (180x180)
                $src2 = @imagecreatefrompng($logoDark);
                if ($src2) {
                    $appleSize = 180;
                    $apple = imagecreatetruecolor($appleSize, $appleSize);
                    imagesavealpha($apple, true);
                    $transparent2 = imagecolorallocatealpha($apple, 0, 0, 0, 127);
                    imagefill($apple, 0, 0, $transparent2);
                    $ratio2 = min($appleSize / $w, $appleSize / $h);
                    $newW2 = (int)round($w * $ratio2);
                    $newH2 = (int)round($h * $ratio2);
                    $x2 = (int)round(($appleSize - $newW2) / 2);
                    $y2 = (int)round(($appleSize - $newH2) / 2);
                    imagecopyresampled($apple, $src2, $x2, $y2, 0, 0, $newW2, $newH2, $w, $h);
                    imagepng($apple, __DIR__ . '/assets/images/apple-touch-icon.png');
                }
            }
        } else {
            // Fallback: kopiera logotypen direkt
            copy($logoDark, $faviconDest);
        }
    }

    // 9. includes/analytics.php (GA4 script)
    if (!empty($data['ga_id'])) {
        $gaContent = "<?php\n// Google Analytics 4 - Genererad av Setup Wizard\n";
        $gaContent .= "// Använder Google Consent Mode v2 (konfigureras i cookie-consent.php)\n?>\n";
        $gaContent .= "<script async src=\"https://www.googletagmanager.com/gtag/js?id=" . htmlspecialchars($data['ga_id']) . "\"></script>\n";
        $gaContent .= "<script <?php echo csp_nonce_attr(); ?>>\n";
        $gaContent .= "window.dataLayer = window.dataLayer || [];\n";
        $gaContent .= "function gtag(){dataLayer.push(arguments);}\n";
        $gaContent .= "gtag('js', new Date());\n";
        $gaContent .= "gtag('config', '" . htmlspecialchars($data['ga_id']) . "');\n";
        $gaContent .= "</script>\n";
        if (file_put_contents(__DIR__ . '/includes/analytics.php', $gaContent, LOCK_EX) === false) {
            $errors[] = 'Kunde inte skriva till: analytics.php';
        }
    }

    // 10. overrides.css (tom fil med header — för framtida AI-overrides)
    $overridesFile = __DIR__ . '/assets/css/overrides.css';
    if (!file_exists($overridesFile)) {
        $overridesContent = "/**\n";
        $overridesContent .= " * Design Overrides\n";
        $overridesContent .= " * Denna fil laddas SIST och vinner över allt annat.\n";
        $overridesContent .= " *\n";
        $overridesContent .= " * REGLER:\n";
        $overridesContent .= " * - Alla visuella ändringar som avviker från brand guiden skrivs HÄR\n";
        $overridesContent .= " * - Ändra ALDRIG variables.css eller components.css direkt\n";
        $overridesContent .= " * - Denna fil överlever omgenerering av setup-wizarden\n";
        $overridesContent .= " *\n";
        $overridesContent .= " * EXEMPEL:\n";
        $overridesContent .= " * .button--primary { border-radius: 0; background: linear-gradient(...); }\n";
        $overridesContent .= " * .card { box-shadow: none; border: 2px solid #000; }\n";
        $overridesContent .= " */\n";
        if (file_put_contents($overridesFile, $overridesContent, LOCK_EX) === false) {
            $errors[] = 'Kunde inte skriva till: overrides.css';
        }
    }

    return $errors;
}


/**
 * Generera enbart config.php (config-only mode)
 * Läser befintlig content.json för site-data, tar admin + SMTP från formuläret
 */
function generateConfigOnly(array $data): array {
    $errors = [];

    // Läs befintlig content.json
    $contentFile = __DIR__ . '/data/content.json';
    $siteName = 'Min Webbplats';
    $siteDescription = '';
    $contactEmail = '';
    $contactPhone = '';

    if (file_exists($contentFile)) {
        $content = json_decode(file_get_contents($contentFile), true);
        if ($content) {
            $siteName = $content['footer']['company_name'] ?? $siteName;
            $siteDescription = $content['home']['meta_description'] ?? $siteDescription;
            $contactEmail = $content['footer']['email'] ?? $contactEmail;
            $contactPhone = $content['footer']['phone'] ?? $contactPhone;
        }
    }

    // Auto-detect SITE_URL
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host = $_SERVER['HTTP_HOST'] ?? 'localhost';
    $siteUrl = $protocol . '://' . $host;

    // Auto-generera secrets
    $sessionSecret = bin2hex(random_bytes(32));
    $csrfSalt = bin2hex(random_bytes(32));
    $saToken = bin2hex(random_bytes(32));
    $passwordHash = password_hash($data['admin_password'], PASSWORD_BCRYPT);

    // Bygg config.php
    $configContent = "<?php\n";
    $configContent .= "/**\n * Konfiguration - Genererad av Setup Wizard (config-only)\n * " . date('Y-m-d H:i:s') . "\n */\n\n";
    $configContent .= "// Site\n";
    $configContent .= "define('SITE_URL', " . var_export($siteUrl, true) . ");\n";
    $configContent .= "define('SITE_NAME', " . var_export($siteName, true) . ");\n";
    $configContent .= "define('SITE_DESCRIPTION', " . var_export($siteDescription, true) . ");\n";
    $configContent .= "define('CONTACT_EMAIL', " . var_export($contactEmail, true) . ");\n";
    $configContent .= "define('CONTACT_PHONE', " . var_export($contactPhone, true) . ");\n\n";
    $configContent .= "// Admin\n";
    $configContent .= "define('ADMIN_USERNAME', " . var_export($data['admin_username'], true) . ");\n";
    $configContent .= "define('ADMIN_PASSWORD_HASH', " . var_export($passwordHash, true) . ");\n";
    if (!empty($data['admin_email'])) {
        $configContent .= "define('ADMIN_EMAIL', " . var_export($data['admin_email'], true) . ");\n";
    }
    $configContent .= "\n";
    // Agency super-admin
    $agencyUser = trim($data['agency_user'] ?? 'admin');
    $agencyPassHash = password_hash($data['agency_pass'] ?? bin2hex(random_bytes(16)), PASSWORD_BCRYPT);
    $configContent .= "// Agency super-admin\n";
    $configContent .= "define('AGENCY_USERNAME', " . var_export($agencyUser, true) . ");\n";
    $configContent .= "define('AGENCY_PASSWORD_HASH', " . var_export($agencyPassHash, true) . ");\n\n";
    $configContent .= "// Security\n";
    $configContent .= "define('SESSION_SECRET', " . var_export($sessionSecret, true) . ");\n";
    $configContent .= "define('CSRF_TOKEN_SALT', " . var_export($csrfSalt, true) . ");\n\n";

    if (!empty($data['smtp_host'])) {
        $configContent .= "// SMTP\n";
        $configContent .= "define('SMTP_HOST', " . var_export($data['smtp_host'], true) . ");\n";
        $configContent .= "define('SMTP_PORT', " . (int)$data['smtp_port'] . ");\n";
        $configContent .= "define('SMTP_ENCRYPTION', " . var_export($data['smtp_encryption'], true) . ");\n";
        $configContent .= "define('SMTP_USERNAME', " . var_export($data['smtp_username'], true) . ");\n";
        $configContent .= "define('SMTP_PASSWORD', " . var_export($data['smtp_password'], true) . ");\n\n";
    }

    // GitHub (om konfigurerat)
    if (!empty($data['github_repo']) && !empty($data['github_token'])) {
        $configContent .= "// GitHub (för automatisk push vid uppdatering)\n";
        $configContent .= "define('GITHUB_REPO', " . var_export($data['github_repo'], true) . ");\n";
        $configContent .= "define('GITHUB_TOKEN', " . var_export($data['github_token'], true) . ");\n\n";
    }

    $configContent .= "// Environment\n";
    $configContent .= "define('ENVIRONMENT', 'development');\n\n";

    // Preserve existing update URL and agency preset
    $existingUpdateUrl = 'https://raw.githubusercontent.com/agencidev/bosse-updates/main';
    $existingConfigPath = __DIR__ . '/config.php';
    if (file_exists($existingConfigPath)) {
        $existingConfig = file_get_contents($existingConfigPath);
        if (preg_match("/define\('AGENCI_UPDATE_URL',\s*'([^']*)'\)/", $existingConfig, $um)) {
            $existingUpdateUrl = $um[1];
        }
    }

    $configContent .= "// Agenci\n";
    $configContent .= "define('AGENCI_SUPER_ADMIN_TOKEN', " . var_export($saToken, true) . ");\n";
    $configContent .= "define('AGENCI_UPDATE_URL', '{$existingUpdateUrl}');\n";
    $configContent .= "define('AGENCI_UPDATE_KEY', '');\n\n";

    // API — use key from form, preserve existing, or generate new
    $apiKey = '';
    if (!empty($data['api_key']) && preg_match('/^[a-f0-9]{64}$/', $data['api_key'])) {
        $apiKey = $data['api_key'];
    }
    if (empty($apiKey)) {
        $existingConfigPath = __DIR__ . '/config.php';
        if (file_exists($existingConfigPath)) {
            $existingConfig = file_get_contents($existingConfigPath);
            if (preg_match("/define\('API_KEY',\s*'([a-f0-9]{64})'\)/", $existingConfig, $m)) {
                $apiKey = $m[1];
            }
        }
    }
    if (empty($apiKey)) {
        $apiKey = bin2hex(random_bytes(32));
    }
    $configContent .= "// API\n";
    $configContent .= "define('API_KEY', '{$apiKey}');\n";
    $configContent .= "define('API_RATE_LIMIT', 60);\n";
    $configContent .= "define('API_RATE_WINDOW', 60);\n";
    $configContent .= "define('API_CORS_ORIGINS', '*');\n";

    if (file_put_contents(__DIR__ . '/config.php', $configContent) === false) {
        $errors[] = 'Kunde inte skriva config.php';
    }

    // .site-url (committas till git — används av portalen för att visa domän)
    if (file_put_contents(__DIR__ . '/.site-url', rtrim($siteUrl, '/'), LOCK_EX) === false) {
        $errors[] = 'Kunde inte skriva till: .site-url';
    }

    return $errors;
}


/**
 * Bygg font-stack för CSS
 */
function buildFontStack(string $font): string {
    if ($font === 'System UI') {
        return "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
    }
    if ($font === 'Custom') {
        return "'Custom Font', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
    }
    return "'" . $font . "', system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif";
}

// Ladda sparad data för formulär
$saved = $_SESSION['setup_data'] ?? [];
?>
<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Setup Wizard - Konfigurera din webbplats</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'DM Sans', sans-serif;
            background-color: #033234;
            color: rgba(255,255,255,1.0);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 3rem 1.5rem;
        }

        .setup-container {
            width: 100%;
            max-width: 36rem;
        }

        .setup-header {
            text-align: center;
            margin-bottom: 2.5rem;
        }

        .setup-header h1 {
            font-size: 2.25rem;
            font-weight: bold;
            color: rgba(255,255,255,1.0);
            margin-bottom: 0.75rem;
        }

        .setup-header p {
            font-size: 1.125rem;
            color: rgba(255,255,255,0.50);
        }

        /* Progress Steps */
        .progress-steps {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 0;
            margin-bottom: 2.5rem;
        }

        .progress-step {
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .step-circle {
            width: 36px;
            height: 36px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
            font-size: 0.875rem;
            border: 2px solid rgba(255,255,255,0.10);
            color: rgba(255,255,255,0.50);
            background: rgba(255,255,255,0.05);
            transition: all 0.2s;
        }

        .step-circle.active {
            border-color: #379b83;
            background: #379b83;
            color: white;
        }

        .step-circle.completed {
            border-color: #10b981;
            background: #10b981;
            color: white;
        }

        .step-label {
            font-size: 0.8125rem;
            font-weight: 600;
            color: rgba(255,255,255,0.50);
            display: none;
        }

        @media (min-width: 640px) {
            .step-label { display: block; }
        }

        .step-line {
            width: 60px;
            height: 2px;
            background: rgba(255,255,255,0.10);
            margin: 0 0.75rem;
            transition: background 0.2s;
        }

        .step-line.completed {
            background: #10b981;
        }

        /* Card — matches CMS dashboard/support style */
        .setup-card {
            background: rgba(255,255,255,0.05);
            border-radius: 1.5rem;
            border: 1px solid rgba(255,255,255,0.10);
            padding: 2rem;
        }

        .setup-card h2 {
            font-size: 1.25rem;
            font-weight: bold;
            color: rgba(255,255,255,1.0);
            margin-bottom: 1.5rem;
        }

        /* Form — matches CMS admin.php / support.php */
        .form-group {
            margin-bottom: 1.5rem;
        }

        .form-group label {
            display: block;
            font-size: 0.875rem;
            font-weight: 600;
            color: rgba(255,255,255,1.0);
            margin-bottom: 0.5rem;
        }

        .form-group .hint {
            font-size: 0.75rem;
            color: rgba(255,255,255,0.50);
            margin-top: 0.375rem;
        }

        input[type="text"],
        input[type="email"],
        input[type="tel"],
        input[type="url"],
        input[type="password"],
        input[type="number"],
        textarea,
        select {
            width: 100%;
            padding: 0.875rem 1rem;
            border: 1px solid rgba(255,255,255,0.10);
            border-radius: 0.75rem;
            font-size: 1rem;
            font-family: inherit;
            background: rgba(255,255,255,0.05);
            color: rgba(255,255,255,1.0);
            outline: none;
            transition: all 0.2s;
        }

        input:focus,
        textarea:focus,
        select:focus {
            border-color: transparent;
            box-shadow: 0 0 0 2px #379b83;
        }

        textarea {
            min-height: 80px;
            resize: vertical;
        }

        input[type="color"] {
            width: 48px;
            height: 44px;
            padding: 2px;
            border: 1px solid rgba(255,255,255,0.10);
            border-radius: 0.75rem;
            cursor: pointer;
            background: rgba(255,255,255,0.05);
        }

        .color-group {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .color-group input[type="text"] {
            flex: 1;
        }

        /* Section divider */
        .section-divider {
            margin-top: 2rem;
            margin-bottom: 1rem;
            padding-top: 1.5rem;
            border-top: 1px solid rgba(255,255,255,0.10);
        }

        .section-divider h3 {
            font-size: 1rem;
            font-weight: bold;
            color: rgba(255,255,255,1.0);
            margin-bottom: 0.25rem;
        }

        .section-divider p {
            font-size: 0.8125rem;
            color: rgba(255,255,255,0.50);
            margin-bottom: 1.25rem;
        }

        /* File upload */
        .file-upload {
            border: 2px dashed rgba(255,255,255,0.10);
            border-radius: 0.75rem;
            padding: 1.25rem;
            text-align: center;
            cursor: pointer;
            transition: border-color 0.2s, background 0.2s;
            position: relative;
        }

        .file-upload:hover {
            border-color: #379b83;
            background: rgba(55,155,131,0.10);
        }

        .file-upload input[type="file"] {
            position: absolute;
            inset: 0;
            opacity: 0;
            cursor: pointer;
        }

        .file-upload-text {
            font-size: 0.875rem;
            color: rgba(255,255,255,0.50);
        }

        .file-upload-text strong {
            color: #379b83;
        }

        .logo-preview {
            max-height: 60px;
            max-width: 200px;
            margin-top: 0.75rem;
            display: none;
            border-radius: 0.25rem;
        }

        /* Preview card */
        .design-preview {
            border: 1px solid rgba(255,255,255,0.10);
            border-radius: 1rem;
            padding: 1.5rem;
            margin-top: 1.5rem;
        }

        .design-preview h3 {
            font-size: 0.875rem;
            font-weight: 600;
            color: rgba(255,255,255,0.50);
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 1rem;
        }

        .preview-colors {
            display: flex;
            gap: 0.75rem;
            margin-bottom: 1rem;
        }

        .preview-swatch {
            width: 48px;
            height: 48px;
            border-radius: 0.75rem;
            border: 1px solid rgba(0,0,0,0.1);
        }

        .preview-text h4 {
            font-size: 1.125rem;
            margin-bottom: 0.25rem;
        }

        .preview-text p {
            font-size: 0.875rem;
            color: rgba(255,255,255,0.50);
        }

        .preview-button {
            display: inline-block;
            padding: 0.5rem 1.25rem;
            border-radius: 9999px;
            color: white;
            font-size: 0.875rem;
            font-weight: 600;
            margin-top: 0.75rem;
            border: none;
        }

        /* Password strength */
        .password-strength {
            height: 4px;
            border-radius: 2px;
            background: rgba(255,255,255,0.10);
            margin-top: 0.5rem;
            overflow: hidden;
        }

        .password-strength-bar {
            height: 100%;
            border-radius: 2px;
            transition: width 0.3s, background 0.3s;
            width: 0;
        }

        .password-strength-text {
            font-size: 0.75rem;
            margin-top: 0.25rem;
            color: rgba(255,255,255,0.50);
        }

        /* Buttons — matches CMS button style */
        .form-actions {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 2rem;
            gap: 1rem;
        }

        .btn {
            padding: 0.875rem 1.75rem;
            border-radius: 9999px;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            border: none;
            transition: all 0.2s;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            text-decoration: none;
        }

        .btn-primary {
            background: #379b83;
            color: white;
        }

        .btn-primary:hover {
            background: #2e8570;
        }

        .btn-secondary {
            background: none;
            color: rgba(255,255,255,0.50);
            border: 1px solid rgba(255,255,255,0.10);
        }

        .btn-secondary:hover {
            background: rgba(255,255,255,0.05);
            color: rgba(255,255,255,0.75);
        }

        .btn-success {
            background: #10b981;
            color: white;
        }

        .btn-success:hover {
            background: #059669;
        }

        /* Errors */
        .error-list {
            background: rgba(239,68,68,0.10);
            border: 1px solid rgba(239,68,68,0.30);
            border-radius: 0.75rem;
            padding: 1rem 1.25rem;
            margin-bottom: 1.5rem;
            list-style: none;
        }

        .error-list li {
            font-size: 0.875rem;
            color: #fca5a5;
            padding: 0.125rem 0;
        }

        /* Writable errors */
        .writable-error {
            background: rgba(245,158,11,0.10);
            border: 1px solid rgba(245,158,11,0.30);
            border-radius: 0.75rem;
            padding: 1rem 1.25rem;
            margin-bottom: 1.5rem;
            font-size: 0.875rem;
            color: #fcd34d;
        }

        .writable-error code {
            background: rgba(0,0,0,0.05);
            padding: 0.125rem 0.375rem;
            border-radius: 0.25rem;
            font-size: 0.8125rem;
        }

        /* Complete page */
        .complete-list {
            list-style: none;
            padding: 0;
        }

        .complete-list li {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem 0;
            font-size: 0.9375rem;
            border-bottom: 1px solid rgba(255,255,255,0.05);
        }

        .complete-list li:last-child {
            border-bottom: none;
        }

        .check-icon {
            width: 24px;
            height: 24px;
            background: #10b981;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            flex-shrink: 0;
            color: white;
            font-size: 0.75rem;
        }

        .complete-actions {
            display: flex;
            gap: 1rem;
            margin-top: 2rem;
        }

        .complete-actions .btn {
            flex: 1;
            justify-content: center;
        }

        /* Row layout */
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }

        /* Agenci badge */
        .agenci-badge {
            position: fixed;
            bottom: 1.5rem;
            left: 1.5rem;
            z-index: 9999;
        }
        .agenci-badge a {
            display: flex;
            align-items: center;
            gap: 0.5rem;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.10);
            padding: 0.5rem 1rem;
            border-radius: 9999px;
            text-decoration: none;
            transition: all 0.2s;
            font-size: 0.875rem;
            color: rgba(255,255,255,0.65);
            font-weight: 600;
        }
        .agenci-badge a:hover {
            transform: translateY(-2px);
        }

        @media (max-width: 480px) {
            .form-row { grid-template-columns: 1fr; }
            .form-actions { flex-direction: column-reverse; }
            .form-actions .btn { width: 100%; justify-content: center; }
            .complete-actions { flex-direction: column; }
        }

        .password-wrapper {
            position: relative;
        }
        .password-wrapper input {
            padding-right: 2.75rem;
        }
        .password-toggle {
            position: absolute;
            right: 0.625rem;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            cursor: pointer;
            color: rgba(255,255,255,0.4);
            padding: 0.25rem;
            display: flex;
            align-items: center;
            transition: color 0.2s;
        }
        .password-toggle:hover {
            color: rgba(255,255,255,0.7);
        }
    </style>
</head>
<body>
    <div class="setup-container">
        <div class="setup-header">
            <?php if ($configOnlyMode && $step !== 4): ?>
            <h1>Serverkonfiguration</h1>
            <p>Design och innehåll finns redan — ange admin-inlogg och SMTP.</p>
            <?php else: ?>
            <h1>Välkommen! 👋</h1>
            <p>Konfigurera din webbplats i tre enkla steg</p>
            <?php endif; ?>
        </div>

        <?php if ($step <= 3 && !$configOnlyMode): ?>
        <!-- Progress Steps -->
        <div class="progress-steps">
            <div class="progress-step">
                <div class="step-circle <?php echo $step === 1 ? 'active' : ($step > 1 ? 'completed' : ''); ?>">
                    <?php echo $step > 1 ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>' : '1'; ?>
                </div>
                <span class="step-label">Företag</span>
            </div>
            <div class="step-line <?php echo $step > 1 ? 'completed' : ''; ?>"></div>
            <div class="progress-step">
                <div class="step-circle <?php echo $step === 2 ? 'active' : ($step > 2 ? 'completed' : ''); ?>">
                    <?php echo $step > 2 ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>' : '2'; ?>
                </div>
                <span class="step-label">Design</span>
            </div>
            <div class="step-line <?php echo $step > 2 ? 'completed' : ''; ?>"></div>
            <div class="progress-step">
                <div class="step-circle <?php echo $step === 3 ? 'active' : ''; ?>">3</div>
                <span class="step-label">Admin</span>
            </div>
        </div>
        <?php endif; ?>

        <?php if (!empty($writableErrors) && $step <= 3): ?>
        <div class="writable-error">
            <strong>Skrivbehörigheter saknas!</strong> Följande mappar/filer är inte skrivbara:
            <?php foreach ($writableErrors as $path): ?>
                <br><code><?php echo htmlspecialchars($path); ?></code>
            <?php endforeach; ?>
            <br><br>Kör: <code>chmod -R 755 <?php echo htmlspecialchars(__DIR__); ?></code>
        </div>
        <?php endif; ?>

        <?php if (!empty($errors)): ?>
        <ul class="error-list">
            <?php foreach ($errors as $error): ?>
                <li><?php echo htmlspecialchars($error); ?></li>
            <?php endforeach; ?>
        </ul>
        <?php endif; ?>

        <?php if ($configOnlyMode && $step !== 4): ?>
        <!-- CONFIG-ONLY MODE: Bara admin + SMTP -->
        <div class="setup-card">
            <h2>Admin-konto</h2>
            <form method="post" action="/setup" id="config-only-form">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['setup_csrf']); ?>">

                <div class="form-group">
                    <label for="admin_username">Användarnamn *</label>
                    <input type="text" id="admin_username" name="admin_username" required minlength="3"
                           placeholder="admin" autocomplete="username">
                    <div class="hint">Minst 3 tecken. Undvik "admin" för bättre säkerhet.</div>
                </div>

                <div class="form-group">
                    <label for="admin_email">E-postadress (för lösenordsåterställning)</label>
                    <input type="email" id="admin_email" name="admin_email"
                           placeholder="kund@foretag.se">
                    <div class="hint">Används för att återställa lösenordet via e-post.</div>
                </div>

                <div class="form-group">
                    <label for="admin_password">Lösenord *</label>
                    <div class="password-wrapper">
                        <input type="password" id="admin_password" name="admin_password" required minlength="8"
                               placeholder="Minst 8 tecken" autocomplete="new-password">
                        <button type="button" class="password-toggle" data-target="admin_password" aria-label="Visa lösenord">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                        </button>
                    </div>
                    <div class="password-strength">
                        <div class="password-strength-bar" id="strength-bar"></div>
                    </div>
                    <div class="password-strength-text" id="strength-text"></div>
                </div>

                <div class="form-group">
                    <label for="admin_password_confirm">Bekräfta lösenord *</label>
                    <div class="password-wrapper">
                        <input type="password" id="admin_password_confirm" name="admin_password_confirm" required minlength="8"
                               placeholder="Upprepa lösenord" autocomplete="new-password">
                        <button type="button" class="password-toggle" data-target="admin_password_confirm" aria-label="Visa lösenord">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                        </button>
                    </div>
                </div>

                <div class="section-divider">
                    <h3>Super-admin (byrå)</h3>
                    <p>Valfritt — används av byrån för att hantera sajten.</p>
                </div>

                <div class="form-group">
                    <label for="agency_user">Super-admin användarnamn</label>
                    <input type="text" id="agency_user" name="agency_user"
                           placeholder="admin" autocomplete="off">
                    <div class="hint">Används av byrån för att hantera sajten. Standard: "admin".</div>
                </div>

                <div class="form-group">
                    <label for="agency_pass">Super-admin lösenord</label>
                    <div class="password-wrapper">
                        <input type="password" id="agency_pass" name="agency_pass" minlength="8"
                               placeholder="Minst 8 tecken" autocomplete="new-password">
                        <button type="button" class="password-toggle" data-target="agency_pass" aria-label="Visa lösenord">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                        </button>
                    </div>
                    <div class="hint">Minst 8 tecken. Om tomt genereras ett slumpmässigt lösenord.</div>
                </div>

                <div class="section-divider">
                    <h3>E-post &amp; SMTP</h3>
                    <p>Valfritt — behövs för kontaktformulär och support-mail.</p>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="smtp_host">SMTP-server</label>
                        <input type="text" id="smtp_host" name="smtp_host"
                               placeholder="smtp.example.com">
                    </div>
                    <div class="form-group">
                        <label for="smtp_port">Port</label>
                        <input type="number" id="smtp_port" name="smtp_port" min="1" max="65535"
                               value="465" placeholder="465">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="smtp_encryption">Kryptering</label>
                        <select id="smtp_encryption" name="smtp_encryption">
                            <option value="ssl" selected>SSL (port 465)</option>
                            <option value="tls">STARTTLS (port 587)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="smtp_username">SMTP-användarnamn</label>
                        <input type="email" id="smtp_username" name="smtp_username"
                               placeholder="user@example.com">
                    </div>
                </div>

                <div class="form-group">
                    <label for="smtp_password">SMTP-lösenord</label>
                    <input type="password" id="smtp_password" name="smtp_password"
                           placeholder="SMTP-lösenord" autocomplete="new-password">
                </div>

                <div class="section-divider">
                    <h3>GitHub</h3>
                    <p>Valfritt — behövs för att uppdateringar ska pushas tillbaka till repot.</p>
                </div>

                <div class="form-group">
                    <label for="github_repo">Repository (owner/repo)</label>
                    <input type="text" id="github_repo" name="github_repo"
                           placeholder="peysdev/kundnamn">
                </div>

                <div class="form-group">
                    <label for="github_token">Personal Access Token</label>
                    <input type="password" id="github_token" name="github_token"
                           placeholder="ghp_xxxx" autocomplete="new-password">
                    <div class="hint">Samma token kan användas för alla projekt. Skapa en klassisk PAT med "repo"-scope via GitHub &rarr; Settings &rarr; Developer settings &rarr; Personal access tokens (classic).</div>
                </div>

                <div class="section-divider">
                    <h3>API</h3>
                    <p>Generera en nyckel för att använda REST-API:t. Nyckeln sparas i config.php.</p>
                </div>

                <div class="form-group">
                    <label>API-nyckel</label>
                    <div style="display:flex;align-items:center;gap:0.5rem;">
                        <input type="text" id="api_key_field" name="api_key" readonly
                               placeholder="Klicka Generera för att skapa en nyckel"
                               style="flex:1;font-family:monospace;font-size:0.8125rem;">
                        <button type="button" id="btn-generate-api-key" class="btn btn-primary" style="white-space:nowrap;">Generera</button>
                        <button type="button" id="btn-copy-api-key-setup" class="btn" style="white-space:nowrap;display:none;">Kopiera</button>
                    </div>
                    <div class="hint">64-teckens hex-nyckel. Kopiera och spara den — den visas även i Super Admin efter setup.</div>
                </div>

                <div class="form-actions">
                    <span></span>
                    <button type="submit" class="btn btn-primary">Slutför</button>
                </div>
            </form>
        </div>

        <?php elseif ($step === 1): ?>
        <!-- STEG 1: Företagsinformation -->
        <div class="setup-card">
            <h2>Företagsinformation</h2>
            <form method="post" action="/setup?step=1" id="step1-form">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['setup_csrf']); ?>">
                <input type="hidden" name="step" value="1">

                <div class="section-divider" style="margin-top:0;padding-top:0;">
                    <h3>Byrå</h3>
                    <p>Välj vilken byrå som driver sajten — styr logotyper, footer och CMS-branding.</p>
                </div>

                <div class="form-group">
                    <label for="agency_preset">Byrå *</label>
                    <select id="agency_preset" name="agency_preset">
                        <option value="peys" <?php echo ($saved['agency_preset'] ?? 'peys') === 'peys' ? 'selected' : ''; ?>>PEYS</option>
                        <option value="grw" <?php echo ($saved['agency_preset'] ?? 'peys') === 'grw' ? 'selected' : ''; ?>>GRW Media AB</option>
                    </select>
                </div>

                <div class="section-divider">
                    <h3>Företag</h3>
                </div>

                <div class="form-group">
                    <label for="site_name">Företagsnamn *</label>
                    <input type="text" id="site_name" name="site_name" required
                           value="<?php echo htmlspecialchars($saved['site_name'] ?? ''); ?>"
                           placeholder="Mitt Företag AB">
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="contact_email">E-postadress *</label>
                        <input type="email" id="contact_email" name="contact_email" required
                               value="<?php echo htmlspecialchars($saved['contact_email'] ?? ''); ?>"
                               placeholder="info@example.com">
                    </div>
                    <div class="form-group">
                        <label for="contact_phone">Telefon</label>
                        <input type="tel" id="contact_phone" name="contact_phone"
                               value="<?php echo htmlspecialchars($saved['contact_phone'] ?? ''); ?>"
                               placeholder="+46 70 000 00 00">
                    </div>
                </div>

                <div class="form-group">
                    <label for="site_url">Webbadress *</label>
                    <input type="url" id="site_url" name="site_url" required
                           value="<?php echo htmlspecialchars($saved['site_url'] ?? 'http://localhost:8000'); ?>"
                           placeholder="https://example.com">
                    <div class="hint">Ändra till din riktiga domän vid produktion</div>
                </div>

                <div class="form-group">
                    <label for="site_description">Beskrivning *</label>
                    <textarea id="site_description" name="site_description" required
                              placeholder="Kort beskrivning av företaget och vad ni gör"><?php echo htmlspecialchars($saved['site_description'] ?? ''); ?></textarea>
                </div>

                <div class="section-divider">
                    <h3>E-post &amp; SMTP</h3>
                    <p>Valfritt — behövs för kontaktformulär och support-mail.</p>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="smtp_host">SMTP-server</label>
                        <input type="text" id="smtp_host" name="smtp_host"
                               value="<?php echo htmlspecialchars($saved['smtp_host'] ?? ''); ?>"
                               placeholder="smtp.example.com">
                    </div>
                    <div class="form-group">
                        <label for="smtp_port">Port</label>
                        <input type="number" id="smtp_port" name="smtp_port" min="1" max="65535"
                               value="<?php echo htmlspecialchars($saved['smtp_port'] ?? '465'); ?>"
                               placeholder="465">
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="smtp_encryption">Kryptering</label>
                        <select id="smtp_encryption" name="smtp_encryption">
                            <option value="ssl" <?php echo ($saved['smtp_encryption'] ?? 'ssl') === 'ssl' ? 'selected' : ''; ?>>SSL (port 465)</option>
                            <option value="tls" <?php echo ($saved['smtp_encryption'] ?? 'ssl') === 'tls' ? 'selected' : ''; ?>>STARTTLS (port 587)</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="smtp_username">SMTP-användarnamn</label>
                        <input type="email" id="smtp_username" name="smtp_username"
                               value="<?php echo htmlspecialchars($saved['smtp_username'] ?? ''); ?>"
                               placeholder="user@example.com">
                    </div>
                </div>

                <div class="form-group">
                    <label for="smtp_password">SMTP-lösenord</label>
                    <input type="password" id="smtp_password" name="smtp_password"
                           value="<?php echo htmlspecialchars($saved['smtp_password'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                           placeholder="SMTP-lösenord" autocomplete="new-password">
                    <div class="hint">Ange lösenord för SMTP-servern. Lämna tomt om du inte vill använda SMTP-mail.</div>
                </div>

                <div class="section-divider">
                    <h3>GitHub</h3>
                    <p>Valfritt — behövs för att uppdateringar ska pushas tillbaka till repot.</p>
                </div>

                <div class="form-group">
                    <label for="github_repo">Repository (owner/repo)</label>
                    <input type="text" id="github_repo" name="github_repo"
                           value="<?php echo htmlspecialchars($saved['github_repo'] ?? ''); ?>"
                           placeholder="peysdev/kundnamn">
                </div>

                <div class="form-group">
                    <label for="github_token">Personal Access Token</label>
                    <input type="password" id="github_token" name="github_token"
                           value="<?php echo htmlspecialchars($saved['github_token'] ?? '', ENT_QUOTES, 'UTF-8'); ?>"
                           placeholder="ghp_xxxx" autocomplete="new-password">
                    <div class="hint">Samma token kan användas för alla projekt. Skapa en klassisk PAT med "repo"-scope via GitHub &rarr; Settings &rarr; Developer settings &rarr; Personal access tokens (classic).</div>
                </div>

                <div class="section-divider">
                    <h3>Google Analytics</h3>
                    <p>Valfritt — kräver samtycke via cookie-bannern (Consent Mode v2).</p>
                </div>

                <div class="form-group">
                    <label>Har du Google Analytics?</label>
                    <div style="display: flex; gap: 1rem; margin: 0.5rem 0;">
                        <label style="display:flex;align-items:center;gap:0.375rem;cursor:pointer;">
                            <input type="radio" name="has_analytics" value="yes"
                                   <?php echo !empty($saved['ga_id']) ? 'checked' : ''; ?>> Ja
                        </label>
                        <label style="display:flex;align-items:center;gap:0.375rem;cursor:pointer;">
                            <input type="radio" name="has_analytics" value="no"
                                   <?php echo empty($saved['ga_id']) ? 'checked' : ''; ?>> Nej
                        </label>
                    </div>
                </div>
                <div id="ga-id-group" style="display: <?php echo !empty($saved['ga_id']) ? 'block' : 'none'; ?>;">
                    <div class="form-group">
                        <label for="ga_id">Measurement ID</label>
                        <input type="text" id="ga_id" name="ga_id"
                               value="<?php echo htmlspecialchars($saved['ga_id'] ?? ''); ?>"
                               placeholder="G-XXXXXXXXXX">
                        <div class="hint">Hittas i Google Analytics &rarr; Admin &rarr; Data Streams</div>
                    </div>
                </div>

                <div class="section-divider">
                    <h3>Sociala medier</h3>
                    <p>Valfritt — visas i footer och används i schema.org SEO.</p>
                </div>

                <div class="form-group">
                    <label for="social_facebook">Facebook</label>
                    <input type="url" id="social_facebook" name="social_facebook"
                           value="<?php echo htmlspecialchars($saved['social_facebook'] ?? ''); ?>"
                           placeholder="https://facebook.com/foretagsnamn">
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="social_instagram">Instagram</label>
                        <input type="url" id="social_instagram" name="social_instagram"
                               value="<?php echo htmlspecialchars($saved['social_instagram'] ?? ''); ?>"
                               placeholder="https://instagram.com/foretagsnamn">
                    </div>
                    <div class="form-group">
                        <label for="social_linkedin">LinkedIn</label>
                        <input type="url" id="social_linkedin" name="social_linkedin"
                               value="<?php echo htmlspecialchars($saved['social_linkedin'] ?? ''); ?>"
                               placeholder="https://linkedin.com/company/foretagsnamn">
                    </div>
                </div>

                <div class="section-divider">
                    <h3>Öppettider</h3>
                    <p>Valfritt — visas i footer och schema.org.</p>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="hours_weekdays">Vardagar (mån-fre)</label>
                        <input type="text" id="hours_weekdays" name="hours_weekdays"
                               value="<?php echo htmlspecialchars($saved['hours_weekdays'] ?? ''); ?>"
                               placeholder="08:00 - 17:00">
                    </div>
                    <div class="form-group">
                        <label for="hours_weekends">Helger (lör-sön)</label>
                        <input type="text" id="hours_weekends" name="hours_weekends"
                               value="<?php echo htmlspecialchars($saved['hours_weekends'] ?? ''); ?>"
                               placeholder="Stängt">
                    </div>
                </div>

                <div class="form-actions">
                    <span></span>
                    <button type="submit" class="btn btn-primary">Nästa &rarr;</button>
                </div>
            </form>
        </div>

        <?php elseif ($step === 2): ?>
        <!-- STEG 2: Design & Varumärke -->
        <div class="setup-card">
            <h2>Design &amp; Varumärke</h2>
            <form method="post" action="/setup?step=2" enctype="multipart/form-data" id="step2-form">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['setup_csrf']); ?>">
                <input type="hidden" name="step" value="2">

                <div class="form-row">
                    <div class="form-group">
                        <label>Ladda upp mörk logotyp</label>
                        <p class="hint" style="margin-bottom: 0.5rem;">Mörk logo för ljusa bakgrunder (header)</p>
                        <div class="file-upload" id="upload-dark">
                            <input type="file" name="logo_dark" accept=".png,.jpg,.jpeg,.svg,.webp"
                                   onchange="previewLogo(this, 'preview-dark')">
                            <div class="file-upload-text">
                                <strong>Välj fil</strong> eller dra hit
                                <br><small>PNG, JPG, SVG, WebP (max 5MB)</small>
                            </div>
                            <img class="logo-preview" id="preview-dark" alt="Logo förhandsgranskning">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Ladda upp ljus logotyp</label>
                        <p class="hint" style="margin-bottom: 0.5rem;">Ljus/vit logo för mörka bakgrunder (footer)</p>
                        <div class="file-upload" id="upload-light">
                            <input type="file" name="logo_light" accept=".png,.jpg,.jpeg,.svg,.webp"
                                   onchange="previewLogo(this, 'preview-light')">
                            <div class="file-upload-text">
                                <strong>Välj fil</strong> eller dra hit
                                <br><small>PNG, JPG, SVG, WebP (max 5MB)</small>
                            </div>
                            <img class="logo-preview" id="preview-light" alt="Logo förhandsgranskning">
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label>Favicon (valfritt)</label>
                    <p class="hint" style="margin-bottom: 0.5rem;">Liten ikon som visas i webbläsarfliken. Om ingen laddas upp används logon.</p>
                    <div class="file-upload" id="upload-favicon">
                        <input type="file" name="favicon" accept=".png,.ico,.svg"
                               onchange="previewFavicon(this)">
                        <div class="file-upload-text">
                            <strong>Välj fil</strong> eller dra hit
                            <br><small>PNG, ICO, SVG (32x32 rekommenderat)</small>
                        </div>
                        <img class="logo-preview" id="preview-favicon" alt="Favicon förhandsgranskning" style="max-height: 32px;">
                    </div>
                </div>

                <div class="form-row" style="grid-template-columns: 1fr 1fr 1fr;">
                    <div class="form-group">
                        <label for="primary_color">Primärfärg</label>
                        <div class="color-group">
                            <input type="color" id="primary_color" name="primary_color"
                                   value="<?php echo htmlspecialchars($saved['primary_color'] ?? '#8b5cf6'); ?>"
                                   onchange="updateColorText(this, 'primary_text'); updatePreview();">
                            <input type="text" id="primary_text"
                                   value="<?php echo htmlspecialchars($saved['primary_color'] ?? '#8b5cf6'); ?>"
                                   onchange="document.getElementById('primary_color').value = this.value; updatePreview();"
                                   pattern="#[0-9a-fA-F]{6}" maxlength="7">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="secondary_color">Sekundärfärg</label>
                        <div class="color-group">
                            <input type="color" id="secondary_color" name="secondary_color"
                                   value="<?php echo htmlspecialchars($saved['secondary_color'] ?? '#379b83'); ?>"
                                   onchange="updateColorText(this, 'secondary_text'); updatePreview();">
                            <input type="text" id="secondary_text"
                                   value="<?php echo htmlspecialchars($saved['secondary_color'] ?? '#379b83'); ?>"
                                   onchange="document.getElementById('secondary_color').value = this.value; updatePreview();"
                                   pattern="#[0-9a-fA-F]{6}" maxlength="7">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="accent_color">Accentfärg</label>
                        <div class="color-group">
                            <input type="color" id="accent_color" name="accent_color"
                                   value="<?php echo htmlspecialchars($saved['accent_color'] ?? '#379b83'); ?>"
                                   onchange="updateColorText(this, 'accent_text'); updatePreview();">
                            <input type="text" id="accent_text"
                                   value="<?php echo htmlspecialchars($saved['accent_color'] ?? '#379b83'); ?>"
                                   onchange="document.getElementById('accent_color').value = this.value; updatePreview();"
                                   pattern="#[0-9a-fA-F]{6}" maxlength="7">
                        </div>
                    </div>
                </div>

                <?php
                // Comprehensive Google Fonts list organized by category
                $fontCategories = [
                    'System' => ['System UI'],
                    'Sans-serif (Modern)' => ['Inter', 'Roboto', 'Open Sans', 'Lato', 'Montserrat', 'Poppins', 'Nunito', 'Raleway', 'Ubuntu', 'Rubik', 'Work Sans', 'DM Sans', 'Manrope', 'Plus Jakarta Sans', 'Outfit', 'Figtree', 'Sora', 'Space Grotesk', 'Albert Sans', 'Be Vietnam Pro', 'Lexend'],
                    'Sans-serif (Classic)' => ['Barlow', 'Mulish', 'Jost', 'Karla', 'Quicksand', 'Cabin', 'Archivo', 'Heebo', 'Fira Sans', 'Source Sans 3', 'Noto Sans', 'PT Sans', 'Asap', 'Exo 2', 'Overpass'],
                    'Serif (Elegant)' => ['Playfair Display', 'Lora', 'Merriweather', 'Libre Baskerville', 'Crimson Text', 'EB Garamond', 'Cormorant Garamond', 'Spectral', 'Fraunces', 'DM Serif Display'],
                    'Serif (Classic)' => ['PT Serif', 'Source Serif 4', 'Bitter', 'Libre Caslon Text', 'Bodoni Moda', 'Noto Serif', 'Vollkorn', 'Josefin Slab', 'Cardo', 'Old Standard TT', 'Literata', 'Newsreader'],
                    'Display' => ['Oswald', 'Bebas Neue', 'Anton', 'Righteous', 'Abril Fatface', 'Alfa Slab One', 'Staatliches', 'Russo One'],
                    'Handwriting' => ['Pacifico', 'Lobster', 'Permanent Marker', 'Satisfy', 'Dancing Script', 'Great Vibes', 'Caveat', 'Kalam'],
                    'Monospace' => ['Fira Code', 'JetBrains Mono', 'Source Code Pro', 'IBM Plex Mono', 'Space Mono', 'Roboto Mono', 'Ubuntu Mono', 'Inconsolata'],
                    'Scandinavian' => ['Rethink Sans', 'Instrument Sans', 'Onest', 'General Sans'],
                ];
                $selectedHeading = $saved['font_heading'] ?? 'System UI';
                $selectedBody = $saved['font_body'] ?? 'System UI';
                ?>
                <div class="form-row">
                    <div class="form-group">
                        <label for="font_heading">Rubrik-typsnitt</label>
                        <select id="font_heading" name="font_heading" onchange="updateFontPreview()" style="max-height: 300px;">
                            <?php foreach ($fontCategories as $category => $fonts): ?>
                            <optgroup label="<?php echo $category; ?>">
                                <?php foreach ($fonts as $f): ?>
                                <option value="<?php echo $f; ?>" <?php echo $f === $selectedHeading ? 'selected' : ''; ?>><?php echo $f; ?></option>
                                <?php endforeach; ?>
                            </optgroup>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="font_body">Brödtext-typsnitt</label>
                        <select id="font_body" name="font_body" onchange="updateFontPreview()" style="max-height: 300px;">
                            <?php foreach ($fontCategories as $category => $fonts): ?>
                            <optgroup label="<?php echo $category; ?>">
                                <?php foreach ($fonts as $f): ?>
                                <option value="<?php echo $f; ?>" <?php echo $f === $selectedBody ? 'selected' : ''; ?>><?php echo $f; ?></option>
                                <?php endforeach; ?>
                            </optgroup>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- Custom Font Upload (Optional) -->
                <div class="form-group" style="margin-top: 1rem;">
                    <label>Egen font (valfritt)</label>
                    <p class="hint" style="margin-bottom: 0.5rem;">Ladda upp din egen font-fil (.woff2 eller .woff). Den kommer användas som "Custom" i dropdownen ovan.</p>
                    <div class="file-upload" id="upload-custom-font">
                        <input type="file" name="custom_font" accept=".woff2,.woff,.ttf,.otf"
                               onchange="showFontFileName(this)">
                        <div class="file-upload-text">
                            <strong>Välj font-fil</strong> eller dra hit
                            <br><small>WOFF2, WOFF, TTF, OTF</small>
                        </div>
                        <span id="custom-font-name" style="display: none; font-size: 0.8125rem; margin-top: 0.5rem; color: #16a34a;"></span>
                    </div>
                </div>

                <div class="section-divider">
                    <h3>Form &amp; Stil</h3>
                    <p>Styr grundkänslan — kan alltid justeras av AI senare.</p>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="border_radius">Hörnradie</label>
                        <select id="border_radius" name="border_radius" onchange="updatePreview()">
                            <?php
                            $radiusOptions = ['sharp' => 'Skarp (2px)', 'rounded' => 'Rundad (8px)', 'soft' => 'Mjuk (16px)', 'pill' => 'Pill (helrund)'];
                            $selectedRadius = $saved['border_radius'] ?? 'rounded';
                            foreach ($radiusOptions as $val => $label):
                            ?>
                            <option value="<?php echo $val; ?>" <?php echo $val === $selectedRadius ? 'selected' : ''; ?>><?php echo $label; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="button_style">Knappstil</label>
                        <select id="button_style" name="button_style" onchange="updatePreview()">
                            <?php
                            $btnOptions = ['filled' => 'Fylld', 'outline' => 'Outline', 'ghost' => 'Ghost'];
                            $selectedBtn = $saved['button_style'] ?? 'filled';
                            foreach ($btnOptions as $val => $label):
                            ?>
                            <option value="<?php echo $val; ?>" <?php echo $val === $selectedBtn ? 'selected' : ''; ?>><?php echo $label; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="tonality">Tonalitet</label>
                        <select id="tonality" name="tonality">
                            <?php
                            $toneOptions = ['professional' => 'Professionell', 'playful' => 'Lekfull', 'minimal' => 'Minimalistisk'];
                            $selectedTone = $saved['tonality'] ?? 'professional';
                            foreach ($toneOptions as $val => $label):
                            ?>
                            <option value="<?php echo $val; ?>" <?php echo $val === $selectedTone ? 'selected' : ''; ?>><?php echo $label; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="layout_width">Layout-bredd</label>
                        <select id="layout_width" name="layout_width">
                            <?php
                            $widthOptions = ['narrow' => 'Smal (960px)', 'normal' => 'Normal (1200px)', 'wide' => 'Bred (1440px)'];
                            $selectedWidth = $saved['layout_width'] ?? 'normal';
                            foreach ($widthOptions as $val => $label):
                            ?>
                            <option value="<?php echo $val; ?>" <?php echo $val === $selectedWidth ? 'selected' : ''; ?>><?php echo $label; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="form-row">
                    <div class="form-group">
                        <label for="bg_pattern">Bakgrundsmönster</label>
                        <select id="bg_pattern" name="bg_pattern">
                            <?php
                            $bgOptions = ['solid' => 'Solid (enfärgad)', 'gradient' => 'Gradient (tonad)', 'subtle' => 'Subtil (mönster)'];
                            $selectedBg = $saved['bg_pattern'] ?? 'solid';
                            foreach ($bgOptions as $val => $label):
                            ?>
                            <option value="<?php echo $val; ?>" <?php echo $val === $selectedBg ? 'selected' : ''; ?>><?php echo $label; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="spacing_feel">Spacing-känsla</label>
                        <select id="spacing_feel" name="spacing_feel">
                            <?php
                            $spacingOptions = ['compact' => 'Kompakt (tätare)', 'normal' => 'Normal (standard)', 'airy' => 'Luftig (rymligare)'];
                            $selectedSpacing = $saved['spacing_feel'] ?? 'normal';
                            foreach ($spacingOptions as $val => $label):
                            ?>
                            <option value="<?php echo $val; ?>" <?php echo $val === $selectedSpacing ? 'selected' : ''; ?>><?php echo $label; ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- Design preview -->
                <div class="design-preview" id="design-preview">
                    <h3>Förhandsgranskning</h3>
                    <div class="preview-colors">
                        <div class="preview-swatch" id="swatch-primary" style="background: #8b5cf6;"></div>
                        <div class="preview-swatch" id="swatch-secondary" style="background: #379b83;"></div>
                        <div class="preview-swatch" id="swatch-accent" style="background: #379b83;"></div>
                    </div>
                    <div class="preview-text">
                        <h4 id="preview-heading" style="font-family: system-ui, sans-serif;">Rubrik-exempel</h4>
                        <p id="preview-body" style="font-family: system-ui, sans-serif;">Brödtext-exempel med valt typsnitt.</p>
                    </div>
                    <button type="button" class="preview-button" id="preview-btn" style="background: #8b5cf6;">Exempelknapp</button>
                </div>

                <div class="form-actions">
                    <a href="/setup?step=1" class="btn btn-secondary">&larr; Tillbaka</a>
                    <button type="submit" class="btn btn-primary">Nästa &rarr;</button>
                </div>
            </form>
        </div>

        <?php elseif ($step === 3): ?>
        <!-- STEG 3: Admin-konto -->
        <div class="setup-card">
            <h2>Admin-konto</h2>
            <form method="post" action="/setup?step=3" id="step3-form">
                <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars($_SESSION['setup_csrf']); ?>">
                <input type="hidden" name="step" value="3">

                <div class="form-group">
                    <label for="admin_username">Användarnamn *</label>
                    <input type="text" id="admin_username" name="admin_username" required minlength="3"
                           placeholder="admin" autocomplete="username">
                    <div class="hint">Minst 3 tecken. Undvik "admin" för bättre säkerhet.</div>
                </div>

                <div class="form-group">
                    <label for="admin_email">E-postadress (för lösenordsåterställning)</label>
                    <input type="email" id="admin_email" name="admin_email"
                           placeholder="kund@foretag.se">
                    <div class="hint">Används för att återställa lösenordet via e-post.</div>
                </div>

                <div class="form-group">
                    <label for="admin_password">Lösenord *</label>
                    <div class="password-wrapper">
                        <input type="password" id="admin_password" name="admin_password" required minlength="8"
                               placeholder="Minst 8 tecken" autocomplete="new-password">
                        <button type="button" class="password-toggle" data-target="admin_password" aria-label="Visa lösenord">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                        </button>
                    </div>
                    <div class="password-strength">
                        <div class="password-strength-bar" id="strength-bar"></div>
                    </div>
                    <div class="password-strength-text" id="strength-text"></div>
                </div>

                <div class="form-group">
                    <label for="admin_password_confirm">Bekräfta lösenord *</label>
                    <div class="password-wrapper">
                        <input type="password" id="admin_password_confirm" name="admin_password_confirm" required minlength="8"
                               placeholder="Upprepa lösenord" autocomplete="new-password">
                        <button type="button" class="password-toggle" data-target="admin_password_confirm" aria-label="Visa lösenord">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                        </button>
                    </div>
                </div>

                <div class="section-divider">
                    <h3>Super-admin (byrå)</h3>
                    <p>Valfritt — används av byrån för att hantera sajten.</p>
                </div>

                <div class="form-group">
                    <label for="agency_user">Super-admin användarnamn</label>
                    <input type="text" id="agency_user" name="agency_user"
                           placeholder="admin" autocomplete="off">
                    <div class="hint">Används av byrån för att hantera sajten. Standard: "admin".</div>
                </div>

                <div class="form-group">
                    <label for="agency_pass">Super-admin lösenord</label>
                    <div class="password-wrapper">
                        <input type="password" id="agency_pass" name="agency_pass" minlength="8"
                               placeholder="Minst 8 tecken" autocomplete="new-password">
                        <button type="button" class="password-toggle" data-target="agency_pass" aria-label="Visa lösenord">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>
                        </button>
                    </div>
                    <div class="hint">Minst 8 tecken. Om tomt genereras ett slumpmässigt lösenord.</div>
                </div>

                <div class="form-actions">
                    <a href="/setup?step=2" class="btn btn-secondary">&larr; Tillbaka</a>
                    <button type="submit" class="btn btn-primary" id="submit-btn">Slutför installation</button>
                </div>
            </form>
        </div>

        <?php elseif ($step === 4):
            // Backend-verifiering
            $checks = [
                ['label' => 'config.php', 'desc' => 'Konfiguration', 'ok' => file_exists(__DIR__ . '/config.php')],
                ['label' => 'variables.css', 'desc' => 'Färger och typsnitt', 'ok' => file_exists(__DIR__ . '/assets/css/variables.css') && str_contains(file_get_contents(__DIR__ . '/assets/css/variables.css'), '--color-primary')],
                ['label' => 'overrides.css', 'desc' => 'Override-system', 'ok' => file_exists(__DIR__ . '/assets/css/overrides.css')],
                ['label' => 'content.json', 'desc' => 'Innehållsdata', 'ok' => file_exists(__DIR__ . '/data/content.json')],
                ['label' => 'brand-guide.md', 'desc' => 'Varumärkesguide', 'ok' => file_exists(__DIR__ . '/.rules/brand-guide.md')],
                ['label' => 'ai-rules.md', 'desc' => 'AI-regler', 'ok' => file_exists(__DIR__ . '/.rules/ai-rules.md')],
                ['label' => 'fonts.php', 'desc' => 'Typsnittslänkar', 'ok' => file_exists(__DIR__ . '/includes/fonts.php')],
                ['label' => 'SMTP', 'desc' => 'E-postkonfiguration', 'ok' => defined('SMTP_HOST') || (file_exists(__DIR__ . '/config.php') && str_contains(file_get_contents(__DIR__ . '/config.php'), 'SMTP_HOST'))],
                ['label' => 'Säkerhet', 'desc' => 'Session & CSRF', 'ok' => file_exists(__DIR__ . '/config.php') && str_contains(file_get_contents(__DIR__ . '/config.php'), 'SESSION_SECRET')],
                ['label' => 'Skrivbar', 'desc' => 'data/-mappen', 'ok' => is_writable(__DIR__ . '/data')],
            ];
            $allOk = !in_array(false, array_column($checks, 'ok'));
        ?>
        <!-- STEG 4: Verifiering + Färdig -->
        <div class="setup-card" id="verify-card">
            <h2 style="text-align: center;" id="verify-title">Verifierar installation...</h2>
            <p style="text-align: center; color: rgba(255,255,255,0.50); margin-bottom: 1.5rem;" id="verify-subtitle">Kontrollerar att allt genererats korrekt</p>

            <ul class="complete-list" id="verify-list">
                <?php foreach ($checks as $i => $check): ?>
                <li data-index="<?php echo $i; ?>" data-ok="<?php echo $check['ok'] ? '1' : '0'; ?>" style="opacity: 0.3;">
                    <span class="check-icon" style="background: rgba(255,255,255,0.10);" id="icon-<?php echo $i; ?>">
                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" style="display:none;" id="svg-<?php echo $i; ?>">
                            <path d="M2 6L5 9L10 3" stroke="white" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                        <svg width="12" height="12" viewBox="0 0 12 12" fill="none" style="display:none;" id="fail-<?php echo $i; ?>">
                            <path d="M3 3L9 9M9 3L3 9" stroke="white" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                    </span>
                    <span><?php echo htmlspecialchars($check['label']); ?> — <?php echo htmlspecialchars($check['desc']); ?></span>
                </li>
                <?php endforeach; ?>
            </ul>

            <?php
                // Read API key from newly generated config.php
                $generatedApiKey = '';
                $configPath = __DIR__ . '/config.php';
                if (file_exists($configPath)) {
                    $configSrc = file_get_contents($configPath);
                    if (preg_match("/define\('API_KEY',\s*'([a-f0-9]{64})'\)/", $configSrc, $akm)) {
                        $generatedApiKey = $akm[1];
                    }
                }
            ?>
            <?php if ($generatedApiKey): ?>
            <div id="api-key-section" style="margin-top: 1.5rem; padding: 1.25rem; background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.10); border-radius: 0.75rem; display: none;">
                <h3 style="font-size: 0.9375rem; font-weight: 600; margin-bottom: 0.25rem;">API-nyckel</h3>
                <p style="font-size: 0.8125rem; color: rgba(255,255,255,0.50); margin-bottom: 1rem;">Denna nyckel behövs för att anropa API:t. Kopiera och spara den säkert — du hittar den även i Super Admin.</p>
                <div style="display: flex; align-items: center; gap: 0.5rem;">
                    <code id="setup-api-key" style="flex:1; font-size: 0.8125rem; background: rgba(255,255,255,0.08); padding: 0.5rem 0.75rem; border-radius: 0.375rem; word-break: break-all; color: white;"><?php echo htmlspecialchars($generatedApiKey); ?></code>
                    <button type="button" id="btn-copy-api-key" style="padding: 0.5rem 1rem; font-size: 0.8125rem; font-weight: 600; background: rgba(255,255,255,0.10); color: white; border: 1px solid rgba(255,255,255,0.15); border-radius: 0.375rem; cursor: pointer; white-space: nowrap;">Kopiera</button>
                </div>
            </div>
            <script>
            document.getElementById('btn-copy-api-key').addEventListener('click', function() {
                var key = <?php echo json_encode($generatedApiKey); ?>;
                navigator.clipboard.writeText(key).then(function() {
                    var btn = document.getElementById('btn-copy-api-key');
                    btn.textContent = 'Kopierad!';
                    setTimeout(function() { btn.textContent = 'Kopiera'; }, 2000);
                });
            });
            </script>
            <?php endif; ?>

            <div class="complete-actions" id="verify-actions" style="display: none;">
                <a href="/" class="btn btn-primary">Gå till hemsidan</a>
                <a href="/admin" class="btn btn-success">Öppna admin</a>
            </div>
        </div>

        <script>
        (function() {
            const items = document.querySelectorAll('#verify-list li');
            const total = items.length;
            let current = 0;

            function revealNext() {
                if (current >= total) {
                    // Done — show result
                    const allOk = <?php echo $allOk ? 'true' : 'false'; ?>;
                    document.getElementById('verify-title').textContent = allOk ? 'Installation klar!' : 'Nästan klart';
                    document.getElementById('verify-subtitle').textContent = allOk
                        ? 'Alla kontroller godkända — din webbplats är redo.'
                        : 'Vissa kontroller misslyckades. Se markerade rader.';
                    var apiSection = document.getElementById('api-key-section');
                    if (apiSection) {
                        apiSection.style.display = 'block';
                        apiSection.style.opacity = '0';
                        apiSection.style.transition = 'opacity 0.4s';
                        setTimeout(function() { apiSection.style.opacity = '1'; }, 50);
                    }
                    document.getElementById('verify-actions').style.display = 'flex';
                    return;
                }

                const li = items[current];
                const ok = li.dataset.ok === '1';
                const icon = document.getElementById('icon-' + current);
                const svg = document.getElementById('svg-' + current);
                const fail = document.getElementById('fail-' + current);

                li.style.transition = 'opacity 0.3s';
                li.style.opacity = '1';

                setTimeout(function() {
                    icon.style.transition = 'background 0.2s';
                    icon.style.background = ok ? '#10b981' : '#ef4444';
                    if (ok) {
                        svg.style.display = 'block';
                    } else {
                        fail.style.display = 'block';
                    }
                    current++;
                    setTimeout(revealNext, 200);
                }, 150);
            }

            setTimeout(revealNext, 500);
        })();
        </script>
        <?php endif; ?>
    </div>

    <?php
    $setupAgency = ['url' => 'https://peys.se', 'corner_text' => 'Skapad av oss 🥳'];
    if (file_exists(__DIR__ . '/agency-defaults.json')) {
        $j = json_decode(file_get_contents(__DIR__ . '/agency-defaults.json'), true);
        if (is_array($j)) $setupAgency = array_merge($setupAgency, $j);
    }
    ?>
    <div class="agenci-badge">
        <a href="<?php echo htmlspecialchars($setupAgency['url']); ?>" target="_blank" rel="noopener noreferrer">
            <?php echo htmlspecialchars($setupAgency['corner_text']); ?>
        </a>
    </div>

    <script>
    // Logo preview
    function previewLogo(input, previewId) {
        const preview = document.getElementById(previewId);
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.style.display = 'block';
            };
            reader.readAsDataURL(input.files[0]);
        }
    }

    // Favicon preview
    function previewFavicon(input) {
        const preview = document.getElementById('preview-favicon');
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.style.display = 'block';
            };
            reader.readAsDataURL(input.files[0]);
        }
    }

    // Show custom font filename
    function showFontFileName(input) {
        const nameSpan = document.getElementById('custom-font-name');
        if (input.files && input.files[0]) {
            nameSpan.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align: -2px; margin-right: 4px;"><polyline points="20 6 9 17 4 12"/></svg>' + input.files[0].name;
            nameSpan.style.display = 'block';
        } else {
            nameSpan.style.display = 'none';
        }
    }

    // Color picker sync
    function updateColorText(colorInput, textId) {
        document.getElementById(textId).value = colorInput.value;
    }

    // Update preview
    function updatePreview() {
        const primary = document.getElementById('primary_color')?.value || '#8b5cf6';
        const secondary = document.getElementById('secondary_color')?.value || '#379b83';
        const accent = document.getElementById('accent_color')?.value || '#379b83';

        const sp = document.getElementById('swatch-primary');
        const ss = document.getElementById('swatch-secondary');
        const sa = document.getElementById('swatch-accent');
        const btn = document.getElementById('preview-btn');

        if (sp) sp.style.background = primary;
        if (ss) ss.style.background = secondary;
        if (sa) sa.style.background = accent;

        // Border radius
        const radiusMap = { sharp: '2px', rounded: '8px', soft: '16px', pill: '9999px' };
        const radius = radiusMap[document.getElementById('border_radius')?.value] || '8px';

        // Button style
        const btnStyle = document.getElementById('button_style')?.value || 'filled';

        if (btn) {
            btn.style.borderRadius = radius;
            if (btnStyle === 'filled') {
                btn.style.background = primary;
                btn.style.color = 'white';
                btn.style.border = 'none';
            } else if (btnStyle === 'outline') {
                btn.style.background = 'transparent';
                btn.style.color = primary;
                btn.style.border = '2px solid ' + primary;
            } else {
                btn.style.background = 'transparent';
                btn.style.color = primary;
                btn.style.border = 'none';
            }
        }

        // Update swatches radius
        [sp, ss, sa].forEach(function(s) { if (s) s.style.borderRadius = radius; });
    }

    // Font preview with dynamic loading
    const loadedFonts = {};
    function loadGoogleFont(fontName) {
        if (fontName === 'System UI' || loadedFonts[fontName]) return;
        const link = document.createElement('link');
        link.rel = 'stylesheet';
        link.href = 'https://fonts.googleapis.com/css2?family=' + encodeURIComponent(fontName) + ':wght@400;500;600;700&display=swap';
        document.head.appendChild(link);
        loadedFonts[fontName] = true;
    }

    function getFontFamily(fontName) {
        if (fontName === 'System UI') return 'system-ui, sans-serif';
        return "'" + fontName + "', system-ui, sans-serif";
    }

    function updateFontPreview() {
        const heading = document.getElementById('font_heading')?.value || 'System UI';
        const body = document.getElementById('font_body')?.value || 'System UI';

        loadGoogleFont(heading);
        loadGoogleFont(body);

        const previewH = document.getElementById('preview-heading');
        const previewB = document.getElementById('preview-body');

        if (previewH) previewH.style.fontFamily = getFontFamily(heading);
        if (previewB) previewB.style.fontFamily = getFontFamily(body);
    }

    // Password strength indicator
    const passwordInput = document.getElementById('admin_password');
    if (passwordInput) {
        passwordInput.addEventListener('input', function() {
            const val = this.value;
            let score = 0;
            if (val.length >= 8) score++;
            if (val.length >= 12) score++;
            if (/[a-z]/.test(val) && /[A-Z]/.test(val)) score++;
            if (/\d/.test(val)) score++;
            if (/[^a-zA-Z0-9]/.test(val)) score++;

            const bar = document.getElementById('strength-bar');
            const text = document.getElementById('strength-text');
            const levels = [
                { width: '0%', color: '#e4e4e7', label: '' },
                { width: '20%', color: '#ef4444', label: 'Mycket svagt' },
                { width: '40%', color: '#f59e0b', label: 'Svagt' },
                { width: '60%', color: '#f59e0b', label: 'Medel' },
                { width: '80%', color: '#10b981', label: 'Starkt' },
                { width: '100%', color: '#10b981', label: 'Mycket starkt' },
            ];

            if (bar) {
                bar.style.width = levels[score].width;
                bar.style.background = levels[score].color;
            }
            if (text) {
                text.textContent = levels[score].label;
                text.style.color = levels[score].color;
            }
        });
    }

    // Client-side validation
    document.querySelectorAll('form').forEach(function(form) {
        form.addEventListener('submit', function(e) {
            const step3 = document.getElementById('step3-form');
            const configOnly = document.getElementById('config-only-form');
            if (form === step3 || form === configOnly) {
                const pw = document.getElementById('admin_password').value;
                const pwc = document.getElementById('admin_password_confirm').value;
                if (pw !== pwc) {
                    e.preventDefault();
                    alert('Lösenorden matchar inte.');
                    return false;
                }
            }
        });
    });

    // Init preview on load
    if (document.getElementById('design-preview')) {
        updatePreview();
        updateFontPreview();
    }

    // Password visibility toggle
    document.querySelectorAll('.password-toggle').forEach(function(btn) {
        btn.addEventListener('click', function() {
            var input = document.getElementById(this.dataset.target);
            if (!input) return;
            var isPassword = input.type === 'password';
            input.type = isPassword ? 'text' : 'password';
            this.innerHTML = isPassword
                ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></svg>'
                : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></svg>';
        });
    });

    // API key generate + copy
    (function() {
        var genBtn = document.getElementById('btn-generate-api-key');
        var copyBtn = document.getElementById('btn-copy-api-key-setup');
        var field = document.getElementById('api_key_field');
        if (!genBtn || !field) return;

        genBtn.addEventListener('click', function() {
            var arr = new Uint8Array(32);
            crypto.getRandomValues(arr);
            var hex = Array.from(arr, function(b) { return b.toString(16).padStart(2, '0'); }).join('');
            field.value = hex;
            copyBtn.style.display = 'inline-flex';
        });

        copyBtn.addEventListener('click', function() {
            navigator.clipboard.writeText(field.value).then(function() {
                copyBtn.textContent = 'Kopierad!';
                setTimeout(function() { copyBtn.textContent = 'Kopiera'; }, 2000);
            });
        });
    })();

    // Google Analytics toggle
    document.querySelectorAll('input[name="has_analytics"]').forEach(function(r) {
        r.addEventListener('change', function() {
            document.getElementById('ga-id-group').style.display =
                document.querySelector('input[name="has_analytics"][value="yes"]').checked ? 'block' : 'none';
            if (!this.checked || this.value === 'no') {
                document.getElementById('ga_id').value = '';
            }
        });
    });
    </script>
</body>
</html>
