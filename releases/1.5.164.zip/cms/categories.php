<?php
/**
 * CMS Category Management — Manage category labels
 * CORE-fil — skrivs över vid uppdatering
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../security/session.php';
require_once __DIR__ . '/../security/csrf.php';
require_once __DIR__ . '/helpers.php';

if (!is_logged_in()) {
    header('Location: /admin');
    exit;
}

$categoriesFile = __DIR__ . '/extensions/categories.php';

// Load current data
$categories = file_exists($categoriesFile) ? (require $categoriesFile) : [];
if (!is_array($categories)) $categories = [];
// Migrate old format (associative array with route keys) to new format (simple array)
if (!empty($categories) && !array_is_list($categories)) {
    $categories = array_unique(array_column($categories, 'category'));
    $categories = array_values(array_filter($categories));
}

$error = '';

// Handle POST actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();
    $action = $_POST['action'] ?? '';

    // --- Category actions ---
    if ($action === 'add_category') {
        $name = trim($_POST['category_name'] ?? '');
        if (empty($name)) {
            $error = 'Kategorinamn krävs.';
        } elseif (in_array($name, $categories, true)) {
            $error = 'Kategorin "' . htmlspecialchars($name) . '" finns redan.';
        } else {
            $categories[] = $name;
            if (saveCategoryLabels($categories, $categoriesFile)) {
                header('Location: /categories?msg=saved'); exit;
            } else {
                $error = 'Kunde inte spara. Kontrollera filrättigheter.';
            }
        }
    } elseif ($action === 'delete_category') {
        $name = $_POST['category_name'] ?? '';
        if ($name === 'Inlägg') {
            $error = 'Standardkategorin "Inlägg" kan inte tas bort.';
        } else {
            $categories = array_values(array_filter($categories, fn($c) => $c !== $name));
            if (saveCategoryLabels($categories, $categoriesFile)) {
                header('Location: /categories?msg=saved'); exit;
            } else {
                $error = 'Kunde inte spara.';
            }
        }
    }
}

// Reload after save
$categories = file_exists($categoriesFile) ? (require $categoriesFile) : [];
if (!is_array($categories)) $categories = [];
if (!empty($categories) && !array_is_list($categories)) {
    $categories = array_unique(array_column($categories, 'category'));
    $categories = array_values(array_filter($categories));
}

/**
 * Save category labels (simple string array)
 */
function saveCategoryLabels(array $cats, string $catFile): bool
{
    $content = "<?php\n";
    $content .= "/**\n";
    $content .= " * Category labels (SAFE — survives updates)\n";
    $content .= " * Managed via CMS admin (/categories). Manual edits are also OK.\n";
    $content .= " */\n";
    $content .= "return " . var_export(array_values($cats), true) . ";\n";
    return file_put_contents($catFile, $content, LOCK_EX) !== false;
}
?>
<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kategorier - CMS</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'DM Sans', sans-serif;
            background-color: #033234;
            min-height: 100vh;
            color: white;
        }
        .page-content { padding: 3rem 1.5rem; }
        .container { max-width: 52rem; margin: 0 auto; }
        .back-link {
            display: inline-block;
            color: rgba(255,255,255,0.50);
            text-decoration: none;
            font-size: 0.875rem;
            margin-bottom: 1rem;
            transition: color 0.2s;
        }
        .back-link:hover { color: rgba(255,255,255,1.0); }
        .title {
            font-size: 2rem;
            font-weight: bold;
            margin-bottom: 0.5rem;
        }
        .subtitle {
            font-size: 0.9375rem;
            color: rgba(255,255,255,0.50);
            margin-bottom: 2rem;
        }
        .card {
            background: rgba(255,255,255,0.05);
            border-radius: 1.5rem;
            border: 1px solid rgba(255,255,255,0.10);
            padding: 2rem;
            margin-bottom: 1.5rem;
        }
        .card-title {
            font-size: 1.125rem;
            font-weight: 600;
            margin-bottom: 1.5rem;
        }
        .alert {
            padding: 0.875rem 1rem;
            border-radius: 0.75rem;
            font-size: 0.875rem;
            margin-bottom: 1.5rem;
        }
        .alert-error {
            background: rgba(220,38,38,0.15);
            border: 1px solid rgba(220,38,38,0.3);
            color: #fca5a5;
        }
        .cat-list { list-style: none; }
        .cat-item {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 1rem 0;
            border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .cat-item:last-child { border-bottom: none; }
        .cat-info { flex: 1; }
        .cat-name {
            font-weight: 600;
            font-size: 1rem;
            color: #6ee7b7;
        }
        .cat-prefix {
            font-weight: 600;
            font-size: 1rem;
            color: #6ee7b7;
        }
        .cat-meta {
            font-size: 0.8125rem;
            color: rgba(255,255,255,0.50);
            margin-top: 0.25rem;
        }
        .cat-badge {
            display: inline-block;
            padding: 0.2rem 0.6rem;
            background: rgba(255,255,255,0.08);
            border-radius: 0.375rem;
            font-size: 0.75rem;
            color: rgba(255,255,255,0.50);
            margin-left: 0.5rem;
        }
        .btn-delete {
            background: none;
            border: 1px solid rgba(220,38,38,0.3);
            color: #fca5a5;
            padding: 0.4rem 0.75rem;
            border-radius: 0.5rem;
            font-size: 0.8125rem;
            cursor: pointer;
            transition: all 0.2s;
        }
        .btn-delete:hover {
            background: rgba(220,38,38,0.15);
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1rem;
        }
        .form-group { margin-bottom: 1rem; }
        .form-label {
            display: block;
            font-size: 0.8125rem;
            font-weight: 600;
            color: rgba(255,255,255,0.85);
            margin-bottom: 0.375rem;
        }
        .form-hint {
            font-size: 0.75rem;
            color: rgba(255,255,255,0.40);
            margin-top: 0.25rem;
        }
        .form-input, .form-select {
            width: 100%;
            padding: 0.75rem 1rem;
            border: 1px solid rgba(255,255,255,0.15);
            border-radius: 0.75rem;
            font-size: 0.9375rem;
            font-family: inherit;
            background: rgba(255,255,255,0.05);
            color: white;
            outline: none;
            transition: all 0.2s;
        }
        .form-input:focus, .form-select:focus {
            border-color: #379b83;
            box-shadow: 0 0 0 3px rgba(55, 155, 131, 0.2);
        }
        .form-input::placeholder { color: rgba(255,255,255,0.30); }
        .form-select option { background: #033234; color: white; }
        .checkbox-group {
            display: flex;
            flex-wrap: wrap;
            gap: 0.75rem;
            margin-top: 0.375rem;
        }
        .checkbox-label {
            display: flex;
            align-items: center;
            gap: 0.375rem;
            padding: 0.375rem 0.75rem;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.15);
            border-radius: 0.5rem;
            font-size: 0.875rem;
            color: rgba(255,255,255,0.85);
            cursor: pointer;
            transition: all 0.2s;
        }
        .checkbox-label:has(input:checked) {
            background: rgba(55,155,131,0.15);
            border-color: #379b83;
            color: #6ee7b7;
        }
        .checkbox-label input { accent-color: #379b83; }
        .btn-submit {
            padding: 0.75rem 1.5rem;
            background: #379b83;
            color: white;
            border: none;
            border-radius: 9999px;
            font-size: 0.9375rem;
            font-weight: 600;
            cursor: pointer;
            transition: opacity 0.2s;
        }
        .btn-submit:hover { opacity: 0.9; }
        .section-divider {
            border: none;
            border-top: 1px solid rgba(255,255,255,0.08);
            margin: 2rem 0;
        }
        @media (max-width: 640px) {
            .form-row { grid-template-columns: 1fr; }
        }
    </style>
<?php if (function_exists("agency_cms_theme")) { echo agency_cms_theme(); echo agency_cms_fonts(); } ?>
</head>
<body>
    <?php include __DIR__ . '/../includes/admin-bar.php'; ?>
    <div class="page-content">
    <div class="container">
        <a href="/dashboard" class="back-link">&larr; Tillbaka till dashboard</a>

        <h1 class="title">Kategorier</h1>
        <p class="subtitle">Hantera kategorietiketter. Kategorier visas som val i inläggshanteraren.</p>

        <?php if ($error): ?>
            <div class="alert alert-error"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- ===== SECTION 1: Categories (labels) ===== -->
        <div class="card">
            <h2 class="card-title">Kategorier</h2>
            <p style="color: rgba(255,255,255,0.50); font-size: 0.8125rem; margin-bottom: 1rem;">Etiketter som tilldelas inlägg.</p>

            <?php if (empty($categories)): ?>
                <p style="color: rgba(255,255,255,0.40); font-size: 0.875rem;">Inga kategorier.</p>
            <?php else: ?>
                <ul class="cat-list">
                    <?php foreach ($categories as $cat): ?>
                    <li class="cat-item">
                        <div class="cat-info">
                            <span class="cat-name"><?php echo htmlspecialchars($cat, ENT_QUOTES, 'UTF-8'); ?></span>
                            <?php if ($cat === 'Inlägg'): ?>
                                <span class="cat-badge">Standard</span>
                            <?php endif; ?>
                        </div>
                        <?php if ($cat !== 'Inlägg'): ?>
                        <form method="POST" style="margin: 0;" onsubmit="return confirm('Ta bort kategorin &quot;<?php echo htmlspecialchars($cat, ENT_QUOTES, 'UTF-8'); ?>&quot;?')">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="action" value="delete_category">
                            <input type="hidden" name="category_name" value="<?php echo htmlspecialchars($cat, ENT_QUOTES, 'UTF-8'); ?>">
                            <button type="submit" class="btn-delete">Ta bort</button>
                        </form>
                        <?php endif; ?>
                    </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>

            <hr class="section-divider">

            <form method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="add_category">
                <div class="form-group" style="display: flex; gap: 0.75rem; align-items: flex-end;">
                    <div style="flex: 1;">
                        <label class="form-label" for="new_cat_name">Ny kategori</label>
                        <input type="text" id="new_cat_name" name="category_name" class="form-input" placeholder="T.ex. Event, Nyhet, Blogg" required>
                    </div>
                    <button type="submit" class="btn-submit">Lägg till</button>
                </div>
            </form>
        </div>

    </div>
    </div>

    <script src="/assets/js/cms.js?v=<?php echo defined('BOSSE_VERSION') ? BOSSE_VERSION : '1'; ?>"></script>
</body>
</html>
