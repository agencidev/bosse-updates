<?php
/**
 * Form Log Data Access Layer
 * SQLite-baserad formulärlogg — sparar alla inskick oavsett formulärtyp.
 * CORE-fil — skrivs över vid uppdatering.
 */

/**
 * Get or create SQLite PDO connection (lazy singleton)
 */
function get_form_log_db(): PDO {
    static $pdo = null;
    if ($pdo !== null) return $pdo;

    $dbPath = defined('DATA_PATH') ? DATA_PATH . '/form-log.db' : dirname(__DIR__) . '/data/form-log.db';

    $pdo = new PDO('sqlite:' . $dbPath, null, null, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
    ]);

    $pdo->exec('PRAGMA journal_mode=WAL');
    $pdo->exec('PRAGMA busy_timeout=5000');

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            source TEXT DEFAULT 'kontakt',
            name TEXT DEFAULT '',
            email TEXT DEFAULT '',
            phone TEXT DEFAULT '',
            message TEXT DEFAULT '',
            fields TEXT DEFAULT '{}',
            email_sent INTEGER DEFAULT 0,
            email_error TEXT DEFAULT '',
            ip TEXT DEFAULT '',
            read INTEGER DEFAULT 0,
            created_at TEXT DEFAULT (datetime('now'))
        )
    ");

    return $pdo;
}

/**
 * Submit a form entry — saves to DB + sends email notification.
 *
 * Usage:
 *   form_log_submit([
 *       'source' => 'Bordsbokning',
 *       'name' => 'Anna',
 *       'email' => 'anna@test.se',
 *       'message' => 'Vill boka bord',
 *       'fields' => ['datum' => '2026-04-15', 'gäster' => '4'],
 *       'email_to' => 'info@restaurant.se',
 *   ]);
 *
 * @return int The new submission ID
 */
function form_log_submit(array $data): int {
    $db = get_form_log_db();

    $source  = trim($data['source'] ?? 'kontakt');
    $name    = trim($data['name'] ?? '');
    $email   = trim($data['email'] ?? '');
    $phone   = trim($data['phone'] ?? '');
    $message = trim($data['message'] ?? '');
    $fields  = isset($data['fields']) && is_array($data['fields']) ? json_encode($data['fields'], JSON_UNESCAPED_UNICODE) : '{}';
    $ip      = $_SERVER['REMOTE_ADDR'] ?? '';

    // Save to database
    $stmt = $db->prepare("
        INSERT INTO submissions (source, name, email, phone, message, fields, ip)
        VALUES (:source, :name, :email, :phone, :message, :fields, :ip)
    ");
    $stmt->execute([
        ':source'  => $source,
        ':name'    => $name,
        ':email'   => $email,
        ':phone'   => $phone,
        ':message' => $message,
        ':fields'  => $fields,
        ':ip'      => $ip,
    ]);
    $id = (int) $db->lastInsertId();

    // Send email notification
    $emailTo = $data['email_to'] ?? (defined('CONTACT_EMAIL') ? CONTACT_EMAIL : '');
    $emailSent = 0;
    $emailError = '';

    if (!empty($emailTo) && function_exists('send_mail')) {
        $siteName = defined('SITE_NAME') ? SITE_NAME : '';
        $subject = "Nytt formulär: {$source}" . ($siteName ? " — {$siteName}" : '');

        $body = "Nytt inskick från {$source}\n\n";
        $body .= "Namn: {$name}\n";
        if ($email) $body .= "E-post: {$email}\n";
        if ($phone) $body .= "Telefon: {$phone}\n";
        if ($message) $body .= "\nMeddelande:\n{$message}\n";

        // Extra fält
        $extraFields = json_decode($fields, true);
        if (!empty($extraFields)) {
            $body .= "\n--- Detaljer ---\n";
            foreach ($extraFields as $key => $value) {
                $body .= ucfirst($key) . ": {$value}\n";
            }
        }

        $result = @send_mail($emailTo, $subject, $body, [
            'reply_to' => $email ?: null,
            'from_name' => $siteName ?: 'Bosse CMS',
        ]);

        $emailSent = $result ? 1 : 0;
        if (!$result) {
            $emailError = function_exists('send_mail_error') ? send_mail_error() : 'Okänt fel';
        }
    } elseif (empty($emailTo)) {
        $emailError = 'Ingen mottagaradress konfigurerad (CONTACT_EMAIL saknas)';
    }

    // Update email status
    $stmt = $db->prepare("UPDATE submissions SET email_sent = :sent, email_error = :error WHERE id = :id");
    $stmt->execute([':sent' => $emailSent, ':error' => $emailError, ':id' => $id]);

    return $id;
}

/**
 * List submissions (newest first)
 */
function form_log_list(?string $source = null, int $limit = 20, int $offset = 0): array {
    $db = get_form_log_db();

    if ($source && $source !== 'all') {
        $stmt = $db->prepare("SELECT * FROM submissions WHERE source = :source ORDER BY created_at DESC LIMIT :limit OFFSET :offset");
        $stmt->bindValue(':source', $source, PDO::PARAM_STR);
    } else {
        $stmt = $db->prepare("SELECT * FROM submissions ORDER BY created_at DESC LIMIT :limit OFFSET :offset");
    }
    $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
    $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
    $stmt->execute();

    $rows = $stmt->fetchAll();
    foreach ($rows as &$row) {
        $row['fields'] = json_decode($row['fields'] ?? '{}', true) ?: [];
    }
    return $rows;
}

/**
 * Get a single submission
 */
function form_log_get(int $id): ?array {
    $db = get_form_log_db();
    $stmt = $db->prepare("SELECT * FROM submissions WHERE id = :id");
    $stmt->execute([':id' => $id]);
    $row = $stmt->fetch();
    if ($row) {
        $row['fields'] = json_decode($row['fields'] ?? '{}', true) ?: [];
    }
    return $row ?: null;
}

/**
 * Toggle read status
 */
function form_log_mark_read(int $id, bool $read = true): void {
    $db = get_form_log_db();
    $stmt = $db->prepare("UPDATE submissions SET read = :read WHERE id = :id");
    $stmt->execute([':read' => $read ? 1 : 0, ':id' => $id]);
}

/**
 * Count unread submissions
 */
function form_log_count_unread(): int {
    $db = get_form_log_db();
    return (int) $db->query("SELECT COUNT(*) FROM submissions WHERE read = 0")->fetchColumn();
}

/**
 * Get unique source values (for filter tabs)
 */
function form_log_sources(): array {
    $db = get_form_log_db();
    return $db->query("SELECT DISTINCT source FROM submissions ORDER BY source")->fetchAll(PDO::FETCH_COLUMN);
}
