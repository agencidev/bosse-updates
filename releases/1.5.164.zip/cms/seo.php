<?php
/**
 * SEO Admin — Meta title & description management
 * Super-admin only
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../security/session.php';
require_once __DIR__ . '/../security/csrf.php';
require_once __DIR__ . '/../security/super-admin.php';
require_once __DIR__ . '/content.php';

if (!is_logged_in()) {
    header('Location: /cms/admin.php');
    exit;
}

if (!is_super_admin()) {
    require_super_admin();
}

// Known static pages with content.json keys
$pages = [
    ['url' => '/', 'label' => 'Startsida', 'key' => 'home'],
    ['url' => '/cookies', 'label' => 'Cookies', 'key' => 'cookies'],
    ['url' => '/integritetspolicy', 'label' => 'Integritetspolicy', 'key' => 'integritetspolicy'],
];

// Discover custom pages in pages/*.php (exclude system files)
$exclude = ['inlagg.php', 'inlagg-single.php', 'cookies.php', 'integritetspolicy.php'];
$pagesDir = ROOT_PATH . '/pages';
$knownKeys = array_column($pages, 'key');
if (is_dir($pagesDir)) {
    foreach (glob($pagesDir . '/*.php') as $file) {
        $basename = basename($file);
        if (in_array($basename, $exclude, true)) continue;
        $slug = pathinfo($basename, PATHINFO_FILENAME);
        if (in_array($slug, $knownKeys, true)) continue;
        $label = ucfirst(str_replace('-', ' ', $slug));
        $pages[] = ['url' => '/' . $slug, 'label' => $label, 'key' => $slug];
    }
}

// Handle save
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();

    $titles = $_POST['meta_title'] ?? [];
    $descriptions = $_POST['meta_description'] ?? [];

    $updates = [];
    foreach ($pages as $page) {
        $key = $page['key'];
        if (isset($titles[$key])) {
            $updates[$key . '.meta_title'] = trim($titles[$key]);
        }
        if (isset($descriptions[$key])) {
            $updates[$key . '.meta_description'] = trim($descriptions[$key]);
        }
    }

    if (!empty($updates)) {
        $result = save_content_bulk($updates);
        if ($result) {
            header('Location: /seo?msg=saved'); exit;
        } else {
            $error = 'Kunde inte spara. Försök igen.';
        }
    }
}

// Load current values
$content = get_all_content();

// Default meta values per page (fallback when content.json is empty)
$defaults = [
    'home' => ['title' => 'Välkommen', 'description' => 'Modern hemsida med CMS, SEO och säkerhet'],
    'cookies' => ['title' => 'Cookie Policy', 'description' => 'Information om hur vi använder cookies på webbplatsen.'],
    'integritetspolicy' => ['title' => 'Integritetspolicy', 'description' => 'Läs om hur vi hanterar dina personuppgifter i enlighet med GDPR.'],
];
?>
<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SEO - CMS</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Space+Grotesk:wght@400;500;600;700&family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'DM Sans', sans-serif;
            background-color: #033234;
            min-height: 100vh;
            color: rgba(255,255,255,1.0);
        }
        .page-content { padding: 3rem 1.5rem; }
        .container { max-width: 52rem; margin: 0 auto; }
        .back-link {
            display: inline-block;
            color: rgba(255,255,255,0.50);
            text-decoration: none;
            font-size: 0.875rem;
            margin-bottom: 1.5rem;
            transition: color 0.2s;
        }
        .back-link:hover { color: rgba(255,255,255,1.0); }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 0.5rem;
        }
        .title { font-size: 2rem; font-weight: bold; }
        .description {
            color: rgba(255,255,255,0.50);
            font-size: 0.875rem;
            line-height: 1.6;
            margin-bottom: 2rem;
        }
        .alert {
            padding: 0.875rem 1rem;
            border-radius: 0.5rem;
            font-size: 0.875rem;
            margin-bottom: 1.5rem;
        }
        .alert-error {
            background: rgba(220,38,38,0.15);
            border: 1px solid rgba(220,38,38,0.3);
            color: #f87171;
        }
        .page-card {
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.10);
            border-radius: 1rem;
            padding: 1.25rem;
            margin-bottom: 1rem;
        }
        .page-card-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1rem;
        }
        .page-label {
            font-size: 1rem;
            font-weight: 600;
        }
        .page-url {
            font-size: 0.75rem;
            color: rgba(255,255,255,0.40);
            font-family: monospace;
        }
        .form-group { margin-bottom: 0.75rem; }
        .form-label {
            display: block;
            font-size: 0.8125rem;
            font-weight: 600;
            color: rgba(255,255,255,0.65);
            margin-bottom: 0.25rem;
        }
        .form-input, .form-textarea {
            width: 100%;
            padding: 0.625rem 0.75rem;
            border: 1px solid rgba(255,255,255,0.15);
            border-radius: 0.5rem;
            font-size: 0.875rem;
            font-family: inherit;
            outline: none;
            transition: all 0.2s;
            background-color: rgba(255,255,255,0.05);
            color: white;
        }
        .form-input:focus, .form-textarea:focus {
            border-color: #379b83;
            box-shadow: 0 0 0 3px rgba(55, 155, 131, 0.1);
        }
        .form-textarea { resize: vertical; min-height: 60px; }
        .char-count {
            font-size: 0.6875rem;
            color: rgba(255,255,255,0.40);
            margin-top: 0.125rem;
            text-align: right;
        }
        .char-count.warning { color: #ca8a04; }
        .char-count.error { color: #dc2626; }
        .btn-row {
            display: flex;
            justify-content: flex-end;
            margin-top: 1.5rem;
        }
        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            padding: 0.75rem 2rem;
            border-radius: 9999px;
            font-size: 0.875rem;
            font-weight: 600;
            cursor: pointer;
            border: none;
            transition: all 0.2s;
        }
        .btn-primary { background: #379b83; color: white; }
        .btn-primary:hover { background: #2e8570; }
        .preview-bar {
            margin-top: 0.5rem;
            padding: 0.625rem 0.75rem;
            background: rgba(255,255,255,0.03);
            border-radius: 0.375rem;
            border: 1px solid rgba(255,255,255,0.06);
        }
        .preview-title {
            font-size: 0.875rem;
            color: #8ab4f8;
            margin-bottom: 0.125rem;
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .preview-url {
            font-size: 0.75rem;
            color: #bdc1c6;
            margin-bottom: 0.25rem;
        }
        .preview-desc {
            font-size: 0.8125rem;
            color: #bdc1c6;
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
        }
        .preview-label {
            font-size: 0.6875rem;
            color: rgba(255,255,255,0.30);
            margin-bottom: 0.25rem;
        }
        @media (max-width: 640px) {
            .page-card-header { flex-direction: column; align-items: flex-start; gap: 0.25rem; }
        }
    </style>
<?php if (function_exists("agency_cms_theme")) { echo agency_cms_theme(); echo agency_cms_fonts(); } ?>
</head>
<body>
    <?php include __DIR__ . '/../includes/admin-bar.php'; ?>
    <div class="page-content">
    <div class="container">
        <a href="/dashboard" class="back-link">&larr; Tillbaka</a>

        <div class="header">
            <h1 class="title">SEO</h1>
        </div>
        <p class="description">
            Hantera meta-titlar och beskrivningar för sajtens sidor. Dessa visas i sökresultat på Google.
        </p>

        <?php if ($error): ?>
        <div class="alert alert-error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="POST" action="/seo">
            <?php csrf_field(); ?>

            <?php foreach ($pages as $page):
                $key = $page['key'];
                $currentTitle = $content[$key]['meta_title'] ?? $defaults[$key]['title'] ?? '';
                $currentDesc = $content[$key]['meta_description'] ?? $defaults[$key]['description'] ?? '';
                $siteUrl = defined('SITE_URL') ? SITE_URL : '';
            ?>
            <div class="page-card">
                <div class="page-card-header">
                    <span class="page-label"><?php echo htmlspecialchars($page['label']); ?></span>
                    <span class="page-url"><?php echo htmlspecialchars($page['url']); ?></span>
                </div>

                <div class="form-group">
                    <label class="form-label">Meta-titel</label>
                    <input type="text"
                           class="form-input"
                           name="meta_title[<?php echo htmlspecialchars($key); ?>]"
                           value="<?php echo htmlspecialchars($currentTitle); ?>"
                           maxlength="70"
                           data-counter="title"
                           data-preview-title="<?php echo htmlspecialchars($key); ?>">
                    <div class="char-count" data-for="title-<?php echo htmlspecialchars($key); ?>">
                        <span class="count"><?php echo mb_strlen($currentTitle); ?></span> / 60
                    </div>
                </div>

                <div class="form-group">
                    <label class="form-label">Meta-beskrivning</label>
                    <textarea class="form-textarea"
                              name="meta_description[<?php echo htmlspecialchars($key); ?>]"
                              maxlength="200"
                              data-counter="desc"
                              data-preview-desc="<?php echo htmlspecialchars($key); ?>"><?php echo htmlspecialchars($currentDesc); ?></textarea>
                    <div class="char-count" data-for="desc-<?php echo htmlspecialchars($key); ?>">
                        <span class="count"><?php echo mb_strlen($currentDesc); ?></span> / 160
                    </div>
                </div>

                <div class="preview-bar">
                    <div class="preview-label">Google-förhandsgranskning</div>
                    <div class="preview-title" id="preview-title-<?php echo htmlspecialchars($key); ?>"><?php echo htmlspecialchars($currentTitle); ?> | <?php echo htmlspecialchars(SITE_NAME); ?></div>
                    <div class="preview-url"><?php echo htmlspecialchars($siteUrl . $page['url']); ?></div>
                    <div class="preview-desc" id="preview-desc-<?php echo htmlspecialchars($key); ?>"><?php echo htmlspecialchars($currentDesc); ?></div>
                </div>
            </div>
            <?php endforeach; ?>

            <div class="btn-row">
                <button type="submit" class="btn btn-primary">Spara alla</button>
            </div>
        </form>
    </div>
    </div>
    <?php include __DIR__ . '/../includes/agenci-badge.php'; ?>
    <script <?php echo csp_nonce_attr(); ?>>
    document.querySelectorAll('.form-input[data-counter], .form-textarea[data-counter]').forEach(function(el) {
        var type = el.dataset.counter;
        var key = el.dataset.previewTitle || el.dataset.previewDesc;
        var limit = type === 'title' ? 60 : 160;
        var warnAt = type === 'title' ? 50 : 140;

        function update() {
            var len = el.value.length;
            var counterEl = el.closest('.form-group').querySelector('.char-count');
            var countSpan = counterEl.querySelector('.count');
            countSpan.textContent = len;

            counterEl.classList.remove('warning', 'error');
            if (len > limit) {
                counterEl.classList.add('error');
            } else if (len > warnAt) {
                counterEl.classList.add('warning');
            }

            // Update preview
            if (type === 'title') {
                var previewEl = document.getElementById('preview-title-' + key);
                if (previewEl) previewEl.textContent = (el.value || '') + ' | <?php echo htmlspecialchars(SITE_NAME, ENT_QUOTES); ?>';
            } else {
                var previewEl = document.getElementById('preview-desc-' + key);
                if (previewEl) previewEl.textContent = el.value || '';
            }
        }

        el.addEventListener('input', update);
    });
    </script>
    <script src="/assets/js/cms.js?v=<?php echo BOSSE_VERSION; ?>"></script>
</body>
</html>
