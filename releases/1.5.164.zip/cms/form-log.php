<?php
/**
 * Form Log — View form submissions
 * Dark theme matching dashboard (#033234, DM Sans)
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../security/session.php';
require_once __DIR__ . '/../security/csrf.php';
require_once __DIR__ . '/form-log-db.php';

if (!is_logged_in()) {
    header('Location: /admin');
    exit;
}

// Handle mark as read
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_require();
    $action = $_POST['action'] ?? '';
    if ($action === 'toggle_read' && isset($_POST['id'])) {
        $sub = form_log_get((int)$_POST['id']);
        if ($sub) form_log_mark_read((int)$_POST['id'], !$sub['read']);
        header('Location: /form-log?msg=updated');
        exit;
    }
}

$filter = $_GET['source'] ?? 'all';
$submissions = form_log_list($filter === 'all' ? null : $filter);
$sources = form_log_sources();
$unread = form_log_count_unread();

$months_sv = [
    1 => 'jan', 2 => 'feb', 3 => 'mar', 4 => 'apr',
    5 => 'maj', 6 => 'jun', 7 => 'jul', 8 => 'aug',
    9 => 'sep', 10 => 'okt', 11 => 'nov', 12 => 'dec',
];
?>
<!DOCTYPE html>
<html lang="sv">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formul&auml;r - CMS</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'DM Sans', sans-serif;
            background-color: #033234;
            min-height: 100vh;
            color: rgba(255,255,255,1.0);
        }
        .page-content { padding: 3rem 1.5rem; }
        .container { max-width: 60rem; margin: 0 auto; }
        .back-link {
            display: inline-block;
            color: rgba(255,255,255,0.50);
            text-decoration: none;
            font-size: 0.875rem;
            margin-bottom: 1rem;
            transition: color 0.2s;
        }
        .back-link:hover { color: rgba(255,255,255,1.0); }
        .page-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1.5rem;
        }
        .title-group { display: flex; align-items: center; gap: 0.75rem; }
        .title { font-size: 2rem; font-weight: bold; }
        .unread-badge {
            background: #ef4444;
            color: white;
            font-size: 0.75rem;
            font-weight: 700;
            padding: 0.2rem 0.6rem;
            border-radius: 9999px;
            line-height: 1;
        }
        .total-badge {
            background: rgba(255,255,255,0.10);
            color: rgba(255,255,255,0.6);
            font-size: 0.75rem;
            font-weight: 600;
            padding: 0.25rem 0.75rem;
            border-radius: 9999px;
        }

        /* Source filter tabs */
        .source-tabs {
            display: flex;
            gap: 0.375rem;
            margin-bottom: 1.5rem;
            flex-wrap: wrap;
        }
        .source-tab {
            display: inline-block;
            padding: 0.45rem 0.9rem;
            border-radius: 9999px;
            font-size: 0.8125rem;
            font-weight: 500;
            text-decoration: none;
            color: rgba(255,255,255,0.55);
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.10);
            transition: background 0.2s, color 0.2s;
        }
        .source-tab:hover {
            background: rgba(255,255,255,0.08);
            color: rgba(255,255,255,0.8);
        }
        .source-tab.active {
            background: #379b83;
            color: white;
            border-color: #379b83;
        }

        /* Submission list */
        .sub-list { display: flex; flex-direction: column; gap: 0.5rem; }
        .sub-row {
            padding: 1rem 1.25rem;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(255,255,255,0.10);
            border-radius: 0.75rem;
            transition: background 0.2s;
            cursor: pointer;
        }
        .sub-row:hover { background: rgba(255,255,255,0.08); }
        .sub-row.is-unread { border-left: 3px solid #379b83; }
        .sub-main {
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }
        .status-dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
            flex-shrink: 0;
        }
        .status-dot.sent { background: #22c55e; }
        .status-dot.failed { background: #ef4444; }
        .badge-source {
            font-size: 0.625rem;
            font-weight: 600;
            padding: 0.15rem 0.5rem;
            border-radius: 9999px;
            background: rgba(55,155,131,0.15);
            color: #379b83;
            text-transform: uppercase;
            letter-spacing: 0.03em;
            flex-shrink: 0;
        }
        .sub-name {
            font-size: 0.9375rem;
            font-weight: 600;
            color: rgba(255,255,255,0.9);
            white-space: nowrap;
        }
        .sub-email {
            font-size: 0.8125rem;
            color: rgba(255,255,255,0.45);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }
        .sub-message {
            flex: 1;
            font-size: 0.8125rem;
            color: rgba(255,255,255,0.50);
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
            min-width: 0;
        }
        .sub-date {
            font-size: 0.75rem;
            color: rgba(255,255,255,0.40);
            white-space: nowrap;
            flex-shrink: 0;
        }
        .sub-actions { flex-shrink: 0; }
        .btn-read {
            background: rgba(255,255,255,0.08);
            border: 1px solid rgba(255,255,255,0.15);
            color: rgba(255,255,255,0.6);
            font-size: 0.6875rem;
            font-weight: 600;
            font-family: inherit;
            padding: 0.3rem 0.6rem;
            border-radius: 0.375rem;
            cursor: pointer;
            transition: background 0.2s, color 0.2s;
        }
        .btn-read:hover {
            background: rgba(255,255,255,0.15);
            color: rgba(255,255,255,0.9);
        }
        .btn-read.is-read {
            background: rgba(55,155,131,0.15);
            border-color: rgba(55,155,131,0.3);
            color: #379b83;
        }

        /* Expanded fields */
        .sub-extra {
            display: none;
            margin-top: 0.75rem;
            padding-top: 0.75rem;
            border-top: 1px solid rgba(255,255,255,0.08);
        }
        .sub-row.expanded .sub-extra { display: block; }
        .sub-extra-message {
            font-size: 0.8125rem;
            color: rgba(255,255,255,0.65);
            line-height: 1.5;
            margin-bottom: 0.75rem;
            white-space: pre-wrap;
            word-break: break-word;
        }
        .sub-fields {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 0.5rem;
        }
        .sub-field-item {
            background: rgba(255,255,255,0.04);
            border-radius: 0.5rem;
            padding: 0.5rem 0.75rem;
        }
        .sub-field-label {
            font-size: 0.6875rem;
            font-weight: 600;
            color: rgba(255,255,255,0.40);
            text-transform: uppercase;
            letter-spacing: 0.03em;
            margin-bottom: 0.15rem;
        }
        .sub-field-value {
            font-size: 0.8125rem;
            color: rgba(255,255,255,0.75);
            word-break: break-word;
        }
        .email-error-detail {
            font-size: 0.75rem;
            color: #ef4444;
            margin-top: 0.5rem;
            padding: 0.4rem 0.6rem;
            background: rgba(239,68,68,0.08);
            border-radius: 0.375rem;
        }

        .empty-state {
            text-align: center;
            padding: 4rem 1.5rem;
            color: rgba(255,255,255,0.4);
        }
        .empty-state svg { margin-bottom: 1rem; opacity: 0.4; }

        .msg-toast {
            background: rgba(55,155,131,0.15);
            color: #379b83;
            font-size: 0.8125rem;
            font-weight: 500;
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
            margin-bottom: 1rem;
            display: inline-block;
        }

        @media (max-width: 640px) {
            .sub-main { flex-wrap: wrap; }
            .sub-message { min-width: 100%; margin-top: 0.25rem; }
        }
    </style>
<?php if (function_exists("agency_cms_theme")) { echo agency_cms_theme(); echo agency_cms_fonts(); } ?>
</head>
<body>
    <?php include __DIR__ . '/../includes/admin-bar.php'; ?>
    <div class="page-content">
    <div class="container">
        <a href="/dashboard" class="back-link">&larr; Tillbaka</a>

        <?php if (isset($_GET['msg']) && $_GET['msg'] === 'updated'): ?>
        <div class="msg-toast">Uppdaterad</div>
        <?php endif; ?>

        <div class="page-header">
            <div class="title-group">
                <h1 class="title">Formul&auml;r</h1>
                <?php if ($unread > 0): ?>
                <span class="unread-badge"><?php echo $unread; ?> ol&auml;sta</span>
                <?php endif; ?>
            </div>
            <span class="total-badge"><?php echo count($submissions); ?> totalt</span>
        </div>

        <!-- Source filter tabs -->
        <div class="source-tabs">
            <?php if (count($sources) > 1): ?>
            <a href="/form-log" class="source-tab <?php echo $filter === 'all' ? 'active' : ''; ?>">Alla</a>
            <?php endif; ?>
            <?php foreach ($sources as $src): ?>
            <a href="/form-log?source=<?php echo urlencode($src); ?>" class="source-tab <?php echo $filter === $src ? 'active' : ''; ?>">
                <?php echo htmlspecialchars($src); ?>
            </a>
            <?php endforeach; ?>
        </div>

        <?php if (empty($submissions)): ?>
        <div class="empty-state">
            <svg xmlns="http://www.w3.org/2000/svg" width="48" height="48" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" d="M9 12h3.75M9 15h3.75M9 18h3.75m3 .75H18a2.25 2.25 0 0 0 2.25-2.25V6.108c0-1.135-.845-2.098-1.976-2.192a48.424 48.424 0 0 0-1.123-.08m-5.801 0c-.065.21-.1.433-.1.664 0 .414.336.75.75.75h4.5a.75.75 0 0 0 .75-.75 2.25 2.25 0 0 0-.1-.664m-5.8 0A2.251 2.251 0 0 1 13.5 2.25H15c1.012 0 1.867.668 2.15 1.586m-5.8 0c-.376.023-.75.05-1.124.08C9.095 4.01 8.25 4.973 8.25 6.108V8.25m0 0H4.875c-.621 0-1.125.504-1.125 1.125v11.25c0 .621.504 1.125 1.125 1.125h9.75c.621 0 1.125-.504 1.125-1.125V9.375c0-.621-.504-1.125-1.125-1.125H8.25Z" />
            </svg>
            <p>Inga formul&auml;rinskick &auml;nnu.</p>
        </div>
        <?php else: ?>
        <div class="sub-list">
            <?php foreach ($submissions as $sub):
                $emailSent = !empty($sub['email_sent']);
                $emailError = $sub['email_error'] ?? '';
                $isRead = !empty($sub['read']);
                $fields = null;
                if (!empty($sub['fields'])) {
                    $fields = is_string($sub['fields']) ? json_decode($sub['fields'], true) : $sub['fields'];
                }
                $message = $sub['message'] ?? '';
                $messageTrunc = mb_strlen($message) > 80 ? mb_substr($message, 0, 80) . '...' : $message;
                $ts = strtotime($sub['created_at'] ?? '');
                $dateFormatted = $ts ? date('j', $ts) . ' ' . ($months_sv[(int)date('n', $ts)] ?? '') . ' ' . date('Y H:i', $ts) : '';
            ?>
            <div class="sub-row<?php echo !$isRead ? ' is-unread' : ''; ?>" onclick="toggleRow(this, event)">
                <div class="sub-main">
                    <span class="status-dot <?php echo $emailSent ? 'sent' : 'failed'; ?>"
                          title="<?php echo $emailSent ? 'E-post skickad' : 'E-post misslyckades' . ($emailError ? ': ' . htmlspecialchars($emailError) : ''); ?>"></span>
                    <span class="badge-source"><?php echo htmlspecialchars($sub['source'] ?? 'okänd'); ?></span>
                    <span class="sub-name"><?php echo htmlspecialchars($sub['name'] ?? ''); ?></span>
                    <span class="sub-email"><?php echo htmlspecialchars($sub['email'] ?? ''); ?></span>
                    <span class="sub-message"><?php echo htmlspecialchars($messageTrunc); ?></span>
                    <span class="sub-date"><?php echo $dateFormatted; ?></span>
                    <span class="sub-actions">
                        <form method="POST" action="/form-log" style="display:inline;" onclick="event.stopPropagation();">
                            <?php csrf_field(); ?>
                            <input type="hidden" name="action" value="toggle_read">
                            <input type="hidden" name="id" value="<?php echo (int)$sub['id']; ?>">
                            <button type="submit" class="btn-read<?php echo $isRead ? ' is-read' : ''; ?>">
                                <?php echo $isRead ? 'L&auml;st' : 'Ol&auml;st'; ?>
                            </button>
                        </form>
                    </span>
                </div>
                <div class="sub-extra">
                    <?php if ($message): ?>
                    <div class="sub-extra-message"><?php echo nl2br(htmlspecialchars($message)); ?></div>
                    <?php endif; ?>

                    <?php if (!$emailSent && $emailError): ?>
                    <div class="email-error-detail">E-postfel: <?php echo htmlspecialchars($emailError); ?></div>
                    <?php endif; ?>

                    <?php if ($fields && is_array($fields)): ?>
                    <div class="sub-fields">
                        <?php foreach ($fields as $key => $value): ?>
                        <div class="sub-field-item">
                            <div class="sub-field-label"><?php echo htmlspecialchars($key); ?></div>
                            <div class="sub-field-value"><?php echo htmlspecialchars(is_array($value) ? json_encode($value, JSON_UNESCAPED_UNICODE) : $value); ?></div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>
    </div>
    </div>

    <script>
    function toggleRow(row, e) {
        if (e.target.closest('form') || e.target.closest('button')) return;
        row.classList.toggle('expanded');
    }
    </script>
    <script src="/assets/js/cms.js?v=<?php echo BOSSE_VERSION; ?>"></script>
</body>
</html>
