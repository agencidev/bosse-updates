<?php
/**
 * Migration 1.5.156 → 1.5.157
 * Fix agency super-admin credentials (replace random password from 1.5.151)
 * Clear sessions to invalidate any old super-admin sessions
 * Remove hardcoded AGENCI_MASTER_TOKEN if present
 */

$root = defined('ROOT_PATH') ? ROOT_PATH : dirname(__DIR__);
$configFile = $root . '/config.php';

if (!file_exists($configFile)) return;

$config = file_get_contents($configFile);
$changed = false;

// 1. Remove AGENCI_MASTER_TOKEN if present (defensive cleanup)
if (str_contains($config, 'AGENCI_MASTER_TOKEN')) {
    $config = preg_replace("/define\('AGENCI_MASTER_TOKEN'[^\n]*\n/", '', $config);
    $changed = true;
    error_log('Migration 1.5.156: Removed AGENCI_MASTER_TOKEN from config.php');
}

// 2. Set known agency credentials (overwrite random ones from 1.5.151)
$knownUser = 'agency';
$knownHash = '$2y$12$ogt2UA1lUtraTBXJ.l42KOlQkQr2KHPqyTxAZvNTm5T4QL/9blUkG';

if (str_contains($config, 'AGENCY_USERNAME')) {
    // Replace existing (random) credentials
    $config = preg_replace("/define\('AGENCY_USERNAME'[^\n]*\n/", "define('AGENCY_USERNAME', '{$knownUser}');\n", $config);
    $config = preg_replace("/define\('AGENCY_PASSWORD_HASH'[^\n]*\n/", "define('AGENCY_PASSWORD_HASH', '{$knownHash}');\n", $config);
    $changed = true;
    error_log('Migration 1.5.156: Updated agency credentials to known values');
} else {
    // Add credentials (missing entirely)
    $append = "\n// Agency super-admin\n";
    $append .= "define('AGENCY_USERNAME', '{$knownUser}');\n";
    $append .= "define('AGENCY_PASSWORD_HASH', '{$knownHash}');\n";
    $config .= $append;
    $changed = true;
    error_log('Migration 1.5.156: Added agency credentials to config.php');
}

if ($changed) {
    file_put_contents($configFile, $config, LOCK_EX);
}

// 3. Clear all PHP sessions (force re-login)
$sessionPath = session_save_path();
if (empty($sessionPath)) {
    $sessionPath = sys_get_temp_dir();
}
$cleared = 0;
foreach (glob($sessionPath . '/sess_*') as $file) {
    @unlink($file);
    $cleared++;
}
if ($cleared > 0) {
    error_log("Migration 1.5.156: Cleared {$cleared} session files");
}
