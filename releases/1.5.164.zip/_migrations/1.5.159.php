<?php
/**
 * Migration 1.5.159 → 1.5.160
 * Change default agency super-admin username from "agency" to "admin"
 */

$root = defined('ROOT_PATH') ? ROOT_PATH : dirname(__DIR__);
$configFile = $root . '/config.php';

if (!file_exists($configFile)) return;

$config = file_get_contents($configFile);
$changed = false;

// Update AGENCY_USERNAME from 'agency' to 'admin'
if (preg_match("/define\('AGENCY_USERNAME',\s*'agency'\)/", $config)) {
    $config = preg_replace(
        "/define\('AGENCY_USERNAME',\s*'agency'\)/",
        "define('AGENCY_USERNAME', 'admin')",
        $config
    );
    $changed = true;
    error_log('Migration 1.5.159: Updated AGENCY_USERNAME from "agency" to "admin"');
}

if ($changed) {
    file_put_contents($configFile, $config, LOCK_EX);
}
