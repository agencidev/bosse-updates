<?php
/**
 * Bosse Template Version
 * CORE-fil - skrivs över vid uppdatering
 */

define('BOSSE_VERSION', '1.5.44');
define('BOSSE_VERSION_DATE', '2026-02-19');
