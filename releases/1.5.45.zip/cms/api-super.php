<?php
/**
 * Super Admin API
 * Alla endpoints kraver super admin + CSRF
 */

require_once __DIR__ . '/../bootstrap.php';
require_once __DIR__ . '/../security/session.php';
require_once __DIR__ . '/../security/csrf.php';
require_once __DIR__ . '/../security/updater.php';

// Krav: super admin
require_super_admin();

// CORS/JSON headers
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

// CSRF-verifiering för alla requests
$csrfHeader = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? '';
if (empty($csrfHeader) || !isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $csrfHeader)) {
    http_response_code(403);
    echo json_encode(['error' => 'Ogiltig CSRF-token']);
    exit;
}

switch ($action) {
    case 'check-update':
        handle_check_update();
        break;

    case 'apply-update':
        if ($method !== 'POST') { method_not_allowed(); }
        handle_apply_update();
        break;

    case 'rollback':
        if ($method !== 'POST') { method_not_allowed(); }
        handle_rollback();
        break;

    case 'delete-backup':
        if ($method !== 'POST') { method_not_allowed(); }
        handle_delete_backup();
        break;

    case 'system-info':
        handle_system_info();
        break;

    case 'test-smtp':
        if ($method !== 'POST') { method_not_allowed(); }
        handle_test_smtp();
        break;

    case 'error-log':
        handle_error_log();
        break;

    case 'clear-error-log':
        if ($method !== 'POST') { method_not_allowed(); }
        handle_clear_error_log();
        break;

    case 'check-integrity':
        handle_check_integrity();
        break;

    case 'change-password':
        if ($method !== 'POST') { method_not_allowed(); }
        handle_change_password();
        break;

    case 'save-config':
        if ($method !== 'POST') { method_not_allowed(); }
        handle_save_config();
        break;

    default:
        http_response_code(404);
        echo json_encode(['error' => 'Okänd action']);
        exit;
}

function method_not_allowed(): void {
    http_response_code(405);
    echo json_encode(['error' => 'Method Not Allowed']);
    exit;
}

function handle_check_update(): void {
    $result = check_for_update();
    echo json_encode($result);
}

function handle_apply_update(): void {
    // Hämta aktuell status
    $state = check_for_update();

    if (isset($state['error'])) {
        echo json_encode(['success' => false, 'errors' => [$state['error']]]);
        return;
    }

    if (empty($state['update_available'])) {
        echo json_encode(['success' => false, 'errors' => ['Ingen uppdatering tillgänglig']]);
        return;
    }

    // PHP-versionskontroll
    if (!empty($state['min_php_version']) && version_compare(PHP_VERSION, $state['min_php_version'], '<')) {
        echo json_encode(['success' => false, 'errors' => ['Kräver PHP ' . $state['min_php_version'] . ', du har ' . PHP_VERSION]]);
        return;
    }

    // Ladda ner
    $zipPath = download_update($state['download_url'], $state['signature'] ?? '');
    if ($zipPath === false) {
        echo json_encode(['success' => false, 'errors' => ['Kunde inte ladda ner uppdateringen']]);
        return;
    }

    // Applicera
    $result = apply_update($zipPath);

    // Om fel - automatisk rollback
    if (!$result['success'] && !empty($result['backup_dir'])) {
        rollback_update($result['backup_dir']);
        $result['rolled_back'] = true;
    }

    // Lägg till nya versionen i responsen + rensa update-available-flaggan
    if ($result['success']) {
        $result['new_version'] = $state['latest_version'] ?? '';

        // Spara staten med update_available = false så bannern försvinner
        $state['update_available'] = false;
        $state['current_version'] = $state['latest_version'];
        save_update_state($state);

        // Logga händelsen
        log_update_event('success', $state['latest_version'] ?? '?',
            count($result['updated_files']) . ' filer uppdaterade via Super Admin');
    }

    echo json_encode($result);
}

function handle_rollback(): void {
    $input = json_decode(file_get_contents('php://input'), true);
    $backupName = $input['backup'] ?? '';

    if (empty($backupName) || preg_match('/[^a-zA-Z0-9._-]/', $backupName)) {
        echo json_encode(['success' => false, 'error' => 'Ogiltigt backup-namn']);
        return;
    }

    $backupDir = DATA_PATH . '/backups/' . $backupName;
    if (!is_dir($backupDir)) {
        echo json_encode(['success' => false, 'error' => 'Backup hittades inte']);
        return;
    }

    $success = rollback_update($backupDir);
    echo json_encode(['success' => $success]);
}

function handle_delete_backup(): void {
    $input = json_decode(file_get_contents('php://input'), true);
    $backupName = $input['backup'] ?? '';

    if (empty($backupName) || preg_match('/[^a-zA-Z0-9._-]/', $backupName)) {
        echo json_encode(['success' => false, 'error' => 'Ogiltigt backup-namn']);
        return;
    }

    $backupDir = DATA_PATH . '/backups/' . $backupName;
    $success = delete_backup($backupDir);
    echo json_encode(['success' => $success]);
}

function handle_system_info(): void {
    $info = [
        'php_version' => PHP_VERSION,
        'server' => $_SERVER['SERVER_SOFTWARE'] ?? 'Okänd',
        'os' => PHP_OS,
        'memory_limit' => ini_get('memory_limit'),
        'memory_usage' => round(memory_get_usage(true) / 1024 / 1024, 2) . ' MB',
        'upload_max' => ini_get('upload_max_filesize'),
        'post_max' => ini_get('post_max_size'),
        'max_execution' => ini_get('max_execution_time') . 's',
        'extensions' => get_loaded_extensions(),
        'writable' => [
            'data/' => is_writable(DATA_PATH),
            'config.php' => is_writable(ROOT_PATH . '/config.php'),
            'assets/css/' => is_writable(ROOT_PATH . '/assets/css'),
        ],
    ];

    if (function_exists('disk_free_space')) {
        $info['disk_free'] = round(@disk_free_space(ROOT_PATH) / 1024 / 1024, 2) . ' MB';
        $info['disk_total'] = round(@disk_total_space(ROOT_PATH) / 1024 / 1024, 2) . ' MB';
    }

    echo json_encode($info);
}

function handle_test_smtp(): void {
    if (!defined('SMTP_HOST') || SMTP_HOST === '') {
        echo json_encode(['success' => false, 'error' => 'SMTP är inte konfigurerat']);
        return;
    }

    require_once __DIR__ . '/../includes/mailer.php';

    $to = defined('CONTACT_EMAIL') ? CONTACT_EMAIL : (defined('SMTP_USERNAME') ? SMTP_USERNAME : '');
    if (empty($to)) {
        echo json_encode(['success' => false, 'error' => 'Ingen mottagaradress hittades']);
        return;
    }

    $subject = 'SMTP-test från ' . (defined('SITE_NAME') ? SITE_NAME : 'Bosse Template');
    $body = "Detta ar ett testmail skickat från Super Admin-panelen.\n\n";
    $body .= "Tidpunkt: " . date('Y-m-d H:i:s') . "\n";
    $body .= "Server: " . ($_SERVER['SERVER_NAME'] ?? 'localhost') . "\n";
    $body .= "PHP: " . PHP_VERSION . "\n";

    $success = send_mail($to, $subject, $body);

    echo json_encode([
        'success' => $success,
        'to' => $to,
        'error' => $success ? null : 'SMTP-anslutningen misslyckades. Kontrollera loggarna.',
    ]);
}

function handle_error_log(): void {
    $log = '';
    $errorLogPath = ini_get('error_log');

    if ($errorLogPath && file_exists($errorLogPath) && is_readable($errorLogPath)) {
        $lines = file($errorLogPath);
        if ($lines !== false) {
            $log = implode('', array_slice($lines, -100));
        }
    }

    echo json_encode(['log' => $log]);
}

function handle_clear_error_log(): void {
    $errorLogPath = ini_get('error_log');

    if (!$errorLogPath || !file_exists($errorLogPath)) {
        echo json_encode(['success' => true, 'message' => 'Ingen loggfil att rensa']);
        return;
    }

    if (!is_writable($errorLogPath)) {
        echo json_encode(['success' => false, 'error' => 'Loggfilen är inte skrivbar']);
        return;
    }

    $result = file_put_contents($errorLogPath, '', LOCK_EX);
    echo json_encode(['success' => $result !== false]);
}

function handle_change_password(): void {
    $input = json_decode(file_get_contents('php://input'), true);
    $newPassword = $input['password'] ?? '';

    if (strlen($newPassword) < 8) {
        echo json_encode(['success' => false, 'error' => 'Lösenordet måste vara minst 8 tecken']);
        return;
    }

    $configFile = ROOT_PATH . '/config.php';
    if (!file_exists($configFile)) {
        echo json_encode(['success' => false, 'error' => 'config.php hittades inte']);
        return;
    }

    if (function_exists('backup_config')) backup_config();
    $config = file_get_contents($configFile);
    $newHash = password_hash($newPassword, PASSWORD_BCRYPT);
    $config = preg_replace(
        "/define\('ADMIN_PASSWORD_HASH',\s*'[^']*'\)/",
        "define('ADMIN_PASSWORD_HASH', " . var_export($newHash, true) . ")",
        $config
    );

    if (file_put_contents($configFile, $config, LOCK_EX) === false) {
        echo json_encode(['success' => false, 'error' => 'Kunde inte skriva till config.php']);
        return;
    }

    echo json_encode(['success' => true, 'message' => 'Lösenordet har ändrats']);
}

function handle_save_config(): void {
    $input = json_decode(file_get_contents('php://input'), true);
    if (!is_array($input)) {
        echo json_encode(['success' => false, 'error' => 'Ogiltig data']);
        return;
    }

    $configFile = ROOT_PATH . '/config.php';
    if (!file_exists($configFile) || !is_writable($configFile)) {
        echo json_encode(['success' => false, 'error' => 'config.php är inte skrivbar']);
        return;
    }

    if (function_exists('backup_config')) backup_config();
    $config = file_get_contents($configFile);

    // Fält som kan uppdateras direkt
    $directFields = [
        'site_url' => 'SITE_URL',
        'site_name' => 'SITE_NAME',
        'site_description' => 'SITE_DESCRIPTION',
        'contact_email' => 'CONTACT_EMAIL',
        'contact_phone' => 'CONTACT_PHONE',
        'admin_username' => 'ADMIN_USERNAME',
        'smtp_host' => 'SMTP_HOST',
        'smtp_port' => 'SMTP_PORT',
        'smtp_encryption' => 'SMTP_ENCRYPTION',
        'smtp_username' => 'SMTP_USERNAME',
        'github_repo' => 'GITHUB_REPO',
        'ga_id' => 'GOOGLE_ANALYTICS_ID',
    ];

    foreach ($directFields as $inputKey => $constant) {
        if (!isset($input[$inputKey])) continue;
        $newValue = $input[$inputKey];
        // Byt ut define-raden
        $pattern = "/define\('" . preg_quote($constant, '/') . "',\s*'[^']*'\)/";
        $replacement = "define('" . $constant . "', " . var_export($newValue, true) . ")";
        $config = preg_replace($pattern, $replacement, $config);
    }

    // Lösenordsfält — bara uppdatera om icke-tomma
    if (!empty($input['smtp_password'])) {
        $config = preg_replace(
            "/define\('SMTP_PASSWORD',\s*'[^']*'\)/",
            "define('SMTP_PASSWORD', " . var_export($input['smtp_password'], true) . ")",
            $config
        );
    }

    if (!empty($input['github_token'])) {
        $config = preg_replace(
            "/define\('GITHUB_TOKEN',\s*'[^']*'\)/",
            "define('GITHUB_TOKEN', " . var_export($input['github_token'], true) . ")",
            $config
        );
    }

    // Add GitHub defines if missing in config.php
    if (!empty($input['github_repo']) || !empty($input['github_token'])) {
        $hasGithubRepo = strpos($config, "define('GITHUB_REPO'") !== false;
        $hasGithubToken = strpos($config, "define('GITHUB_TOKEN'") !== false;

        if (!$hasGithubRepo || !$hasGithubToken) {
            $githubBlock = "\n// GitHub (för automatisk push vid uppdatering)\n";
            if (!$hasGithubRepo && !empty($input['github_repo'])) {
                $githubBlock .= "define('GITHUB_REPO', " . var_export($input['github_repo'], true) . ");\n";
            }
            if (!$hasGithubToken && !empty($input['github_token'])) {
                $githubBlock .= "define('GITHUB_TOKEN', " . var_export($input['github_token'], true) . ");\n";
            }
            $config = rtrim($config) . "\n" . $githubBlock;
        }
    }

    if (file_put_contents($configFile, $config, LOCK_EX) === false) {
        echo json_encode(['success' => false, 'error' => 'Kunde inte skriva till config.php']);
        return;
    }

    // Sync .site-url if SITE_URL changed (used by Bosse Portal)
    if (!empty($input['site_url'])) {
        @file_put_contents(ROOT_PATH . '/.site-url', rtrim($input['site_url'], '/'));
    }

    echo json_encode(['success' => true]);
}

function handle_check_integrity(): void {
    $rootPath = defined('ROOT_PATH') ? ROOT_PATH : dirname(__DIR__);
    $missing = [];

    foreach (UPDATABLE_FILES as $file) {
        $fullPath = $rootPath . '/' . $file;
        if (!file_exists($fullPath)) {
            $missing[] = $file;
        }
    }

    echo json_encode([
        'total' => count(UPDATABLE_FILES),
        'present' => count(UPDATABLE_FILES) - count($missing),
        'missing' => $missing,
    ]);
}
