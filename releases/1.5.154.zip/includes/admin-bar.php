<?php
/**
 * Admin Bar Component
 * Visar admin-bar när användaren är inloggad
 */

// Defensive requires for standalone inclusion safety
if (!function_exists('is_logged_in')) {
    require_once __DIR__ . '/../security/session.php';
}
if (!is_logged_in()) {
    return;
}
if (!function_exists('csrf_field')) {
    require_once __DIR__ . '/../security/csrf.php';
}
if (!function_exists('is_super_admin')) {
    require_once __DIR__ . '/../security/super-admin.php';
}
if (!function_exists('csp_nonce_attr')) {
    require_once __DIR__ . '/../security/csp.php';
}

// Check if we're on frontend (not in CMS/dashboard)
$uri = $_SERVER['REQUEST_URI'];
$is_cms = preg_match('#^/(cms/|dashboard|admin|super-admin|seo|support|ai|projects|setup|api/|settings|tickets|media|inlagg-admin|categories|analytics|sok)#', $uri);
$is_frontend = !$is_cms;
?>
<?php $__bg = htmlspecialchars(agency_config('cms_bg') ?: '#033234'); $__ac = htmlspecialchars(agency_config('cms_accent') ?: '#379b83'); ?>
<style>.admin-bar,.admin-bar *{font-family:'<?php echo htmlspecialchars(agency_config('cms_font') ?: 'DM Sans'); ?>',sans-serif !important}.admin-bar{background-color:<?php echo $__bg; ?> !important;background:<?php echo $__bg; ?> !important}.admin-bar .admin-bar__btn-logout{background-color:<?php echo $__ac; ?> !important;background:<?php echo $__ac; ?> !important;color:#fff !important}.admin-bar .admin-bar__btn-edit.active{background:<?php echo $__ac; ?> !important;border-color:<?php echo $__ac; ?> !important}</style>
<div class="admin-bar">
    <div class="admin-bar__container">
        <div class="admin-bar__left">
            <a href="/dashboard" class="admin-bar__logo">
                <img src="<?php echo htmlspecialchars(agency_config('logo_light')); ?>" alt="<?php echo htmlspecialchars(agency_config('name')); ?>" class="admin-bar__logo-img">
            </a>
            <?php if (is_super_admin()): ?>
                <span class="admin-bar__sa-badge" title="Super Admin"><svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M2.5 19.5h19v2h-19v-2Zm19.57-9.36c-.22-.8-1.04-1.27-1.84-1.06L16.5 10.2l-3.12-5.4a1.5 1.5 0 0 0-2.59-.02L7.5 10.2l-3.73-1.12c-.8-.24-1.64.2-1.87 1-.12.4-.05.84.18 1.18L6 16.5h12l3.9-5.24c.25-.35.32-.78.17-1.12Z"/></svg></span>
            <?php endif; ?>
            <div class="admin-bar__divider"></div>
            <div class="admin-bar__menu">
                <button id="admin-bar-menu-toggle" class="admin-bar__menu-btn" aria-expanded="false">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" x2="21" y1="6" y2="6"/><line x1="3" x2="21" y1="12" y2="12"/><line x1="3" x2="21" y1="18" y2="18"/></svg>
                    <span>Meny</span>
                    <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="6 9 12 15 18 9"/></svg>
                </button>
                <div class="admin-bar__dropdown" id="admin-bar-dropdown">
                    <a href="/dashboard" class="admin-bar__dropdown-link">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/></svg>
                        Dashboard
                    </a>
                    <a href="/inlagg-admin" class="admin-bar__dropdown-link">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/></svg>
                        Inlägg
                    </a>
                    <a href="/media" class="admin-bar__dropdown-link">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.09-3.09a2 2 0 0 0-2.82 0L6 21"/></svg>
                        Media
                    </a>
                    <a href="/seo" class="admin-bar__dropdown-link">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>
                        SEO
                    </a>
                    <!-- Ärenden (dold tills lansering)
                    <a href="/tickets" class="admin-bar__dropdown-link">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/></svg>
                        Ärenden
                    </a>
                    -->
                    <a href="/analytics" class="admin-bar__dropdown-link">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M3 3v18h18"/><path d="m19 9-5 5-4-4-3 3"/></svg>
                        Analytics
                    </a>
                    <a href="/categories" class="admin-bar__dropdown-link">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 2 2 7l10 5 10-5-10-5Z"/><path d="m2 17 10 5 10-5"/><path d="m2 12 10 5 10-5"/></svg>
                        Kategorier
                    </a>
                    <a href="/settings" class="admin-bar__dropdown-link">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>
                        Inställningar
                    </a>
                    <a href="/support" class="admin-bar__dropdown-link">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><path d="M12 17h.01"/></svg>
                        Support
                    </a>
                </div>
            </div>
            <?php if ($is_frontend): ?>
                <div class="admin-bar__divider"></div>
                <button id="toggle-edit-mode" class="admin-bar__btn-edit">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>
                    <span>Aktivera redigering</span>
                </button>
                <button id="cms-save-all" class="admin-bar__btn-save" style="display:none;">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg>
                    <span>Spara</span>
                </button>
            <?php endif; ?>
        </div>

        <div class="admin-bar__right">
            <a href="/dashboard" class="admin-bar__nav-link">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="7" height="9" x="3" y="3" rx="1"/><rect width="7" height="5" x="14" y="3" rx="1"/><rect width="7" height="9" x="14" y="12" rx="1"/><rect width="7" height="5" x="3" y="16" rx="1"/></svg>
                <span>Dashboard</span>
            </a>
            <form method="post" action="/cms/admin.php" style="display:inline;margin:0;">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="action" value="logout">
                <button type="submit" class="admin-bar__nav-link admin-bar__nav-link--logout">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" x2="9" y1="12" y2="12"/></svg>
                    <span>Logga ut</span>
                </button>
            </form>
        </div>
    </div>
</div>

<style>
.admin-bar {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 10000;
    height: 3.5rem;
    background: #033234;
    color: white;
    font-family: 'DM Sans', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif !important;
    font-size: 0.875rem;
    line-height: 1.5;
    border-bottom: 1px solid rgba(255,255,255,0.08);
}

.admin-bar *,
.admin-bar *::before,
.admin-bar *::after {
    font-family: inherit !important;
}

.admin-bar__container {
    width: 100%;
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 1.5rem;
    display: flex;
    align-items: center;
    justify-content: space-between;
    height: 100%;
}

.admin-bar__left {
    display: flex;
    align-items: center;
    gap: 0.75rem;
}

.admin-bar__right {
    display: flex;
    align-items: center;
    gap: 0.25rem;
}

.admin-bar__logo {
    display: flex;
    align-items: center;
    transition: opacity 0.2s;
}

.admin-bar__logo:hover {
    opacity: 0.8;
}

.admin-bar__logo-img {
    height: 1.625rem;
    width: auto;
}

.admin-bar__divider {
    width: 1px;
    height: 1.25rem;
    background: rgba(255,255,255,0.15);
}

/* Edit mode toggle button */
.admin-bar__btn-edit {
    display: inline-flex;
    align-items: center;
    gap: 0.375rem;
    padding: 0.375rem 0.875rem;
    border-radius: 9999px;
    font-size: 0.875rem;
    font-weight: 600;
    cursor: pointer;
    border: 1px solid rgba(255,255,255,0.15);
    background: transparent;
    color: rgba(255,255,255,0.8);
    white-space: nowrap;
    transition: all 0.2s;
    line-height: 1;
}

.admin-bar__btn-edit:hover {
    background: rgba(255,255,255,0.08);
    color: white;
    border-color: rgba(255,255,255,0.25);
}

.admin-bar__btn-edit.active {
    background: #379b83;
    color: white;
    border-color: #379b83;
}

.admin-bar__btn-edit.active:hover {
    background: #2e8570;
    border-color: #2e8570;
}

.admin-bar__btn-edit svg {
    flex-shrink: 0;
}

.admin-bar__btn-save {
    display: inline-flex;
    align-items: center;
    gap: 0.375rem;
    padding: 0.375rem 0.875rem;
    border-radius: 9999px;
    font-size: 0.875rem;
    font-weight: 600;
    cursor: pointer;
    border: none;
    background: #379b83;
    color: white;
    white-space: nowrap;
    transition: all 0.2s;
    line-height: 1;
    animation: cmsSaveFadeIn 0.2s ease-out;
}
.admin-bar__btn-save:hover { background: #2e8570; }
.admin-bar__btn-save svg { flex-shrink: 0; }
@keyframes cmsSaveFadeIn { from { opacity: 0; transform: scale(0.9); } to { opacity: 1; transform: scale(1); } }

/* Navigation links (Dashboard, Logga ut) */
.admin-bar__nav-link {
    display: inline-flex;
    align-items: center;
    gap: 0.375rem;
    padding: 0.375rem 0.75rem;
    border-radius: 0.5rem;
    font-size: 0.875rem;
    font-weight: 500;
    cursor: pointer;
    border: none;
    background: transparent;
    color: rgba(255,255,255,0.55);
    white-space: nowrap;
    transition: all 0.15s;
    text-decoration: none;
    line-height: 1;
}

.admin-bar__nav-link:hover {
    color: white;
    background: rgba(255,255,255,0.08);
}

.admin-bar__nav-link svg {
    flex-shrink: 0;
    opacity: 0.7;
}

.admin-bar__nav-link:hover svg {
    opacity: 1;
}

.admin-bar__sa-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    color: #f59e0b;
    flex-shrink: 0;
}

/* Menu dropdown */
.admin-bar__menu {
    position: relative;
}

.admin-bar__menu-btn {
    display: inline-flex;
    align-items: center;
    gap: 0.375rem;
    padding: 0.375rem 0.75rem;
    border-radius: 0.5rem;
    font-size: 0.875rem;
    font-weight: 500;
    cursor: pointer;
    border: none;
    background: transparent;
    color: rgba(255,255,255,0.7);
    white-space: nowrap;
    transition: all 0.15s;
    line-height: 1;
}

.admin-bar__menu-btn:hover,
.admin-bar__menu-btn[aria-expanded="true"] {
    color: white;
    background: rgba(255,255,255,0.08);
}

.admin-bar__dropdown {
    display: none;
    position: absolute;
    top: calc(100% + 0.5rem);
    left: 0;
    min-width: 200px;
    background: rgba(0,0,0,0.95);
    backdrop-filter: blur(12px);
    border: 1px solid rgba(255,255,255,0.12);
    border-radius: 0.75rem;
    padding: 0.375rem;
    z-index: 10001;
    box-shadow: 0 8px 32px rgba(0,0,0,0.4);
}

.admin-bar__dropdown.open {
    display: block;
}

.admin-bar__dropdown-link {
    display: flex;
    align-items: center;
    gap: 0.625rem;
    padding: 0.5rem 0.75rem;
    border-radius: 0.5rem;
    font-size: 0.8125rem;
    font-weight: 500;
    color: rgba(255,255,255,0.7) !important;
    text-decoration: none !important;
    transition: all 0.12s;
    line-height: 1;
}

.admin-bar__dropdown-link:hover {
    background: rgba(255,255,255,0.08);
    color: white !important;
}

.admin-bar__dropdown-link svg {
    flex-shrink: 0;
    opacity: 0.6;
}

.admin-bar__dropdown-link:hover svg {
    opacity: 1;
}

body.has-admin-bar {
    padding-top: 3.5rem !important;
}

/* Push down fixed/sticky headers so they don't overlap admin-bar */
/* Uses child selector (>) to only target top-level header, not nested elements like .header__nav */
body.has-admin-bar > header,
body.has-admin-bar > .header {
    top: 3.5rem !important;
}

/* Ensure admin-bar is always on top of everything */
.admin-bar {
    z-index: 10000 !important;
}

/* Hide legacy CMS link in site headers — admin bar provides dashboard access */
.header__nav-link--admin {
    display: none !important;
}
</style>

<script <?php echo csp_nonce_attr(); ?>>
document.body.classList.add('has-admin-bar');

// Admin menu dropdown
(function() {
    var btn = document.getElementById('admin-bar-menu-toggle');
    var dd = document.getElementById('admin-bar-dropdown');
    if (btn && dd) {
        btn.addEventListener('click', function(e) {
            e.stopPropagation();
            var open = dd.classList.toggle('open');
            btn.setAttribute('aria-expanded', open);
        });
        document.addEventListener('click', function() {
            dd.classList.remove('open');
            btn.setAttribute('aria-expanded', 'false');
        });
        document.addEventListener('keydown', function(e) {
            if (e.key === 'Escape') {
                dd.classList.remove('open');
                btn.setAttribute('aria-expanded', 'false');
            }
        });
    }
})();

// CMS Edit Mode State
window.CMS = window.CMS || {};
window.CMS.isEditMode = false;
window.CMS.isAuthenticated = true;

const toggleBtn = document.getElementById('toggle-edit-mode');
const saveAllBtn = document.getElementById('cms-save-all');

// Track unsaved inline editors
window.CMS.hasUnsavedEdits = false;

function hasOpenEditors() {
    // Check if any inline editor wrappers are currently open
    return document.querySelectorAll('[data-editable-text] + div input, [data-editable-text] + div textarea').length > 0;
}

if (toggleBtn) {
    toggleBtn.addEventListener('click', function() {
        // Trying to exit edit mode — check for open editors
        if (window.CMS.isEditMode) {
            if (hasOpenEditors()) {
                if (!confirm('Du har osparade ändringar. Vill du lämna utan att spara?')) {
                    return; // Stay in edit mode
                }
            }
        }

        window.CMS.isEditMode = !window.CMS.isEditMode;

        if (window.CMS.isEditMode) {
            toggleBtn.classList.add('active');
            toggleBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"/></svg><span>Avsluta redigering</span>';
            document.body.classList.add('cms-edit-mode');
        } else {
            toggleBtn.classList.remove('active');
            toggleBtn.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg><span>Aktivera redigering</span>';
            document.body.classList.remove('cms-edit-mode');
            if (saveAllBtn) saveAllBtn.style.display = 'none';
        }

        window.dispatchEvent(new CustomEvent('cms-edit-mode-changed', { detail: { isEditMode: window.CMS.isEditMode } }));
    });
}

// Save button: click saves all open inline editors
if (saveAllBtn) {
    saveAllBtn.addEventListener('click', function() {
        var saveBtns = document.querySelectorAll('[data-editable-text] + div button');
        saveBtns.forEach(function(btn) {
            // Find save buttons (they contain the checkmark SVG or "Spara" text)
            if (btn.textContent.includes('Spara') || btn.innerHTML.includes('polyline')) {
                btn.click();
            }
        });
    });
}

// Show/hide save button when editors open/close
var editorObserver = new MutationObserver(function() {
    if (!saveAllBtn || !window.CMS.isEditMode) return;
    saveAllBtn.style.display = hasOpenEditors() ? 'inline-flex' : 'none';
});
editorObserver.observe(document.body, { childList: true, subtree: true });

// Warn on page navigation with open editors
window.addEventListener('beforeunload', function(e) {
    if (window.CMS.isEditMode && hasOpenEditors()) {
        e.preventDefault();
        e.returnValue = '';
    }
});
</script>
